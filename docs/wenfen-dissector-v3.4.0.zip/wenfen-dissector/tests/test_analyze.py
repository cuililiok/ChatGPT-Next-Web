#!/usr/bin/env python3
"""
wenfen-dissector 单元测试 — analyze.py

覆盖范围：
- is_cjk 边界（Basic / Ext A / Ext B / Compat / 非CJK）
- _sent_bucket / _para_bucket 分桶正确性
- classify_rhetoric 各辞格正例和反例
- detect_open 句首分类
- detect_classical 文言文检测
- analyze_paragraphs 单换行 fallback
- _get_contexts 完整句子返回
- run() 错误路径
- run() 正常路径 golden output 快照
- verify_quotes 引句去重
"""

import sys
import os
import pytest

# 确保 scripts 目录在路径中
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

import analyze
from analyze import (
    is_cjk, _sent_bucket, _para_bucket, classify_rhetoric,
    detect_open, detect_classical, analyze_paragraphs,
    _get_contexts, run, verify_quotes, _SENT_RE
)


# ════════════════════════════════════════════════
# is_cjk 测试
# ════════════════════════════════════════════════

class TestIsCJK:
    def test_basic_range(self):
        """CJK Basic: U+4E00-U+9FFF"""
        assert is_cjk('中') is True
        assert is_cjk('国') is True
        assert is_cjk('龟') is True  # U+9F9F

    def test_ext_a(self):
        """CJK Ext A: U+3400-U+4DBF"""
        assert is_cjk('\u3400') is True
        assert is_cjk('\u4DB5') is True

    def test_ext_b(self):
        """CJK Ext B: U+20000-U+2A6DF"""
        assert is_cjk('\U00020000') is True
        assert is_cjk('\U0002A6D6') is True

    def test_compat(self):
        """CJK Compat: U+F900-U+FAFF"""
        assert is_cjk('\uF900') is True

    def test_non_cjk(self):
        """非CJK字符应返回 False"""
        assert is_cjk('A') is False
        assert is_cjk('1') is False
        assert is_cjk('，') is False
        assert is_cjk(' ') is False
        assert is_cjk('ア') is False  # 片假名


# ════════════════════════════════════════════════
# 分桶测试
# ════════════════════════════════════════════════

class TestBuckets:
    def test_sent_bucket(self):
        assert _sent_bucket(1) == '短句'
        assert _sent_bucket(12) == '短句'
        assert _sent_bucket(13) == '中句'
        assert _sent_bucket(30) == '中句'
        assert _sent_bucket(31) == '长句'
        assert _sent_bucket(50) == '长句'
        assert _sent_bucket(51) == '超长句'
        assert _sent_bucket(200) == '超长句'

    def test_para_bucket(self):
        assert _para_bucket(1) == '极短'
        assert _para_bucket(30) == '极短'
        assert _para_bucket(31) == '短'
        assert _para_bucket(80) == '短'
        assert _para_bucket(81) == '中'
        assert _para_bucket(200) == '中'
        assert _para_bucket(201) == '长'
        assert _para_bucket(400) == '长'
        assert _para_bucket(401) == '超长'


# ════════════════════════════════════════════════
# classify_rhetoric 测试
# ════════════════════════════════════════════════

class TestClassifyRhetoric:
    def test_simile(self):
        """明喻：像...一样"""
        s = '她的眼睛像星星一样明亮。'
        r = classify_rhetoric(s)
        assert '明喻' in r

    def test_simile_negative(self):
        """非明喻：只有像，没有一样/般"""
        s = '她像是走了很远的路。'
        r = classify_rhetoric(s)
        assert '明喻' not in r

    def test_contrast(self):
        """对比：不是...而是..."""
        s = '这不是勇气，而是愚蠢。'
        r = classify_rhetoric(s)
        assert '对比' in r

    def test_reduplication(self):
        """叠字：多个 AA 叠字"""
        s = '风风雨雨，坎坎坷坷。'
        r = classify_rhetoric(s)
        assert '叠字' in r

    def test_repetition_fuci(self):
        """复辞：不...不..."""
        s = '他不说话不动弹。'
        r = classify_rhetoric(s)
        assert '复辞' in r

    def test_parallelism(self):
        """排比：≥3 短句，长度近似"""
        s = '春天来了，花儿开了，鸟儿唱了，河水流了。'
        r = classify_rhetoric(s)
        assert '排比' in r

    def test_rhetorical_question(self):
        """反问：岂/难道 + 句末问号"""
        s = '难道这还不够明白吗？'
        r = classify_rhetoric(s)
        assert '反问' in r

    def test_rhetorical_question_negative(self):
        """普通问句不应标为反问"""
        s = '你今天吃了什么？'
        r = classify_rhetoric(s)
        assert '反问' not in r

    def test_transition(self):
        """转折"""
        s = '虽然他很努力，但结果却不如人意。'
        r = classify_rhetoric(s)
        assert '转折' in r

    def test_concession(self):
        """让步"""
        s = '即使下了大雨，他们也坚持前行。'
        r = classify_rhetoric(s)
        assert '让步' in r

    def test_exclamation(self):
        """感叹"""
        s = '真是太美了啊！'
        r = classify_rhetoric(s)
        assert '感叹' in r

    def test_causation(self):
        """因果"""
        s = '因为他太累了，所以早早睡下了。'
        r = classify_rhetoric(s)
        assert '因果' in r

    def test_hypothesis(self):
        """假设"""
        s = '如果明天下雨，我们就不去了。'
        r = classify_rhetoric(s)
        assert '假设' in r

    def test_mutual_exclusion(self):
        """互斥：叠字优先级高于复辞"""
        s = '不不不不不不。'  # AA叠字 + 不...不
        r = classify_rhetoric(s)
        # 因为有多个 AA，应该是叠字，不是复辞
        assert not ('叠字' in r and '复辞' in r)


# ════════════════════════════════════════════════
# detect_open 测试
# ════════════════════════════════════════════════

class TestDetectOpen:
    def test_first_person(self):
        assert detect_open('我站在窗前。') == '第一人称起句'

    def test_second_person(self):
        assert detect_open('你看那边的山。') == '第二人称起句'

    def test_third_person(self):
        assert detect_open('他走了很远。') == '第三人称起句'
        assert detect_open('她微微一笑。') == '第三人称起句'

    def test_quote_open(self):
        assert detect_open('"走吧，"他说。') == '引语起句'
        assert detect_open('「你好」她说。') == '引语起句'

    def test_demonstrative_time(self):
        assert detect_open('这时候天已经黑了。') == '指示/时间起句'
        assert detect_open('那天下了很大的雨。') == '指示/时间起句'

    def test_function_word(self):
        assert detect_open('但他还是来了。') == '虚词/连词起句'
        assert detect_open('而那些人早已离去。') == '虚词/连词起句'

    def test_content_word(self):
        assert detect_open('月光洒在地面上。') == '实词起句'
        assert detect_open('风吹过来了。') == '实词起句'

    def test_other(self):
        assert detect_open('') == '其他'
        assert detect_open('123数字开头') == '其他'


# ════════════════════════════════════════════════
# detect_classical 测试
# ════════════════════════════════════════════════

class TestDetectClassical:
    def test_modern_text(self):
        text = '今天天气很好，我和朋友一起去公园散步。花儿开了，鸟儿在唱歌。' * 10
        result = detect_classical(text)
        assert result['is_classical'] is False

    def test_classical_text(self):
        text = '子曰：学而时习之，不亦说乎？有朋自远方来，不亦乐乎？人不知而不愠，不亦君子乎？' * 5
        result = detect_classical(text)
        assert result['is_classical'] is True
        assert result['classical_ratio'] > 2.0
        assert '文言文检测' in result['note']

    def test_empty_text(self):
        result = detect_classical('')
        assert result['is_classical'] is False


# ════════════════════════════════════════════════
# analyze_paragraphs 测试
# ════════════════════════════════════════════════

class TestAnalyzeParagraphs:
    def test_double_newline_split(self):
        text = '第一段内容在这里。\n\n第二段内容在这里。\n\n第三段。'
        result = analyze_paragraphs(text)
        assert result['count'] == 3

    def test_single_newline_fallback(self):
        """单换行文本应 fallback 到单换行切分"""
        text = '第一段内容在这里。\n第二段内容在这里。\n第三段内容也在这里。'
        result = analyze_paragraphs(text)
        assert result['count'] == 3

    def test_single_paragraph_no_newline(self):
        """无换行的单段文本"""
        text = '这是一整段没有任何换行的文字内容。'
        result = analyze_paragraphs(text)
        assert result['count'] == 1

    def test_empty_text(self):
        result = analyze_paragraphs('')
        assert result['count'] == 0


# ════════════════════════════════════════════════
# _get_contexts 测试
# ════════════════════════════════════════════════

class TestGetContexts:
    def test_returns_complete_sentence(self):
        text = '天很蓝。风很大。她走在路上。太阳照着大地。'
        results = _get_contexts(text, '她')
        assert len(results) >= 1
        # 应返回完整句子
        assert '她走在路上。' in results[0]

    def test_max_results(self):
        text = '他来了。他走了。他又来了。他又走了。他再来了。他再走了。'
        results = _get_contexts(text, '他', max_results=3)
        assert len(results) == 3

    def test_target_not_found(self):
        text = '天气很好。阳光明媚。'
        results = _get_contexts(text, '雨')
        assert results == []


# ════════════════════════════════════════════════
# run() 错误路径测试
# ════════════════════════════════════════════════

class TestRunErrors:
    def test_empty_input(self):
        result = run('')
        assert 'error' in result
        assert 'Empty' in result['error']

    def test_whitespace_only(self):
        result = run('   \n\n  ')
        assert 'error' in result

    def test_too_short(self):
        result = run('你好世界')  # 只有4个CJK字符
        assert 'error' in result
        assert 'too short' in result['error']

    def test_non_cjk_text(self):
        result = run('Hello world this is English text without CJK characters.')
        assert 'error' in result


# ════════════════════════════════════════════════
# run() 正常路径 golden output 快照测试
# ════════════════════════════════════════════════

# 约 500 字的中文测试样本
_SAMPLE_TEXT = """
月光如水，洒在青石板路上。她独自走在回家的路上，脚步轻轻的，像是怕惊醒了什么。
两旁的梧桐树叶在风中沙沙作响，偶尔有一片落叶飘下来，打着旋儿落在她的肩上。

她想起了很多事情。想起小时候在这条路上奔跑的样子，想起母亲在门口等她回家的身影，
想起那些再也回不去的日子。时间就像一条河流，平静地流淌着，带走了太多太多。

街灯亮了。昏黄的灯光把她的影子拉得很长很长。她停下脚步，抬头看了看天空。
星星很亮，像是谁洒在天幕上的碎钻石一样闪烁着。她深深地吸了一口气，
继续向前走去。

前方的路还很远。但她知道，只要一直走下去，总会到达那个温暖的地方。
不是因为勇气，而是因为别无选择。有时候，坚持本身就是一种力量。

夜风凉了。她裹紧了外套，加快了脚步。远处传来几声犬吠，打破了夜的寂静。
她的心却渐渐平静下来。

因为她知道，无论多远的路，走着走着就到了。无论多难的日子，过着过着就好了。
这不是安慰，而是经历过风雨之后的领悟。真是太不容易了啊！
""".strip()


class TestRunGolden:
    """验证 run() 在标准样本上的基本输出结构正确"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = run(_SAMPLE_TEXT)

    def test_no_error(self):
        assert 'error' not in self.result

    def test_has_all_sections(self):
        for key in ('chars', 'words', 'sents', 'paras', 'punct', 'meta', 'classical', 'text_preview'):
            assert key in self.result, f"Missing key: {key}"

    def test_no_raw_field(self):
        """v3.3: 不应有 raw 字段"""
        assert 'raw' not in self.result

    def test_text_preview_truncated(self):
        assert len(self.result['text_preview']) <= 501  # 500 + '…'

    def test_meta_fields(self):
        meta = self.result['meta']
        assert meta['engine_version'] == '3.4.0'
        assert meta['total_cjk'] > 100
        assert meta['sent_count'] > 5
        assert meta['para_count'] > 1
        assert meta['text_type'] == '现代文本'
        assert meta['rhythm'] in ('平稳', '起伏', '强烈对比')

    def test_chars_structure(self):
        chars = self.result['chars']
        assert chars['total_cjk'] > 100
        assert chars['unique'] > 50
        assert len(chars['content_freq']) > 0
        assert 'imagery_chars' in chars

    def test_imagery_has_10_categories(self):
        """v3.3: 应检测到多个意象类别（最多10类）"""
        imagery = self.result['chars']['imagery_chars']
        # 样本中应该能命中至少 3 类
        assert len(imagery) >= 3

    def test_sents_structure(self):
        sents = self.result['sents']
        assert sents['count'] > 5
        assert 'note' in sents
        assert len(sents['sents']) == sents['count']
        # 每句应有正确的结构
        first = sents['sents'][0]
        for key in ('id', 'text', 'clen', 'type', 'dialog', 'open', 'rhetoric'):
            assert key in first

    def test_paras_structure(self):
        paras = self.result['paras']
        assert paras['count'] >= 3  # 样本有多段

    def test_classical_detection_modern(self):
        assert self.result['classical']['is_classical'] is False


# ════════════════════════════════════════════════
# verify_quotes 测试
# ════════════════════════════════════════════════

class TestVerifyQuotes:
    def test_no_duplicates(self):
        md = '「第一句」\n「第二句」\n「第三句」'
        result = verify_quotes(md)
        assert result['total'] == 3
        assert result['unique'] == 3
        assert result['duplicates'] == []

    def test_with_duplicates(self):
        md = '「重复的句子」\n「另一句」\n「重复的句子」'
        result = verify_quotes(md)
        assert result['total'] == 3
        assert result['unique'] == 2
        assert '重复的句子' in result['duplicates']

    def test_mixed_quote_styles(self):
        md = '「中文引号」\n\u201c弯引号内容\u201d\n「中文引号」'
        result = verify_quotes(md)
        assert result['total'] == 3
        assert len(result['duplicates']) == 1

    def test_empty_input(self):
        result = verify_quotes('')
        assert result['total'] == 0
        assert result['unique'] == 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
