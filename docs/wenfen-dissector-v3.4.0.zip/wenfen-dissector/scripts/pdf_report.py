#!/usr/bin/env python3
"""
文风拆解器 — PDF 报告生成器 v3.2

直接从 analyze.py 的 JSON 输出构建 reportlab 对象，跳过 Markdown 解析层。
第一部分（基础数据）所有表格从 JSON 直接生成，无 Markdown 中间层。
第二、三部分（语意分析 + 文风诊断）读取 AI 写的 Markdown 散文，解析速度快。

v3.2 变更：
- 修辞格表前加免责说明（统计层为粗粒度模式识别，仅做线索参考）
- 第一部分章节编号修正：概览不占编号，正式章节从「一、字频特征」开始（一-六）
- TOC 拼接改用 sentinel marker（NextPageTemplate('normal')），不再硬编码下标
- _load_md2pdf 清理硬编码私人路径，仅依赖 WENFEN_MD2PDF 环境变量 / scripts/md2pdf.py

用法：
  python pdf_report.py \\
    --stats   stats.json       \\  # analyze.py 的 JSON 输出
    --ai      semantic.md      \\  # AI 写的第二、三部分文字
    --output  report.pdf       \\
    --title   "《XX》文风拆解报告"  \\
    --author  "分析者"           \\
    --theme   warm-academic

依赖：
  pip install reportlab
  md2pdf.py 默认与本文件同目录（即 scripts/md2pdf.py），
  也可通过环境变量 WENFEN_MD2PDF=/path/to/md2pdf.py 显式指定。
"""

import sys, os, json, argparse, re, importlib.util
from pathlib import Path
from datetime import date
from collections import Counter

# ═══════════════════════════════════════════════════════════════════════
# 载入 md2pdf 基础设施
# ═══════════════════════════════════════════════════════════════════════

def _load_md2pdf():
    """在两个候选路径中查找并载入 md2pdf.py。

    优先级：
      1. 环境变量 WENFEN_MD2PDF 指向的文件
      2. 与 pdf_report.py 同目录下的 md2pdf.py（默认 bundle）
    """
    candidates = []
    env_path = os.environ.get("WENFEN_MD2PDF", "").strip()
    if env_path:
        candidates.append(Path(env_path))
    candidates.append(Path(__file__).parent / "md2pdf.py")

    for p in candidates:
        if p and p.exists():
            spec = importlib.util.spec_from_file_location("md2pdf", str(p))
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
    raise ImportError(
        "找不到 md2pdf.py。请将 md2pdf.py 放在 scripts/ 目录下，"
        "或设置环境变量 WENFEN_MD2PDF=/path/to/md2pdf.py。"
    )

_m = _load_md2pdf()

# 从 md2pdf 引入所需符号
register_fonts  = _m.register_fonts
load_theme      = _m.load_theme
THEMES          = _m.THEMES
PDFBuilder      = _m.PDFBuilder
HRule           = _m.HRule
HRuleCentered   = _m.HRuleCentered
ClayDot         = _m.ClayDot
ChapterMark     = _m.ChapterMark
_font_wrap      = _m._font_wrap
_is_cjk         = _m._is_cjk
md_inline       = _m.md_inline
esc             = _m.esc
esc_code        = _m.esc_code
LeftBorderParagraph = _m.LeftBorderParagraph

from reportlab.lib.units import mm
from reportlab.lib.colors import white, HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    Paragraph, Spacer, PageBreak, Table, TableStyle, Flowable
)

# ═══════════════════════════════════════════════════════════════════════
# 辅助：把百分比整合到 N 次（X%）格式
# ═══════════════════════════════════════════════════════════════════════

def _pct(count, total):
    if total <= 0: return "0.0%"
    return f"{count/total*100:.1f}%"

def _fmt(count, total, unit=""):
    return f"{count:,}{unit}（{_pct(count, total)}）"

# ═══════════════════════════════════════════════════════════════════════
# PlotTree Flowable（已移至 scripts/plot_tree.py）
# 当前 SKILL.md 流程未定义 PlotTree 在 semantic.md 中的嵌入语法，
# 待第二部分支持自定义图形语法时从 plot_tree.py 导入启用。
# ═══════════════════════════════════════════════════════════════════════
# from plot_tree import PlotTree  # TODO: enable when semantic.md graph syntax is defined


# ═══════════════════════════════════════════════════════════════════════
# 额外段落样式（用于稀有字/词语境、引句）
# ═══════════════════════════════════════════════════════════════════════

def _make_extra_styles(ST, T, ah):
    """在 PDFBuilder 基础样式之上补充文风报告专用样式。"""
    h_align = ST['part'].alignment
    ST['part_ch'] = ParagraphStyle('PartCh', fontName="Serif", fontSize=22,
        leading=30, textColor=ST['part'].textColor, alignment=h_align,
        spaceBefore=0, spaceAfter=0)
    ST['quote'] = ParagraphStyle('Quote',
        fontName="CJK", fontSize=9, leading=15,
        textColor=T["ink"], leftIndent=12, rightIndent=12,
        spaceBefore=2, spaceAfter=2,
        borderColor=T["accent"], borderWidth=0,
        backColor=T["canvas_sec"])
    ST['label_sm'] = ParagraphStyle('LabelSm',
        fontName="SansBold", fontSize=8, leading=11,
        textColor=T["accent"], spaceBefore=6, spaceAfter=2)
    ST['body_sm'] = ParagraphStyle('BodySm',
        fontName="Sans", fontSize=8.5, leading=13,
        textColor=T["ink"], spaceBefore=1, spaceAfter=1,
        wordWrap='CJK')
    ST['note'] = ParagraphStyle('Note',
        fontName="Sans", fontSize=8, leading=12,
        textColor=T["ink_faded"], spaceBefore=2, spaceAfter=4,
        leftIndent=4, rightIndent=4, wordWrap='CJK')
    ST['concordance_char'] = ParagraphStyle('ConcChar',
        fontName="CJK", fontSize=14, leading=18,
        textColor=T["accent"], alignment=TA_CENTER)
    ST['concordance_ctx'] = ParagraphStyle('ConcCtx',
        fontName="CJK", fontSize=8.5, leading=14,
        textColor=T["ink"], wordWrap='CJK')
    ST['stat_badge'] = ParagraphStyle('Badge',
        fontName="SansBold", fontSize=10, leading=14,
        textColor=T["ink_faded"], alignment=TA_CENTER)
    return ST

# ═══════════════════════════════════════════════════════════════════════
# 表格构建辅助函数
# ═══════════════════════════════════════════════════════════════════════

def _make_table(rows, col_ratios, body_w, ST, T,
                header_bg=None, zebra=True, font_size_override=None):
    ah = f"#{int(T['accent'].red*255):02x}{int(T['accent'].green*255):02x}{int(T['accent'].blue*255):02x}" \
         if hasattr(T['accent'],'red') else "#CC785C"

    total = sum(col_ratios)
    col_w = [(r/total) * (body_w - 4*mm) for r in col_ratios]

    fs = font_size_override or 8
    th_style = ParagraphStyle('th_', fontName="SansBold", fontSize=fs,
                              leading=fs+3, textColor=white, alignment=TA_CENTER,
                              wordWrap='CJK')
    tc_style = ParagraphStyle('tc_', fontName="Sans", fontSize=fs,
                              leading=fs+3, textColor=T["ink"], alignment=TA_LEFT,
                              wordWrap='CJK')

    def _cell(text, is_header=False):
        style = th_style if is_header else tc_style
        return Paragraph(_font_wrap(esc(str(text))), style)

    tdata = []
    for ri, row in enumerate(rows):
        tdata.append([_cell(cell, ri == 0) for cell in row])

    hdr_bg  = header_bg or T["accent"]
    ts_list = [
        ('BACKGROUND', (0,0), (-1,0), hdr_bg),
        ('TEXTCOLOR',  (0,0), (-1,0), white),
        ('GRID',       (0,0), (-1,-1), 0.4, T["border"]),
        ('VALIGN',     (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1), 5),
        ('RIGHTPADDING',(0,0),(-1,-1), 5),
        ('TOPPADDING', (0,0),(-1,-1), 3),
        ('BOTTOMPADDING',(0,0),(-1,-1), 3),
    ]
    if zebra:
        for ri in range(1, len(tdata)):
            bg = white if ri % 2 == 1 else T["canvas_sec"]
            ts_list.append(('BACKGROUND', (0,ri), (-1,ri), bg))

    t = Table(tdata, colWidths=col_w, repeatRows=1)
    t.setStyle(TableStyle(ts_list))
    return t

def _bar(value, max_val, width_mm=30):
    if max_val <= 0: return ""
    filled = int(value / max_val * 8)
    return "█" * filled + "░" * (8 - filled)

# ═══════════════════════════════════════════════════════════════════════
# 第一部分各章节构建函数
# ═══════════════════════════════════════════════════════════════════════

def build_overview(d, story, ST, T, bw, ah):
    """概览数据表（无章节编号，是第一部分的引言数据）。"""
    m  = d["meta"]
    sr = d["sents"]
    pr = d["paras"]
    pu = d["punct"]

    rows = [
        ["指标", "数值"],
        ["总汉字数",         f"{m['total_cjk']:,} 字"],
        ["不重复字种",       f"{m['unique_chars']:,} 种"],
        ["生僻字（仅出现1次）", f"{m['rare_chars']:,} 种（占字种 {_pct(m['rare_chars'], m['unique_chars'])}）"],
        ["总句数",           f"{m['sent_count']:,} 句"],
        ["平均句长",         f"{m['avg_sent_len']} 字/句"],
        ["最长句 / 最短句",  f"{m['max_sent_len']} 字 / {m['min_sent_len']} 字"],
        ["句长方差 · 节奏",  f"{sr['variance']}  ·  {m['rhythm']}"],
        ["含对话句",         f"{sr['dialog_pct']}%"],
        ["段落数",           f"{m['para_count']:,} 段"],
        ["平均段落长",       f"{pr['avg_len']} 字/段"],
        ["平均句数/段",      f"{pr['avg_sc']} 句/段"],
        ["标点密度",         f"{m['punct_density']} 个/百字"],
        ["破折号 / 省略号",  f"{pu['dash_count']} / {pu['ellipsis_count']}"],
    ]
    story.append(_make_table(rows, [0.42, 0.58], bw, ST, T))


def build_char_section(d, story, ST, T, bw, ah):
    """一、字频特征。"""
    chars = d["chars"]
    total = chars["total_cjk"]

    rows = [
        ["类别", "字种数", "占总字种"],
        ["实词字种",
         f"{chars['content_count']:,}",
         _pct(chars['content_count'], chars['unique'])],
        ["虚词字种",
         f"{chars['func_count']:,}",
         _pct(chars['func_count'], chars['unique'])],
        ["生僻字种（出现1次）",
         f"{chars['rare_count']:,}",
         _pct(chars['rare_count'], chars['unique'])],
        ["总字种",
         f"{chars['unique']:,}", "100.0%"],
    ]
    story.append(Paragraph(_font_wrap(esc("1.1  总体字种数据")), ST['h3']))
    story.append(_make_table(rows, [0.48, 0.26, 0.26], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    img = chars.get("imagery_chars", {})
    if img:
        img_total = sum(v["total"] for v in img.values())
        rows = [["意象类别", "次数", "占意象字总量", "高频字"]]
        for cluster, data in sorted(img.items(), key=lambda x: -x[1]["total"]):
            top_chars = "、".join(
                f"{c}({n})" for c, n in
                sorted(data["chars"].items(), key=lambda x: -x[1])[:5]
            )
            rows.append([
                cluster,
                f"{data['total']:,}",
                _pct(data['total'], img_total),
                top_chars,
            ])
        rows.append(["合计", f"{img_total:,}", "100.0%", ""])
        story.append(Paragraph(_font_wrap(esc("1.2  意象字库")), ST['h3']))
        story.append(Paragraph(
            _font_wrap(esc(
                "注：意象字库覆盖 9 类基础意象（身体/颜色/自然/光影/时间/器物/情感/动物/建筑），"
                "繁简体均可。古典诗词、特殊题材的更细分意象建议结合 AI 语意分析层判断。"
            )),
            ST['note']
        ))
        story.append(_make_table(rows, [0.18, 0.14, 0.20, 0.48], bw, ST, T))
        story.append(Spacer(1, 3*mm))

    cf = chars["content_freq"][:20]
    max_n = cf[0][1] if cf else 1
    rows = [["排名", "字", "次数", "占总字", "频率条"]]
    for i, (c, n) in enumerate(cf, 1):
        rows.append([str(i), c, str(n), _pct(n, total), _bar(n, max_n)])
    story.append(Paragraph(_font_wrap(esc("1.3  高频实词字 TOP20")), ST['h3']))
    story.append(_make_table(rows, [0.10, 0.10, 0.14, 0.18, 0.48], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    ff = chars["func_freq"][:10]
    rows = [["排名", "字", "次数", "占总字"]]
    for i, (c, n) in enumerate(ff, 1):
        rows.append([str(i), c, str(n), _pct(n, total)])
    story.append(Paragraph(_font_wrap(esc("1.4  高频虚词字 TOP10")), ST['h3']))
    story.append(_make_table(rows, [0.15, 0.15, 0.20, 0.50], bw, ST, T))


def build_word_section(d, story, ST, T, bw, ah):
    """二、词频与词性。"""
    words = d["words"]
    total_top = sum(n for _, n in words["top_words"]) or 1

    pos_r = words.get("pos_ratios", {})
    pos_d = words.get("pos_dist", {})
    rows = [["词性", "次数", "占比"]]
    for k in ["名词","动词","形容词","副词","代词","数词","成语","惯用语"]:
        cnt = pos_d.get(k, 0)
        if cnt:
            rows.append([k, f"{cnt:,}", f"{pos_r.get(k,0)}%"])
    story.append(Paragraph(_font_wrap(esc("2.1  词性分布")), ST['h3']))
    story.append(_make_table(rows, [0.40, 0.30, 0.30], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    top = words["top_words"][:30]
    max_n = top[0][1] if top else 1
    rows = [["排名", "词", "次数", "占词频", "频率条"]]
    for i, (w, n) in enumerate(top, 1):
        rows.append([str(i), w, str(n), _pct(n, total_top), _bar(n, max_n)])
    story.append(Paragraph(_font_wrap(esc("2.2  高频实词 TOP30")), ST['h3']))
    story.append(_make_table(rows, [0.10, 0.18, 0.14, 0.18, 0.40], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    idioms = words.get("idioms", [])
    if idioms:
        total_idiom = sum(n for _, n in idioms)
        rows = [["成语/惯用语", "次数", "占成语总量"]]
        for w, n in idioms[:20]:
            rows.append([w, str(n), _pct(n, total_idiom)])
        story.append(Paragraph(_font_wrap(esc("2.3  成语与惯用语")), ST['h3']))
        story.append(_make_table(rows, [0.50, 0.25, 0.25], bw, ST, T))
    else:
        story.append(Paragraph(_font_wrap(esc("2.3  成语与惯用语")), ST['h3']))
        story.append(Paragraph("本文未检出成语（jieba 标记为 i 类标签）。", ST['body_sm']))
    story.append(Spacer(1, 3*mm))

    rare_words   = words.get("rare_words", {})
    rare_word_ctx = words.get("rare_word_contexts", {})
    featured  = {w: v for w, v in rare_words.items() if v["level"] == "特色词"}
    low_freq  = {w: v for w, v in rare_words.items() if v["level"] == "低频词"}

    story.append(Paragraph(_font_wrap(esc("2.4  特色词与低频词")), ST['h3']))
    story.append(Paragraph(
        f"特色词（本文高频 + 词典罕见）：{len(featured):,} 个　"
        f"低频词（本文出现≤3次）：{len(low_freq):,} 个",
        ST['body_sm']
    ))
    story.append(Spacer(1, 2*mm))

    if featured:
        rows = [["特色词", "次数", "词典频率", "原文语境"]]
        feat_sorted = sorted(featured.items(), key=lambda x: -x[1]["count"])[:40]
        for w, v in feat_sorted:
            df = v.get("dict_freq", 0)
            df_str = str(df) if df > 0 else "0（词典未收录）"
            ctx_list = rare_word_ctx.get(w, [])
            ctx_first = ctx_list[0] if ctx_list else "—"
            ctx = ctx_first[:45] + ("…" if len(ctx_first) > 45 else "")
            rows.append([w, str(v["count"]), df_str, ctx])
        story.append(Paragraph("特色词（按频次排序）", ST['label_sm']))
        story.append(_make_table(rows, [0.15, 0.08, 0.17, 0.60], bw, ST, T, font_size_override=8))
        story.append(Spacer(1, 3*mm))

    if low_freq:
        rows = [["低频词", "次数", "原文语境"]]
        lf_sorted = sorted(low_freq.items(), key=lambda x: -x[1]["count"])[:30]
        for w, v in lf_sorted:
            ctx_list = rare_word_ctx.get(w, [])
            ctx_first = ctx_list[0] if ctx_list else "—"
            ctx = ctx_first[:55] + ("…" if len(ctx_first) > 55 else "")
            rows.append([w, str(v["count"]), ctx])
        story.append(Paragraph("低频词（按频次排序）", ST['label_sm']))
        story.append(_make_table(rows, [0.15, 0.10, 0.75], bw, ST, T, font_size_override=8))
        story.append(Spacer(1, 3*mm))

    proper_nouns = words.get("proper_nouns", [])
    person_names = words.get("person_names", [])
    if proper_nouns:
        pn_names = set(w for w, _ in (person_names or []))
        nr_items = [(w, c) for w, c in proper_nouns if w in pn_names]
        ns_nz_items = [(w, c) for w, c in proper_nouns if w not in pn_names]

        story.append(Paragraph(_font_wrap(esc("2.5  人名与专有名词")), ST['h3']))
        story.append(Paragraph(
            f"人名：{len(nr_items):,} 个　地名/其他专名：{len(ns_nz_items):,} 个",
            ST['body_sm']
        ))
        story.append(Spacer(1, 2*mm))

        if nr_items:
            rows = [["人名", "出现次数"]]
            for w, c in sorted(nr_items, key=lambda x: -x[1])[:30]:
                rows.append([w, str(c)])
            story.append(Paragraph("人名（按频次排序）", ST['label_sm']))
            story.append(_make_table(rows, [0.55, 0.45], bw, ST, T, font_size_override=8))
            story.append(Spacer(1, 3*mm))

        if ns_nz_items:
            rows = [["地名/专名", "出现次数"]]
            for w, c in sorted(ns_nz_items, key=lambda x: -x[1])[:30]:
                rows.append([w, str(c)])
            story.append(Paragraph("地名/专名（按频次排序）", ST['label_sm']))
            story.append(_make_table(rows, [0.55, 0.45], bw, ST, T, font_size_override=8))
            story.append(Spacer(1, 3*mm))


def build_sentence_section(d, story, ST, T, bw, ah):
    """三、句型分析。"""
    sr = d["sents"]
    total_s = sr["count"] or 1

    # 3.1 句长分布（v3.1：与 analyze.py 的 _sent_bucket 对齐）
    td = sr.get("type_dist", {})
    type_order = [("短句", "≤12字"), ("中句", "13-30字"), ("长句", "31-50字"), ("超长句", ">50字")]
    rows = [["句型", "字数范围", "句数", "占比"]]
    for label, rng in type_order:
        n = td.get(label, 0)
        rows.append([label, rng, str(n), _pct(n, total_s)])
    story.append(Paragraph(_font_wrap(esc("3.1  句长分布")), ST['h3']))
    story.append(_make_table(rows, [0.22, 0.28, 0.22, 0.28], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    rows = [["指标","数值"],
            ["平均句长", f"{sr['avg_len']} 字/句"],
            ["最长句", f"{sr.get('max_len','-')} 字"],
            ["最短句", f"{sr.get('min_len','-')} 字"],
            ["句长方差", f"{sr['variance']}"],
            ["节奏特征", sr['rhythm']],
            ["含对话句", f"{sr.get('dialog_pct', 0)}%"]]
    story.append(Paragraph(_font_wrap(esc("3.2  节奏与对话")), ST['h3']))
    story.append(_make_table(rows, [0.42, 0.58], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    od = sr.get("open_dist", {})
    if od:
        rows = [["句首类型", "句数", "占比"]]
        for label, n in sorted(od.items(), key=lambda x: -x[1]):
            rows.append([label, str(n), _pct(n, total_s)])
        story.append(Paragraph(_font_wrap(esc("3.3  句首类型分布")), ST['h3']))
        story.append(_make_table(rows, [0.40, 0.30, 0.30], bw, ST, T))
        story.append(Spacer(1, 3*mm))

    rd = sr.get("rhet_dist", {})
    if rd:
        story.append(Paragraph(_font_wrap(esc("3.4  修辞格分布（统计层粗粒度识别）")), ST['h3']))
        # v3.2：在表格上方添加免责说明
        story.append(Paragraph(
            _font_wrap(esc(
                "说明：本表为统计引擎基于词法/句法关键字的粗粒度模式识别，用作"
                "第二部分修辞分析（AI 语意层）的线索参考。误报与漏报均存在，"
                "明喻/暗喻、博喻、借代、对偶、顶真、设问/反问等精细辞格的识别"
                "请以语意层结论为准。"
            )),
            ST['note']
        ))
        rows = [["修辞格 / 句间关系", "句数", "占总句"]]
        for label, n in sorted(rd.items(), key=lambda x: -x[1]):
            rows.append([label, str(n), _pct(n, total_s)])
        story.append(_make_table(rows, [0.48, 0.26, 0.26], bw, ST, T))
        story.append(Spacer(1, 3*mm))


def build_paragraph_section(d, story, ST, T, bw, ah):
    """四、段落结构。"""
    pr = d["paras"]
    total_p = pr["count"] or 1

    bd = pr.get("bucket_dist", {})
    rows = [["长度等级","字数范围","段数","占比"]]
    order = ["极短","短","中","长","超长"]
    ranges = {"极短":"≤30","短":"31-80","中":"81-200","长":"201-400","超长":">400"}
    for label in order:
        n = bd.get(label, 0)
        if n:
            rows.append([label, f"{ranges[label]}字", str(n), _pct(n, total_p)])
    story.append(Paragraph(_font_wrap(esc("4.1  段落长度分布")), ST['h3']))
    story.append(_make_table(rows, [0.36, 0.24, 0.20, 0.20], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    rows = [["指标","数值"],
            ["段落数", f"{pr['count']:,} 段"],
            ["平均段落长", f"{pr['avg_len']} 字/段"],
            ["平均句数/段", f"{pr['avg_sc']} 句/段"],
            ["最长段落", f"{pr['max_len']} 字"],
            ["最短段落", f"{pr['min_len']} 字"],
            ["单句段", f"{pr.get('single_sent',0)} 段（{_pct(pr.get('single_sent',0), total_p)}）"]]
    story.append(Paragraph(_font_wrap(esc("4.2  关键段落数据")), ST['h3']))
    story.append(_make_table(rows, [0.42, 0.58], bw, ST, T))


def build_punctuation_section(d, story, ST, T, bw, ah):
    """五、标点符号。"""
    pu = d["punct"]
    total_p = pu["total"] or 1
    NAMES = {
        "，":"逗号","。":"句号","！":"叹号","？":"问号","；":"分号",
        "：":"冒号","、":"顿号","…":"省略号","—":"破折号",
        "“":"引号开","”":"引号闭","‘":"单引号开","’":"单引号闭",
        "「":"直角引号开","」":"直角引号闭","『":"双直角引号开","』":"双直角引号闭",
        "（":"括号开","）":"括号闭","【":"方括号开","】":"方括号闭",
        "《":"书名开","》":"书名闭","〈":"单书名开","〉":"单书名闭",
        "·":"间隔号","～":"波浪号",
    }
    rows = [["标点","名称","次数","占标点总量"]]
    for p, n in sorted(pu["counts"].items(), key=lambda x:-x[1]):
        rows.append([p, NAMES.get(p,""), str(n), _pct(n, total_p)])
    rows.append(["合计","", f"{total_p:,}", "100.0%"])
    story.append(Paragraph(_font_wrap(esc("5.1  标点分布")), ST['h3']))
    story.append(_make_table(rows, [0.15, 0.25, 0.25, 0.35], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    dc = pu.get("dash_contexts", [])
    if dc:
        story.append(Paragraph(_font_wrap(esc("5.2  破折号语境")), ST['h3']))
        for ctx in dc:
            story.append(Paragraph(f"“{_font_wrap(esc(ctx))}”", ST['quote']))
            story.append(Spacer(1, 1*mm))
    else:
        story.append(Paragraph(_font_wrap(esc("5.2  破折号语境")), ST['h3']))
        story.append(Paragraph("本文未使用破折号（—）。", ST['body_sm']))

    story.append(Spacer(1, 2*mm))

    ec = pu.get("ellipsis_contexts", [])
    if ec:
        story.append(Paragraph(_font_wrap(esc("5.3  省略号语境")), ST['h3']))
        for ctx in ec:
            story.append(Paragraph(f"“{_font_wrap(esc(ctx))}”", ST['quote']))
            story.append(Spacer(1, 1*mm))
    else:
        story.append(Paragraph(_font_wrap(esc("5.3  省略号语境")), ST['h3']))
        story.append(Paragraph("本文未使用省略号（…）。", ST['body_sm']))


# ═══════════════════════════════════════════════════════════════════════
# 稀有字
# ═══════════════════════════════════════════════════════════════════════

def build_rare_section(d, story, ST, T, bw, ah):
    """六、稀有字。"""
    chars = d["chars"]
    rare_chars   = chars.get("rare", [])
    rare_ctx     = chars.get("rare_char_contexts", {})

    story.append(Paragraph(_font_wrap(esc("6.1  稀有字（全文仅出现1次）")), ST['h3']))
    story.append(Paragraph(
        f"共 {len(rare_chars):,} 种（占全部字种 "
        f"{_pct(len(rare_chars), chars['unique'])}）。",
        ST['body_sm']
    ))
    story.append(Spacer(1, 2*mm))

    ctx_pairs = [(c, rare_ctx.get(c, [])) for c in rare_chars if rare_ctx.get(c)][:40]
    if ctx_pairs:
        rows = [["稀有字", "原文语境"]]
        for c, ctxs in ctx_pairs:
            rows.append([c, ctxs[0][:60] + ("…" if len(ctxs[0]) > 60 else "")])
        story.append(_make_table(rows, [0.10, 0.90], bw, ST, T, font_size_override=8))


# ═══════════════════════════════════════════════════════════════════════
# Sentinel marker for TOC insertion
# ═══════════════════════════════════════════════════════════════════════

class _TOCInsertionMarker(Flowable):
    """A no-op flowable marking where TOC content should be inserted.

    Replaces the v3.1 hard-coded `story[:3] + toc + [story[3]] + story[5:]`
    slicing approach. Flowing through this marker is a no-op (zero-size draw),
    so it is safe to leave in the story even if no TOC is generated.
    """
    def __init__(self):
        Flowable.__init__(self)
        self.width = 0
        self.height = 0
    def wrap(self, *args, **kwargs):
        return (0, 0)
    def draw(self):
        pass


# ═══════════════════════════════════════════════════════════════════════
# 主构建器
# ═══════════════════════════════════════════════════════════════════════

class WenfenPDFBuilder(PDFBuilder):
    """
    继承 PDFBuilder，重写 build() 以直接消费 analyze.py 的 JSON，
    跳过第一部分的 Markdown 解析。
    """

    def build_from_data(self, stats: dict, ai_md: str, output_path: str):
        register_fonts()
        T  = self.T
        ST = self.ST
        bw = self.body_w
        ah = self.accent_hex
        _make_extra_styles(ST, T, ah)

        story = []

        from reportlab.platypus import (BaseDocTemplate, PageTemplate,
                                        NextPageTemplate, Frame)

        body_frame = Frame(self.lm, self.bm, bw, self.body_h, id='body')
        full_frame = Frame(0, 0, self.page_w, self.page_h,
            leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0, id='full')

        doc = BaseDocTemplate(
            output_path,
            pagesize=(self.page_w, self.page_h),
            leftMargin=self.lm, rightMargin=self.rm,
            topMargin=self.tm, bottomMargin=self.bm,
            title=self.cfg.get("title",""),
            author=self.cfg.get("author",""))

        templates = []
        has_cover = self.cfg.get("cover", True)
        has_toc   = self.cfg.get("toc", True)
        if has_cover:
            templates.append(PageTemplate(id='cover', frames=[full_frame],
                                          onPage=self._cover_page))
        if has_toc:
            templates.append(PageTemplate(id='toc', frames=[body_frame],
                                          onPage=self._toc_page))
        templates.append(PageTemplate(id='normal', frames=[body_frame],
                                      onPage=self._normal_page))

        # ── 封面 ──
        if has_cover:
            story.append(Spacer(1, self.page_h))

        # ── TOC 页面准备 + 占位标记 ──
        if has_toc:
            story.append(NextPageTemplate('toc'))
            story.append(PageBreak())
            # 此处插入实际 TOC 内容（在收集完所有 toc_entries 之后）
            toc_marker = _TOCInsertionMarker()
            story.append(toc_marker)

        # ── 切回正常页 ──
        story.append(NextPageTemplate('normal'))

        toc_entries = []

        def _part(title):
            cm = ChapterMark(title, level=0)
            story.append(PageBreak())
            story.append(cm)
            story.append(Spacer(1, self.body_h * 0.35))
            story.append(HRuleCentered(bw, 40*mm, 0.8, T["accent"]))
            story.append(Spacer(1, 8*mm))
            story.append(Paragraph(_font_wrap(esc(title)), ST['part_ch']))
            story.append(Spacer(1, 8*mm))
            story.append(HRuleCentered(bw, 25*mm, 0.8, T["accent"]))
            toc_entries.append(('part', title, cm.key))

        def _chapter(title):
            cm = ChapterMark(title, level=1)
            story.append(PageBreak())
            story.append(cm)
            story.append(Spacer(1, self.body_h * 0.28))
            story.append(Paragraph(_font_wrap(esc(title)), ST['chapter']))
            story.append(Spacer(1, 5*mm))
            story.append(HRuleCentered(bw, 35*mm, 1.2, T["accent"]))
            toc_entries.append(('chapter', title, cm.key))

        def _section(title):
            """无章节编号的前置小节（如概览）。"""
            story.append(Spacer(1, 4*mm))
            story.append(Paragraph(_font_wrap(esc(title)), ST['chapter']))
            story.append(Spacer(1, 4*mm))
            story.append(HRuleCentered(bw, 35*mm, 1.2, T["accent"]))
            story.append(Spacer(1, 4*mm))

        # ════════════════════════════════════════════════
        # 第一部分：基础数据（直接从 JSON 构建）
        # 章节编号：一-六（概览不占编号，作为引言数据）
        # ════════════════════════════════════════════════
        _part("第一部分：基礎數據")

        # 概览：不占编号，紧跟第一部分扉页
        _section("概覽數據")
        build_overview(stats, story, ST, T, bw, ah)

        _chapter("一、字頻特徵")
        build_char_section(stats, story, ST, T, bw, ah)

        _chapter("二、詞頻與詞性")
        build_word_section(stats, story, ST, T, bw, ah)

        _chapter("三、句型分析")
        build_sentence_section(stats, story, ST, T, bw, ah)

        _chapter("四、段落結構")
        build_paragraph_section(stats, story, ST, T, bw, ah)

        _chapter("五、標點符號")
        build_punctuation_section(stats, story, ST, T, bw, ah)

        _chapter("六、稀有字")
        build_rare_section(stats, story, ST, T, bw, ah)

        # ════════════════════════════════════════════════
        # 第二、三部分：AI 语意分析（解析简单 Markdown 散文）
        # AI 在 semantic.md 中应使用「七、意象系统」「八、敘述聲音」等编号，
        # 与第一部分的一-六衔接。
        # ════════════════════════════════════════════════
        if ai_md.strip():
            ai_story, ai_toc = self.parse_md(ai_md)
            for entry in ai_toc:
                toc_entries.append(entry)
            story.extend(ai_story)

        # ════════════════════════════════════════════════
        # 用 TOC 替换 marker（非脆弱方式：按对象身份查找）
        # ════════════════════════════════════════════════
        if has_toc and toc_entries:
            toc_story = self._build_toc_from_entries(toc_entries, bw, ST, T, ah)
            full_story = []
            for item in story:
                if item is toc_marker:
                    full_story.extend(toc_story)
                else:
                    full_story.append(item)
        else:
            # 移除 marker（如果存在）以避免空白干扰
            full_story = [item for item in story
                          if not isinstance(item, _TOCInsertionMarker)]

        doc.addPageTemplates(templates)
        print(f"[pdf_report] 构建 PDF：{len(full_story)} 个元素")
        doc.build(full_story)
        size = os.path.getsize(output_path)
        print(f"[pdf_report] 完成：{output_path}（{size/1024:.0f} KB）")

    def _build_toc_from_entries(self, entries, bw, ST, T, ah):
        """直接从 toc_entries 列表构建目录，不依赖 Markdown 解析。"""
        ink = T["ink"]
        ink_hex = f"#{int(ink.red*255):02x}{int(ink.green*255):02x}{int(ink.blue*255):02x}" \
                  if hasattr(ink,'red') else "#181818"
        s = [Spacer(1, 15*mm)]
        s.append(Paragraph(_font_wrap("目    錄"), ST['part']))
        s.append(HRule(bw * 0.12, 1, T["accent"]))
        s.append(Spacer(1, 8*mm))
        for etype, title, key in entries:
            style = ST['toc1'] if etype == 'part' else ST['toc2']
            linked = f"<a href=\"#{key}\" color=\"{ink_hex}\">{_font_wrap(esc(title))}</a>"
            s.append(Paragraph(linked, style))
        return s


# ═══════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(description="文风拆解器 PDF 报告生成器")
    ap.add_argument("--stats",   "-s", required=True,
                    help="analyze.py 的 JSON 输出路径")
    ap.add_argument("--ai",      "-a", default="",
                    help="AI 写的第二、三部分 Markdown 文件路径（可选）")
    ap.add_argument("--output",  "-o", default="wenfen_report.pdf",
                    help="輸出 PDF 路徑")
    ap.add_argument("--title",   default="",  help="封面標題")
    ap.add_argument("--subtitle",default="",  help="封面副標題")
    ap.add_argument("--author",  default="",  help="作者/分析者")
    ap.add_argument("--date",    default=str(date.today()), help="日期")
    ap.add_argument("--theme",   default="warm-academic",
                    help=f"主题（{', '.join(THEMES.keys())}）")
    ap.add_argument("--no-cover",action="store_true", help="不生成封面")
    ap.add_argument("--no-toc",  action="store_true", help="不生成目錄")
    ap.add_argument("--watermark",default="",  help="水印文字")
    args = ap.parse_args()

    with open(args.stats, encoding="utf-8") as f:
        stats = json.load(f)

    ai_md = ""
    if args.ai and Path(args.ai).exists():
        with open(args.ai, encoding="utf-8") as f:
            ai_md = f.read()

    title = args.title or f"文风拆解报告"
    m = stats.get("meta", {})
    stats_line  = (f"总汉字 {m.get('total_cjk',0):,} · "
                   f"句数 {m.get('sent_count',0):,} · "
                   f"段落 {m.get('para_count',0):,}")
    stats_line2 = (f"平均句长 {m.get('avg_sent_len',0)} 字 · "
                   f"节奏：{m.get('rhythm','')} · "
                   f"标点密度 {m.get('punct_density',0)}%")

    theme = load_theme(args.theme)
    a = theme['accent']
    accent_hex = (f"#{int(a.red*255):02x}{int(a.green*255):02x}{int(a.blue*255):02x}"
                  if hasattr(a,'red') else "#CC785C")

    from reportlab.lib.pagesizes import A4
    config = {
        "title":       title,
        "subtitle":    args.subtitle,
        "author":      args.author,
        "date":        args.date,
        "watermark":   args.watermark,
        "theme":       theme,
        "accent_hex":  accent_hex,
        "cover":       not args.no_cover,
        "toc":         not args.no_toc,
        "page_size":   A4,
        "header_title":title,
        "footer_left": args.author,
        "stats_line":  stats_line,
        "stats_line2": stats_line2,
    }

    builder = WenfenPDFBuilder(config)
    builder.build_from_data(stats, ai_md, args.output)


if __name__ == "__main__":
    main()
