#!/usr/bin/env python3
"""
文风拆解器 — 全书分析引擎（实用版）

策略：采样 + 快速统计
- 每章：快速基本统计（O(n)，秒级）
- 采样10章：完整 analyze.run()（深度分析）
- 全书：快速线性统计
"""

import sys
import json
import re
from pathlib import Path
from datetime import datetime
from collections import Counter

# 使用相对路径
SKILL_SCRIPTS = Path(__file__).parent
sys.path.insert(0, str(SKILL_SCRIPTS))
import analyze

try:
    from ebooklib import epub
    # ebooklib 在新版本中提供 ITEM_DOCUMENT 常量；旧版（< 0.18）需 fallback
    try:
        from ebooklib import ITEM_DOCUMENT
    except ImportError:
        ITEM_DOCUMENT = 9  # ebooklib < 0.18 的 enum 数值
except ImportError:
    print("[WARN] ebooklib not found.")
    ITEM_DOCUMENT = 9


# v3.2: 统一使用 analyze.is_cjk（覆盖 Basic + Ext A + Ext B + Compat），
# 不再在本文件局部重定义。
is_cjk = analyze.is_cjk


def basic_stats(text: str) -> dict:
    """单章快速基本统计（O(n)，无 ngram position 追踪）"""
    cjk = [c for c in text if is_cjk(c)]
    char_freq = Counter(cjk)
    # v3.2: 与 analyze.py 的句子切分保持一致（允许单字句）
    sents = re.findall(r'[^。！？\n]+[。！？…]+', text)
    paras = [p.strip() for p in text.split('\n\n') if p.strip()]
    return {
        'total_cjk': len(cjk),
        'unique_chars': len(char_freq),
        'sent_count': len(sents),
        'para_count': len(paras),
        'avg_sent_len': round(len(cjk) / max(len(sents), 1), 1),
        'top_chars': char_freq.most_common(15),
    }


def full_analyze(text: str) -> dict:
    """单章完整分析（analyze.run，有 position 追踪）"""
    return analyze.run(text)


def extract_epub(epub_path):
    book = epub.read_epub(str(epub_path))
    chapters = []
    for item in book.get_items():
        # v3.2: 用 ITEM_DOCUMENT 常量替代魔数 9
        if item.get_type() == ITEM_DOCUMENT:
            raw = item.get_content().decode('utf-8', errors='ignore')
            raw = re.sub(r'<script[^>]*>.*?</script>', '', raw, flags=re.DOTALL)
            raw = re.sub(r'<style[^>]*>.*?</style>', '', raw, flags=re.DOTALL)
            # v3.3: 优先从 <h1>-<h3> 或 <title> 标签提取章节标题
            title_match = re.search(r'<h[1-3][^>]*>(.*?)</h[1-3]>', raw, re.DOTALL)
            if not title_match:
                title_match = re.search(r'<title[^>]*>(.*?)</title>', raw, re.DOTALL)
            text = re.sub(r'</p>', '\n', raw)
            text = re.sub(r'<[^>]+>', '', text)
            text = re.sub(r'[ \t]+', ' ', text)
            text = re.sub(r'\n{3,}', '\n\n', text).strip()
            if len(text) < 200:
                continue
            # 标题提取：优先用 HTML 标题标签，fallback 到正文前60字
            if title_match:
                title = re.sub(r'<[^>]+>', '', title_match.group(1)).strip()[:60]
            else:
                title = text[:60].replace('\n', ' ').strip()
            if len(title) > 47:
                title = title[:47] + '...'
            chapters.append({'title': title, 'text': text, 'size': len(text)})
    return chapters


def pick_sample_chapters(chapters, n=10):
    """选择代表性章节：均匀采样 + 长度加权。

    v3.2：当章节数 < n 时，安全降级为返回所有章节索引；
    避免 v3.1 旧实现在 n < 4 时触发 IndexError。
    """
    total = len(chapters)
    if total == 0:
        return []
    if total <= n:
        return list(range(total))
    # 均匀采样
    step = total / n
    sampled = []
    for i in range(n):
        idx = min(int(i * step), total - 1)
        sampled.append(idx)
    # 强化覆盖：开头/前 10%/后 10%/结尾
    sampled[0] = 0
    sampled[1] = max(1, total // 10)
    sampled[-2] = max(0, total - total // 10)
    sampled[-1] = max(0, total - 1)
    return sorted(set(sampled))


def analyze_book(epub_path: str, output_dir: str = None):
    epub_path = Path(epub_path)
    out_dir = Path(output_dir) if output_dir else Path("/tmp/wenfen_book")
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"正在提取：{epub_path.name}")
    chapters = extract_epub(epub_path)
    total_chapters = len(chapters)
    total_size = sum(c['size'] for c in chapters)
    print(f"提取到 {total_chapters} 个章节，总计 {total_size:,} 字")

    # Save raw
    raw_out = out_dir / "chapters_raw.json"
    with open(raw_out, 'w', encoding='utf-8') as f:
        json.dump(chapters, f, ensure_ascii=False)
    print(f"原始章节已保存（{raw_out.stat().st_size // 1024}KB）")

    # ── Step 1: 全章节基本统计（快速） ──
    print(f"\nStep 1：基本统计（{total_chapters} 章）...")
    chapter_stats = []
    global_word_freq = Counter()
    global_char_freq = Counter()

    for i, chap in enumerate(chapters):
        bs = basic_stats(chap['text'])
        # Aggregate
        for c, cnt in bs['top_chars']:
            global_char_freq[c] += cnt
        chapter_stats.append({
            'index': i,
            'title': chap['title'][:80],
            'cjk': bs['total_cjk'],
            'sent_count': bs['sent_count'],
            'para_count': bs['para_count'],
            'avg_sent_len': bs['avg_sent_len'],
            'unique_chars': bs['unique_chars'],
            'top_chars': bs['top_chars'][:5],
        })
        if (i + 1) % 20 == 0:
            print(f"  {i+1}/{total_chapters}")

    print(f"基本统计完成")

    # ── Step 2: 采样10章完整分析 ──
    sample_indices = pick_sample_chapters(chapters, n=10)
    print(f"\nStep 2：采样 {len(sample_indices)} 章完整分析...")
    sample_stats = {}
    for idx in sample_indices:
        chap = chapters[idx]
        print(f"  分析章节 {idx+1}（{chap['title'][:40]}...）")
        stats = full_analyze(chap['text'])
        sample_stats[idx] = stats
        meta = stats.get('meta', {})
        # 记录节奏和对话比
        chapter_stats[idx]['rhythm'] = meta.get('rhythm', '')
        chapter_stats[idx]['dialog_pct'] = round(meta.get('dialog_pct', 0), 1)
        chapter_stats[idx]['top_words'] = stats.get('words', {}).get('top_words', [])[:5]
        # 更新全局词频
        for w, cnt in stats.get('words', {}).get('top_words', []):
            global_word_freq[w] += cnt

    # 估算未采样章节的节奏（用平均值）
    sampled_rhythms = [chapter_stats[i]['rhythm'] for i in sample_indices if chapter_stats[i].get('rhythm')]
    rhythm_dist = Counter(sampled_rhythms)
    most_common_rhythm = rhythm_dist.most_common(1)[0][0] if rhythm_dist else ''

    for cs in chapter_stats:
        if 'rhythm' not in cs:
            cs['rhythm'] = most_common_rhythm
        if 'dialog_pct' not in cs:
            cs['dialog_pct'] = 0

    # ── Step 3: 全书快速统计 ──
    print("\nStep 3：全书统计...")
    full_text = '\n\n'.join(c['text'] for c in chapters)
    full_bs = basic_stats(full_text)

    total_cjk = sum(cs['cjk'] for cs in chapter_stats)
    total_sents = sum(cs['sent_count'] for cs in chapter_stats)

    bundle = {
        'book': {
            'name': epub_path.stem,
            'total_chapters': total_chapters,
            'total_cjk': total_cjk,
            'total_sents': total_sents,
            'unique_chars': full_bs['unique_chars'],
            'avg_sent_len': round(total_cjk / max(total_sents, 1), 1),
            'rhythm': most_common_rhythm,
            'dialog_pct': round(
                sum(cs['dialog_pct'] for cs in chapter_stats if 'dialog_pct' in cs)
                / max(len([cs for cs in chapter_stats if 'dialog_pct' in cs]), 1), 1),
        },
        'chapter_stats': chapter_stats,
        'sample_stats': {
            idx: {
                'meta': stats.get('meta', {}),
                'top_words': stats.get('words', {}).get('top_words', [])[:10],
                'top_chars': stats.get('chars', {}).get('content_freq', [])[:10],
                'sents_rhythm': stats.get('sents', {}).get('rhythm', ''),
            }
            for idx, stats in sample_stats.items()
        },
        'top_words_global': global_word_freq.most_common(30),
        'top_chars_global': global_char_freq.most_common(20),
        'sample_indices': sample_indices,
        'generated_at': datetime.now().isoformat(),
    }

    bundle_out = out_dir / "book_stats_bundle.json"
    with open(bundle_out, 'w', encoding='utf-8') as f:
        json.dump(bundle, f, ensure_ascii=False, indent=2)

    print(f"\n{'='*50}")
    print(f"《{epub_path.stem}》分析完成")
    print(f"{'='*50}")
    print(f"总汉字：{total_cjk:,}")
    print(f"总句数：{total_sents:,}")
    print(f"总章节：{total_chapters}")
    print(f"平均句长：{bundle['book']['avg_sent_len']}字")
    print(f"主节奏：{most_common_rhythm}")
    print(f"采样章节：{sample_indices}")
    print(f"输出：{bundle_out}")

    return bundle


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 epub_analyzer.py <book.epub> [output_dir]")
        sys.exit(1)
    analyze_book(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
