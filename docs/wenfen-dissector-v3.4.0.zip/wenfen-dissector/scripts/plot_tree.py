#!/usr/bin/env python3
"""
文风拆解器 — PlotTree Flowable（情节流程图）

当前状态：预留代码资产。SKILL.md 尚未定义 semantic.md 内嵌图形语法
（如 `:::plot type=ascending` 围栏块），因此本模块暂未被 pdf_report.py 调用。

待启用条件：
1. 在 SKILL.md 中定义 semantic.md 内的图形语法
2. 在 pdf_report.py 的 parse_md() 中识别该语法并调用 PlotTree

用法示例（未来）：
    from plot_tree import PlotTree
    nodes = [
        ("起始", "#4CAF50", "主角出场"),
        ("冲突", "#FF9800", "遇到障碍"),
        ("高潮", "#F44336", "最终对决"),
        ("结局", "#2196F3", "回归平静"),
    ]
    tree = PlotTree(nodes, body_w=160*mm, theme=T, arc_type='ascending')
    story.append(tree)
"""

from reportlab.lib.units import mm
from reportlab.lib.colors import white, HexColor
from reportlab.platypus import Flowable


class PlotTree(Flowable):
    """
    自适应情节流程图——根据情节类型使用不同节点标签和弧线形态。
    支持弯曲/上升/下降/颠覆/螺旋等箭头样式。

    Parameters:
        nodes: list of (label, color_hex, caption) tuples
        body_w: float, available body width in points
        theme: dict, theme color dictionary (needs 'border', 'ink_faded')
        arc_type: str, one of 'linear' | 'ascending' | 'descending' | 'subvert' | 'spiral'
    """
    def __init__(self, nodes, body_w, theme, arc_type='linear'):
        Flowable.__init__(self)
        self._nodes    = nodes
        self._body_w   = body_w
        self._theme    = theme
        self._arc_type = arc_type
        n = len(self._nodes)
        self._box_w    = min(36*mm, (body_w - (n-1)*8*mm) / max(n, 1))
        self._box_h    = 14*mm
        self._total_w  = n * self._box_w + (n-1) * 8*mm
        max_offset = max(abs(o) for o in self._get_y_offsets(n)) if n > 0 else 0
        self._total_h  = self._box_h + 14*mm + max_offset * 2
        self.width     = body_w
        self.height    = self._total_h + 6*mm

    def _draw_arrow(self, c, x1, y1, x2, y2):
        """绘制带箭头的连接线，根据弧线类型决定形状。"""
        import math
        T = self._theme

        if self._arc_type == 'linear':
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            c.line(x1, y1, x2, y2)
            self._arrowhead(c, x2, y2, 0)

        elif self._arc_type == 'ascending':
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            mid_x = (x1 + x2) / 2
            mid_y = max(y1, y2) + 3*mm
            p = c.beginPath()
            p.moveTo(x1, y1)
            p.curveTo(mid_x, mid_y, mid_x, mid_y, x2, y2)
            c.drawPath(p, fill=0, stroke=1)
            angle = math.atan2(y2 - mid_y, x2 - mid_x)
            self._arrowhead(c, x2, y2, angle)

        elif self._arc_type == 'descending':
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            mid_x = (x1 + x2) / 2
            mid_y = min(y1, y2) - 3*mm
            p = c.beginPath()
            p.moveTo(x1, y1)
            p.curveTo(mid_x, mid_y, mid_x, mid_y, x2, y2)
            c.drawPath(p, fill=0, stroke=1)
            angle = math.atan2(y2 - mid_y, x2 - mid_x)
            self._arrowhead(c, x2, y2, angle)

        elif self._arc_type == 'subvert':
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            mid_x = (x1 + x2) / 2
            p = c.beginPath()
            p.moveTo(x1, y1)
            p.curveTo(x1 + 2*mm, y1 + 4*mm, x2 - 2*mm, y2 + 4*mm, mid_x, y1)
            p.curveTo(mid_x, y1 - 5*mm, mid_x, y1 - 5*mm, x2, y2)
            c.drawPath(p, fill=0, stroke=1)
            self._arrowhead(c, x2, y2, -0.3)

        elif self._arc_type == 'spiral':
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            seg = 3
            dx = (x2 - x1) / seg
            dy = 2.5*mm
            p = c.beginPath()
            p.moveTo(x1, y1)
            for s in range(seg):
                sx = x1 + dx * s
                ex = x1 + dx * (s + 1)
                cy = y1 + dy * (1 if s % 2 == 0 else -1)
                p.curveTo(sx + dx*0.3, cy, ex - dx*0.3, cy, ex, y1)
            c.drawPath(p, fill=0, stroke=1)
            self._arrowhead(c, x2, y2, 0)
        else:
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            c.line(x1, y1, x2, y2)
            self._arrowhead(c, x2, y2, 0)

    def _arrowhead(self, c, x, y, angle):
        import math
        c.setFillColor(self._theme["border"])
        size = 1.5*mm
        p = c.beginPath()
        p.moveTo(x, y)
        p.lineTo(x - size * math.cos(angle - 0.4), y - size * math.sin(angle - 0.4))
        p.lineTo(x - size * math.cos(angle + 0.4), y - size * math.sin(angle + 0.4))
        p.close()
        c.drawPath(p, fill=1, stroke=0)

    def draw(self):
        import math
        c = self.canv
        T = self._theme
        n = len(self._nodes)
        x_start = (self._body_w - self._total_w) / 2
        bh = self._box_h

        y_offsets = self._get_y_offsets(n)

        for i, (label, color_hex, caption) in enumerate(self._nodes):
            x = x_start + i * (self._box_w + 8*mm)
            y_off = y_offsets[i] if i < len(y_offsets) else 0
            y = self.height - bh - 2*mm + y_off

            # Shadow
            c.setFillColor(HexColor("#E0E0E0"))
            c.roundRect(x + 0.5*mm, y - 0.5*mm, self._box_w, bh, 3*mm, fill=1, stroke=0)

            # Node box
            c.setFillColor(HexColor(color_hex))
            c.setStrokeColor(HexColor(color_hex))
            c.roundRect(x, y, self._box_w, bh, 3*mm, fill=1, stroke=0)

            # Label
            c.setFillColor(white)
            c.setFont("CJK", 9)
            c.drawCentredString(x + self._box_w/2, y + bh/2 - 3, label)

            # Caption
            if caption:
                c.setFillColor(T["ink_faded"])
                c.setFont("CJK", 7)
                cap = caption[:16] + "..." if len(caption) > 17 else caption
                c.drawCentredString(x + self._box_w/2, y - 8, cap)

            # Arrow to next
            if i < n - 1:
                ax = x + self._box_w + 1*mm
                ay = self.height - bh/2 - 2*mm + (y_off + (y_offsets[i+1] if i+1 < len(y_offsets) else 0)) / 2
                ax2 = x_start + (i+1) * (self._box_w + 8*mm) - 1*mm
                self._draw_arrow(c, ax, ay, ax2, ay)

        # Arc type label
        arc_labels = {
            'linear': '',
            'ascending': '─── 上升弧线 ───',
            'descending': '─── 下降弧线 ───',
            'subvert': '─── 颠覆弧线 ───',
            'spiral': '─── 螺旋弧线 ───',
        }
        lbl = arc_labels.get(self._arc_type, '')
        if lbl:
            c.setFillColor(T["ink_faded"])
            c.setFont("CJK", 7)
            c.drawCentredString(self._body_w / 2, self.height - self._total_h + 1*mm, lbl)

    def _get_y_offsets(self, n):
        """根据弧线类型返回每个节点的垂直偏移。"""
        if self._arc_type == 'ascending':
            step = 2.0 * mm / max(n - 1, 1)
            return [(-i * step) for i in range(n)]
        elif self._arc_type == 'descending':
            step = 2.0 * mm / max(n - 1, 1)
            return [(i * step) for i in range(n)]
        elif self._arc_type == 'subvert':
            offsets = []
            peak = n * 0.4
            for i in range(n):
                if i <= peak:
                    offsets.append(-i * 2.5 * mm / max(peak, 1))
                else:
                    fall = (i - peak) / max(n - 1 - peak, 1)
                    offsets.append(-(peak * 2.5 * mm / max(peak, 1)) + fall * 5.5 * mm)
            return offsets
        elif self._arc_type == 'spiral':
            offsets = []
            for i in range(n):
                amp = 1.5 + i * 0.5
                offsets.append(amp * mm * (1 if i % 2 == 0 else -1))
            return offsets
        return [0] * n
