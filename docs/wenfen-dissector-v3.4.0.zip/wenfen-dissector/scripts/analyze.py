#!/usr/bin/env python3
"""
文风拆解器 — 统计分析引擎 v3.4
Usage: python3 analyze.py <text_file> [--names "人名1,人名2,..."]
       echo "文本" | python3 analyze.py [--names "人名1,人名2,..."]
Output: JSON to stdout

v3.4 变更：
- 修复 jieba 分词边界错误：「人会」「问法」等跨边界粘连伪词
- 强化 _is_segmented_pseudo 检测：新增基于上下文的伪词检测
  （当 jieba 词典中存在微弱频率但实际为分词错误的词）
- 新增「动词+人名首字」粘连检测 _detect_verb_name_adhesion：
  检查双字词后面是否高比例跟随同一个人名后缀→判定为分词错误
- 新增 --names CLI 参数：允许用户注入人名列表到 jieba 词典，
  从根本上避免外国人名导致的粘连错误
- 新增 _filter_pseudo_words 后处理器，统一管理伪词过滤管线

v3.3 变更（保留）：
- 段落切分增加单换行 fallback（修复 EPUB/TXT 中仅用单换行分段的情况）
- _get_contexts 改为基于完整句子匹配，保证返回含上下文的完整句
- run() 不再输出 raw 字段（避免 JSON 过大），改为 text_preview（前500字）
- detect_open 细化为 8 种句首类型（区分人称、引语、时间/指示等）
- 新增文言文检测（detect_classical），文言文模式下跳过特色词/低频词检测
- 意象字库扩展为 10 类（新增「食物」）
- 版本号统一从 VERSION 文件读取
- 引句去重验证工具函数 verify_quotes()

v3.2 变更（保留）：
- 句子切分允许单字句
- 修辞检测改进
- 意象字库 9→10 类
- FUNC_CHARS 标注为现代汉语集

v3.1（保留）：
- _sent_bucket / _para_bucket 分离
- PUNCT_SET 显式列举
- 意象库繁简双库
- is_cjk 覆盖 Basic + Ext A + Ext B + Compat
- rhetoric 转 list（JSON 可序列化）
"""

import sys, json, re, statistics, argparse
from pathlib import Path
from collections import Counter

# ── 版本号统一从 VERSION 文件读取 ──
_VERSION_FILE = Path(__file__).parent.parent / "VERSION"
if _VERSION_FILE.exists():
    __version__ = _VERSION_FILE.read_text(encoding='utf-8').strip()
else:
    __version__ = "3.3.0"

# ── jieba setup ──
try:
    import jieba
    import jieba.posseg as pseg
    jieba.setLogLevel(60)
    HAS_JIEBA = True
except ImportError:
    HAS_JIEBA = False
    print("[WARN] jieba 未安装，词频/词性分析将跳过。执行: pip install jieba", file=sys.stderr)

# ── 用户人名词典注入 ──
_USER_NAMES = []  # 全局：用户通过 --names 注入的人名列表


def inject_user_names(names_str):
    """将用户提供的逗号分隔人名列表注入 jieba 词典。
    每个人名以高频率 + 'nr'（人名）词性加入，确保 jieba 优先识别。
    """
    global _USER_NAMES
    if not names_str or not HAS_JIEBA:
        return
    names = [n.strip() for n in names_str.split(',') if n.strip()]
    for name in names:
        # 高频率确保 jieba 优先选择该人名为整词
        jieba.add_word(name, freq=999999, tag='nr')
        _USER_NAMES.append(name)
    return names

# ════════════════════════════════════════════════
# CONSTANTS
# ════════════════════════════════════════════════

def is_cjk(c):
    """判断是否为 CJK 汉字。覆盖：
    - Basic    (U+4E00-U+9FFF)
    - Ext A    (U+3400-U+4DBF)
    - Ext B    (U+20000-U+2A6DF)
    - Compat   (U+F900-U+FAFF)
    """
    cp = ord(c)
    return (
        0x4E00 <= cp <= 0x9FFF
        or 0x3400 <= cp <= 0x4DBF
        or 0x20000 <= cp <= 0x2A6DF
        or 0xF900 <= cp <= 0xFAFF
    )

# 标点集合：显式列举，避免字符串拼接的歧义和重复
PUNCT_SET = frozenset([
    '，', '。', '！', '？', '；', '：', '、',
    '…', '—', '～', '·',
    '"', '\u201d', '\u2018', '\u2019',
    '「', '」', '『', '』',
    '（', '）', '【', '】',
    '《', '》', '〈', '〉',
    ',', '.', '!', '?', ';', ':',
    '"', "'",
    '(', ')', '[', ']', '{', '}',
])

# 现代汉语虚词字集合（80 余字）。
# 注：本集合主要覆盖现代汉语高频虚词，不含「岂/孰/莫/弗/乃/胡/耶」等
# 文言虚词。分析古典文本时，这些字会被归入"实词字"，
# 导致虚词比偏低、实词字种偏高——分析报告应在此情况下做出说明。
FUNC_CHARS = set(
    '的了是在我他她它你们們和或与與也都就但而如为為以对對很太更最不没沒有要会會能可得着著过過'
    '把被让讓从從到里裡上下中来來去说說道这這那其此已将將曾又再还還只则則于於之乎者哉夫矣焉且若虽雖'
    '然故因所即何啊呢吧哦嗯哪'
)

# 文言虚词集合（用于文言文检测）
CLASSICAL_FUNC_CHARS = set('之乎者也兮焉哉矣耳夫岂孰莫弗乃胡耶欤邪遂则')

POS_MAP = {
    'n':'名词','nr':'人名','ns':'地名','nz':'专名','ng':'名语素',
    'v':'动词','vd':'副动词','vn':'动名词','vg':'动词语素',
    'a':'形容词','ad':'副形容词','an':'形名词',
    'd':'副词','p':'介词','c':'连词',
    'm':'数词','q':'量词','r':'代词',
    't':'时间词','s':'处所词','f':'方位词',
    'x':'标点','u':'助词','y':'语气词','e':'叹词',
    'i':'成语','l':'惯用语','j':'缩略语',
}

# 实词词性（用于content_tokens），不含专有名词nr/ns/nz
CONTENT_POS = {'n','ng','v','vd','vn','vg','a','ad','an','i','l','j','t','s'}


# ════════════════════════════════════════════════
# 意象字库 v3.3：10 类，每类提供简体 + 繁体字符集
# ════════════════════════════════════════════════
_IMAGERY_RAW = {
    '身体': (
        '眼脸手脚腰背肩胸腹头发耳口唇鼻心肺肠血骨皮肉指甲肤颈臂腿膝肘掌齿舌须眉额',
        '眼臉手腳腰背肩胸腹頭髮耳口唇鼻心肺腸血骨皮肉指甲膚頸臂腿膝肘掌齒舌鬚眉額',
    ),
    '颜色': (
        '红白黑黄蓝绿紫金银灰棕橙粉褐青朱碧赤墨翠',
        '紅白黑黃藍綠紫金銀灰棕橙粉褐青朱碧赤墨翠',
    ),
    '自然': (
        '山水风云雨雪日月星天地花草树叶石沙海河湖原野田川岭崖溪谷霜露霞雾烟泉',
        '山水風雲雨雪日月星天地花草樹葉石沙海河湖原野田川嶺崖溪谷霜露霞霧煙泉',
    ),
    '光影': (
        '光暗影明亮淡闪阴晴阳曦暮昏黎曙昼夜辉煌黯朦胧',
        '光暗影明亮淡閃陰晴陽曦暮昏黎曙晝夜輝煌黯朦朧',
    ),
    '时间': (
        '年月日时秒春夏秋冬古今昔往后曾旦昔朝夕晨午夜瞬',
        '年月日時秒春夏秋冬古今昔往後曾旦昔朝夕晨午夜瞬',
    ),
    '器物': (
        '门窗墙桌椅床灯书杯碗刀剑镜笔琴箫笛钟鼓帘扇砚纸帆舟舸席案',
        '門窗牆桌椅床燈書杯碗刀劍鏡筆琴簫笛鐘鼓簾扇硯紙帆舟舸席案',
    ),
    '情感': (
        '爱恨悲欢喜怒哀惧愁忧寂寞孤思念怨恋慕',
        '愛恨悲歡喜怒哀懼愁憂寂寞孤思念怨戀慕',
    ),
    '动物': (
        '鸟兽虫鱼龙凤鹤雁鹰莺鸠燕鹊鹭鸥鹿马牛羊犬猫鼠蛇蝶蛾蝉鸣',
        '鳥獸蟲魚龍鳳鶴雁鷹鶯鳩燕鵲鷺鷗鹿馬牛羊犬貓鼠蛇蝶蛾蟬鳴',
    ),
    '建筑': (
        '殿阁亭台楼榭堂屋宅院廊柱檐栏阶轩塔阙宫府庙寺观',
        '殿閣亭台樓榭堂屋宅院廊柱簷欄階軒塔闕宮府廟寺觀',
    ),
    # v3.3 新增
    '食物': (
        '酒茶饭菜肉鱼汤饼粥饺面馒糕点果蔬盐酱醋糖油蜜',
        '酒茶飯菜肉魚湯餅粥餃麵饅糕點果蔬鹽醬醋糖油蜜',
    ),
}
IMAGERY_CLUSTERS = {k: set(simp) | set(trad) for k, (simp, trad) in _IMAGERY_RAW.items()}

# ════════════════════════════════════════════════
# CONTEXT HELPERS
# ════════════════════════════════════════════════

# 句子切分正则（全局共用）
_SENT_RE = re.compile(r'[^。！？\n]+[。！？…]+')


def _get_contexts(text, target, max_results=5):
    """返回含 target 的完整句子列表。
    v3.3：改为先切句再搜索，保证返回完整句子（含上下文）。
    """
    results = []
    for m in _SENT_RE.finditer(text):
        sent = m.group(0).strip()
        if target in sent and sent:
            results.append(sent)
            if len(results) >= max_results:
                break
    return results


def _sent_bucket(clen):
    """句子长度分桶（汉字数）。"""
    if clen <= 12:  return '短句'
    if clen <= 30:  return '中句'
    if clen <= 50:  return '长句'
    return '超长句'


def _para_bucket(clen):
    """段落长度分桶（汉字数）。粒度比句子更粗。"""
    if clen <= 30:  return '极短'
    if clen <= 80:  return '短'
    if clen <= 200: return '中'
    if clen <= 400: return '长'
    return '超长'


# ════════════════════════════════════════════════
# CLASSICAL CHINESE DETECTION
# ════════════════════════════════════════════════

def detect_classical(text):
    """检测文本是否为文言文/古典文本。
    策略：统计文言虚词「之乎者也兮焉哉矣耳夫岂孰莫弗乃胡耶」出现频率。
    若文言虚词占总 CJK 字符 > 2%，判定为文言文。
    返回 dict: {is_classical: bool, classical_ratio: float, note: str}
    """
    cjk_chars = [c for c in text if is_cjk(c)]
    total = len(cjk_chars)
    if total == 0:
        return {'is_classical': False, 'classical_ratio': 0.0, 'note': ''}
    classical_count = sum(1 for c in cjk_chars if c in CLASSICAL_FUNC_CHARS)
    ratio = classical_count / total
    is_classical = ratio > 0.02
    note = ''
    if is_classical:
        note = (
            '文言文检测：文言虚词占比 {:.1f}%（阈值 2%），判定为古典文本。'
            'jieba 分词基于现代汉语词典，词性标注和稀有词识别结果仅供参考。'
        ).format(ratio * 100)
    return {'is_classical': is_classical, 'classical_ratio': round(ratio * 100, 2), 'note': note}


# ════════════════════════════════════════════════
# SENTENCE OPENING CLASSIFICATION (v3.3 改进)
# ════════════════════════════════════════════════

def detect_open(s):
    """句首类型分类。v3.3：细化为 8 种类型。"""
    if not s:
        return '其他'
    c = s[0]
    head = s[:2] if len(s) >= 2 else s

    # 引语起句
    if c in '""「『':
        return '引语起句'
    # 第一人称起句
    if c == '我' or head in ('我们', '我們', '咱们', '咱們'):
        return '第一人称起句'
    # 第二人称起句
    if c in '你您' or head in ('你们', '你們'):
        return '第二人称起句'
    # 第三人称起句
    if c in '他她它' or head in ('他们', '她们', '它们', '他們', '她們', '它們'):
        return '第三人称起句'
    # 指示/时间起句
    if c in '这那此其每当' or head in ('这个', '那个', '此时', '此刻', '当时', '那天', '这時', '當時'):
        return '指示/时间起句'
    # 虚词/连词起句
    if c in '的了但而若因如虽虽既':
        return '虚词/连词起句'
    # CJK 实词起句
    if is_cjk(c):
        return '实词起句'
    return '其他'


def classify_rhetoric(s):
    """检测修辞格 / 句间逻辑关系。返回 set。
    v3.2：本函数仅做粗粒度模式识别，作为线索供 AI 语意层参考；
    精细辞格识别（暗喻、博喻、借代、对偶、顶真、设问/反问区分等）
    应由 AI 阅读原文后判断。
    """
    types = set()

    # === 比喻类 ===
    if re.search(r'(像|似|如|猶|犹|彷彿|仿佛|好比)', s) and \
       re.search(r'(一樣|一样|般|似的|一般)', s):
        types.add('明喻')
    if '不是' in s and '而是' in s:
        types.add('对比')

    # === 反复 / 复辞 / 叠字（互斥分类） ===
    pairs = re.findall(r'([\u4e00-\u9fff])\1', s)
    aa_count = len(pairs)
    cf_match = bool(re.search(r'(不|没|沒).{0,3}(不|没|沒)', s))
    low_div = (len(set(s)) / max(len(s), 1) < 0.45 and len(s) > 8)

    if aa_count >= 2:
        types.add('叠字')
    elif cf_match and len(s) >= 4:
        types.add('复辞')
    elif low_div:
        types.add('反复')

    # === 排比 ===
    if not s.count('；'):
        segs = re.split(r'[，,]', s)
        segs = [seg.strip() for seg in segs if seg.strip()]
        if len(segs) >= 3:
            seg_lens = [len(seg) for seg in segs]
            avg_len = sum(seg_lens) / len(seg_lens)
            if avg_len >= 3:
                variance = sum((l - avg_len) ** 2 for l in seg_lens) / len(seg_lens)
                cv = (variance ** 0.5) / avg_len if avg_len > 0 else 1
                if cv < 0.4:
                    types.add('排比')

    # === 反问 ===
    if re.search(r'(豈|岂|難道|难道|何嘗|何尝|何曾|何必|何不|何苦|何須|何须|怎能|怎可|焉能|寧不|宁不)', s):
        if s.endswith('？') or s.endswith('?') or s.endswith('！') or s.endswith('!'):
            types.add('反问')
        elif '？' in s or '?' in s:
            types.add('反问')

    # === 句间逻辑关系 ===
    if re.search(r'(然|而|却|但|虽|尽管|雖|儘管|卻).{1,8}(却|但|然而|可是|卻|不過|不过)', s):
        types.add('转折')
    if re.search(r'(雖然|虽然|尽管|儘管|即使|縱然|纵然).{2,15}(也|還|还|仍|依然)', s):
        types.add('让步')
    if re.search(r'(連|连).{1,4}[都也]', s):
        types.add('递进')
    if re.search(r'(真|好|很|太|极|十分|非常|格外|極).{1,4}(啊|呀|呢|了|的)', s) or \
       (s.endswith('！') or s.endswith('!')) and len(s) <= 20:
        types.add('感叹')
    if re.search(r'(因为|由于|因為|由於).{2,30}(所以|因此|故|以致|於是|于是)', s):
        types.add('因果')
    if re.search(r'(如果|假若|倘若|要是|即使|若是|若).{2,20}(就|便|也|则|則|將|将)', s):
        types.add('假设')
    return types


# ════════════════════════════════════════════════
# CHARACTER ANALYSIS
# ════════════════════════════════════════════════

def analyze_chars(text):
    cjk  = [c for c in text if is_cjk(c)]
    freq = Counter(cjk)

    content_freq = sorted([(c,n) for c,n in freq.items() if c not in FUNC_CHARS], key=lambda x:-x[1])
    func_freq    = sorted([(c,n) for c,n in freq.items() if c in FUNC_CHARS],     key=lambda x:-x[1])
    rare_chars   = [c for c,n in freq.items() if n == 1]

    rare_char_contexts = {}
    for c in rare_chars[:60]:
        ctxs = _get_contexts(text, c, max_results=2)
        if ctxs:
            rare_char_contexts[c] = ctxs

    imagery = {}
    for cluster, chars in IMAGERY_CLUSTERS.items():
        hits = {c: freq[c] for c in chars if c in freq}
        if hits:
            imagery[cluster] = {'total': sum(hits.values()), 'chars': hits}

    return {
        'total_cjk':          len(cjk),
        'unique':             len(freq),
        'content_count':      len(content_freq),
        'func_count':         len(func_freq),
        'rare_count':         len(rare_chars),
        'content_freq':       content_freq[:80],
        'func_freq':          func_freq[:40],
        'rare':               rare_chars,
        'rare_char_contexts': rare_char_contexts,
        'all_freq':           freq.most_common(5000),
        'imagery_chars':      imagery,
    }

# ════════════════════════════════════════════════
# WORD ANALYSIS
# ════════════════════════════════════════════════

def _is_segmented_pseudo(word):
    """判断 word 是否是 jieba 分词粘连产生的伪词。
    v3.4 增强：除了检测 jieba 把词切回全部单字的情况，还检测：
    1. 词典频率极低（<5）且由常用动词/虚词 + 实词首字组成的双字词
    2. 词的两个字在 jieba 词典中各自独立频率远高于合并频率
    """
    if not HAS_JIEBA or len(word) < 2:
        return False
    try:
        # 原始检测：jieba 把词切回全部单字
        standalone = list(jieba.cut(word))
        if len(standalone) > 1 and all(len(s) == 1 for s in standalone if s.strip()):
            return True

        # v3.4 新增：基于词典频率的伪词检测
        # 如果该词在 jieba 词典中频率极低（≤5），且组成字符各自高频，
        # 则很可能是分词错误产生的粘连词
        if len(word) == 2:
            word_freq = jieba.dt.FREQ.get(word, 0)
            char1_freq = jieba.dt.FREQ.get(word[0], 0)
            char2_freq = jieba.dt.FREQ.get(word[1], 0)

            # 词典频率极低，但两个字各自频率都很高→大概率是伪词
            if word_freq <= 5 and char1_freq > 100 and char2_freq > 100:
                # 进一步确认：第一个字是常见动词/虚词字
                common_verb_chars = set('问说看想听写读做打去来回走跑吃喝送给带拿叫让请教')
                common_func_adhesion = set('有无没人会能可')
                if word[0] in common_verb_chars or word[0] in common_func_adhesion:
                    return True

    except Exception:
        pass
    return False


def _detect_verb_name_adhesion(word, text, content_freq):
    """检测「动词+人名首字」粘连模式。
    v3.4 新增。

    策略：检查一个双字词是否总是出现在某个固定后缀前面。
    例如「问法」后面 80%+ 紧跟「比耶娜」→说明是「问/法比耶娜」的分词错误。

    前提条件（避免误判）：
    - 仅对 jieba 词典频率 ≤ 100 的词进行检测（高频词不可能是粘连伪词）
    - 仅对双字词检测

    参数：
        word: 待检测的双字词
        text: 完整文本
        content_freq: 当前内容词频率 Counter

    返回：
        True 如果该词被判定为粘连伪词
    """
    if not HAS_JIEBA or len(word) != 2:
        return False

    # 前提：词典频率高的词不需要检测（它们是合法词汇）
    word_dict_freq = jieba.dt.FREQ.get(word, 0)
    if word_dict_freq > 100:
        return False

    try:
        # 找出该词在文本中的所有出现位置及其后续字符
        suffix_counter = Counter()
        occurrences = 0
        start = 0
        while True:
            idx = text.find(word, start)
            if idx < 0:
                break
            occurrences += 1
            # 取后续 1-4 个字符作为后缀候选
            after = text[idx + len(word): idx + len(word) + 4]
            after_cjk = ''.join(c for c in after if is_cjk(c))
            if after_cjk:
                # 收集不同长度的后缀
                for length in range(1, len(after_cjk) + 1):
                    suffix_counter[after_cjk[:length]] += 1
            start = idx + 1

        if occurrences < 2:
            return False

        # 检查是否有某个后缀在 80%+ 的情况下出现
        for suffix, count in suffix_counter.most_common(5):
            if len(suffix) >= 2 and count / occurrences >= 0.8:
                # 该词后面高频跟随同一后缀→
                # 检查「word[1] + suffix」是否可能构成人名
                potential_name = word[1] + suffix
                # 如果这个潜在人名不在 jieba 词典中（或频率很低），
                # 且该词第一个字是常见动词，则判定为粘连
                name_freq = jieba.dt.FREQ.get(potential_name, 0)
                word_first_char_freq = jieba.dt.FREQ.get(word[0], 0)

                # 额外条件：后缀本身不是常见词（避免正常搭配被误判）
                if name_freq <= 10 and word_first_char_freq > 50:
                    suffix_dict_freq = jieba.dt.FREQ.get(suffix, 0)
                    if suffix_dict_freq > 500:
                        # 后缀本身是常见词→这是正常搭配，不是粘连
                        continue
                    return True

        # 检查「X人会」模式：word 是「人会」之类，前面总是跟「有/无/没」
        prefix_counter = Counter()
        start = 0
        while True:
            idx = text.find(word, start)
            if idx < 0:
                break
            # 取前面 1-2 个字符
            before_start = max(0, idx - 2)
            before = text[before_start:idx]
            before_cjk = ''.join(c for c in before if is_cjk(c))
            if before_cjk:
                prefix_counter[before_cjk[-1]] += 1
            start = idx + 1

        # 如果该词前面总是跟同一个字（如「没有/人会」→「人会」是伪词）
        if prefix_counter:
            top_prefix, top_count = prefix_counter.most_common(1)[0]
            if top_count / occurrences >= 0.7:
                # 检查 word 的两个字是否分属不同语义单元
                # 「人」+「会」各自独立高频 → 伪词
                char1_freq = jieba.dt.FREQ.get(word[0], 0)
                char2_freq = jieba.dt.FREQ.get(word[1], 0)
                if char1_freq > 200 and char2_freq > 200 and word_dict_freq <= 50:
                    return True

    except Exception:
        pass
    return False


def _filter_pseudo_words(content_freq, text):
    """伪词过滤后处理器。v3.4 新增。
    统一管理伪词检测管线，返回应被过滤掉的词集合。

    检测策略：
    1. _is_segmented_pseudo：jieba 切回单字 或 词典频率极低的粘连
    2. _detect_verb_name_adhesion：动词+人名首字粘连模式
    """
    pseudo_words = set()
    if not HAS_JIEBA:
        return pseudo_words

    for word in list(content_freq.keys()):
        if len(word) < 2:
            continue

        # 策略 1：基础伪词检测
        if _is_segmented_pseudo(word):
            pseudo_words.add(word)
            continue

        # 策略 2：动词+人名首字粘连检测
        if _detect_verb_name_adhesion(word, text, content_freq):
            pseudo_words.add(word)
            continue

    return pseudo_words


def _detect_word_features(content_tokens, text='', is_classical=False):
    """检测词汇特征（基于文本内频率）。
    v3.4：集成伪词过滤后处理器 _filter_pseudo_words。
    v3.3：文言文模式下跳过检测（jieba 对文言文分词不可靠）。
    """
    if not content_tokens:
        return {}
    if is_classical:
        return {}

    rare = {}
    try:
        text_freq = Counter(w for w, _ in content_tokens)
        all_counts = list(text_freq.values())
        if not all_counts:
            return {}

        median_freq = statistics.median(all_counts)
        sents = re.split(r'[。！？；…]', text)

        # v3.4：统一伪词过滤
        pseudo_words = _filter_pseudo_words(text_freq, text)

        for w, f in content_tokens:
            if w in rare:
                continue
            count = text_freq[w]
            dict_freq = jieba.dt.FREQ.get(w, 0) if HAS_JIEBA else 0

            # v3.4：使用统一伪词过滤结果
            if w in pseudo_words:
                continue
            cross_sent = sum(1 for s in sents if w in s)
            if cross_sent < 2:
                continue

            if count <= 3:
                rare[w] = {'level': '低频词', 'count': count,
                           'pos': f, 'dict_freq': dict_freq}
            elif count >= median_freq and dict_freq <= 2:
                rare[w] = {'level': '特色词', 'count': count,
                           'pos': f, 'dict_freq': dict_freq}
    except Exception:
        pass
    return rare


def analyze_words(text, is_classical=False):
    if not HAS_JIEBA:
        return {
            'top_words':[],'func_words':[],'pos_dist':{},'pos_ratios':{},
            'pronouns':[],'idioms':[],'rare_words':{},'rare_word_contexts':{},'wpos':{},
            'person_names':[],'proper_nouns':[],
        }

    pairs  = list(pseg.cut(text))
    tokens = [(w.word.strip(), w.flag) for w in pairs if w.word.strip()]

    proper_nouns = Counter()
    content_tokens, func_tokens = [], []

    for w, f in tokens:
        if not any(is_cjk(c) for c in w) or len(w) < 2:
            continue

        if f.startswith(('nr', 'ns', 'nz')):
            dict_freq = jieba.dt.FREQ.get(w, 0) if HAS_JIEBA else 0
            if dict_freq > 5000:
                content_tokens.append((w, f))
            else:
                proper_nouns[w] += 1
            continue

        if f[:1] in CONTENT_POS:
            content_tokens.append((w, f))
        else:
            func_tokens.append((w, f))

    content_freq = Counter(w for w,_ in content_tokens)
    func_freq    = Counter(w for w,_ in func_tokens)

    # v3.4：过滤 top_words 中的伪词
    pseudo_in_top = _filter_pseudo_words(content_freq, text)
    for pw in pseudo_in_top:
        if pw in content_freq:
            del content_freq[pw]

    all_cjk  = [(w,f) for w,f in tokens if any(is_cjk(c) for c in w) and len(w) >= 2]
    pos_dist = Counter(POS_MAP.get(f[:2],'其他') for w,f in all_cjk)

    pronoun_freq = Counter(w for w,f in tokens if f.startswith('r') and any(is_cjk(c) for c in w))
    idiom_freq   = Counter(w for w,f in tokens if f.startswith('i') and any(is_cjk(c) for c in w))

    proper_noun_set = set(proper_nouns.keys())
    filtered_tokens = [(w, f) for w, f in content_tokens if w not in proper_noun_set and w not in pseudo_in_top]
    rare_words = _detect_word_features(filtered_tokens, text=text, is_classical=is_classical)
    rare_word_contexts = {}
    for w in rare_words:
        ctxs = _get_contexts(text, w, max_results=2)
        if ctxs:
            rare_word_contexts[w] = ctxs

    wpos = {}
    for w, cnt in content_freq.items():
        if cnt >= 2:
            positions, start = [], 0
            while True:
                idx = text.find(w, start)
                if idx < 0: break
                positions.append(idx); start = idx + 1
            wpos[w] = positions

    total_content = sum(v for k,v in pos_dist.items() if k not in ('标点','助词','语气词','其他'))
    ratios = {k: round(pos_dist.get(k,0)/max(total_content,1)*100, 1)
              for k in ['名词','动词','形容词','副词','代词','数词','成语','惯用语']}

    return {
        'top_words':          content_freq.most_common(80),
        'func_words':         func_freq.most_common(30),
        'pos_dist':           dict(pos_dist.most_common()),
        'pos_ratios':         ratios,
        'pronouns':           pronoun_freq.most_common(20),
        'idioms':             idiom_freq.most_common(20),
        'person_names':       proper_nouns.most_common(40),
        'proper_nouns':       proper_nouns.most_common(40),
        'rare_words':         rare_words,
        'rare_word_contexts': rare_word_contexts,
        'wpos':               wpos,
        'pseudo_words_filtered': sorted(pseudo_in_top),  # v3.4: 记录被过滤的伪词
    }


# ════════════════════════════════════════════════
# SENTENCE ANALYSIS
# ════════════════════════════════════════════════

def analyze_sentences(text):
    sents = []
    for m in _SENT_RE.finditer(text):
        t = m.group(0).strip()
        if not t:
            continue
        cjk_len = len([c for c in t if is_cjk(c)])
        if cjk_len == 0:
            continue
        rhetoric = classify_rhetoric(t)
        dialog  = bool(re.match(r'\s*["\u201c「『]', t) or re.search(r'["\u201d」』]\s*[。，]', t))
        opening = detect_open(t)
        sents.append({
            'id': len(sents) + 1,
            'text': t, 'clen': cjk_len,
            'type': _sent_bucket(cjk_len),
            'dialog': dialog,
            'open': opening,
            'rhetoric': sorted(rhetoric),
        })

    if not sents:
        return {'count':0,'avg_len':0,'max_len':0,'min_len':0,'variance':0,
                'rhythm':'','type_dist':{},'open_dist':{},'rhet_dist':{},
                'dialog_pct':0,'sents':[],
                'note': '统计层修辞识别为粗粒度模式匹配，仅作 AI 语意分析的线索参考。'}

    lens = [s['clen'] for s in sents]
    avg, mx, mn = sum(lens)/len(lens), max(lens), min(lens)
    var = round(sum((l-avg)**2 for l in lens)/len(lens), 1)

    buckets = Counter(s['type'] for s in sents)
    opens   = Counter(s['open'] for s in sents)
    rhets   = Counter()
    for s in sents:
        for r in s['rhetoric']:
            rhets[r] += 1
    dialog_n = sum(1 for s in sents if s['dialog'])
    dialog_pct = round(dialog_n / len(sents) * 100, 1)

    if mx > 3 * mn:
        rhythm = '强烈对比'
    elif var > avg * 0.5:
        rhythm = '起伏'
    else:
        rhythm = '平稳'

    return {
        'count': len(sents), 'avg_len': round(avg, 1), 'variance': var,
        'max_len': mx, 'min_len': mn, 'rhythm': rhythm,
        'type_dist': dict(buckets),
        'open_dist': dict(opens),
        'rhet_dist': dict(rhets),
        'dialog_pct': dialog_pct,
        'sents': sents,
        'note': '统计层修辞识别为粗粒度模式匹配（关键字 + 句法启发式），仅作 AI 语意分析的线索参考。',
    }

# ════════════════════════════════════════════════
# PARAGRAPH ANALYSIS (v3.3: 增加单换行 fallback)
# ════════════════════════════════════════════════

def analyze_paragraphs(text):
    """段落分析。v3.3：增加单换行 fallback 逻辑。
    优先用双换行切分；若结果 ≤ 1 段且文本含单换行，则 fallback 为单换行切分。
    """
    paras = [p.strip() for p in text.split('\n\n') if p.strip()]
    # Fallback: 如果双换行切分只得到 0-1 段，且文本确实有换行
    if len(paras) <= 1 and '\n' in text:
        single_split = [p.strip() for p in text.split('\n') if p.strip() and len(p.strip()) > 1]
        if len(single_split) > 1:
            paras = single_split

    result = []
    for p in paras:
        cjk = len([c for c in p if is_cjk(c)])
        sent_count = len(re.findall(r'[。！？…]', p))
        avg_sent = round(cjk / max(sent_count, 1), 1)
        result.append({
            'id': len(result) + 1,
            'text': p, 'clen': cjk, 'sc': sent_count,
            'avg_sent': avg_sent, 'bucket': _para_bucket(cjk),
        })

    if not result:
        return {'count':0,'avg_len':0,'avg_sc':0,'max_len':0,'min_len':0,
                'bucket_dist':{},'single_sent':0,'paras':[]}

    lens = [p['clen'] for p in result]
    scs  = [p['sc'] for p in result]
    return {
        'count': len(result),
        'avg_len': round(sum(lens)/len(lens), 1),
        'avg_sc': round(sum(scs)/len(scs), 1),
        'max_len': max(lens), 'min_len': min(lens),
        'bucket_dist': dict(Counter(p['bucket'] for p in result)),
        'single_sent': sum(1 for p in result if p['sc'] == 1),
        'paras': result,
    }

# ════════════════════════════════════════════════
# PUNCTUATION ANALYSIS
# ════════════════════════════════════════════════

def analyze_punctuation(text):
    punc_chars = [c for c in text if c in PUNCT_SET]
    counts = Counter(punc_chars)
    total = len(punc_chars)
    cjk_count = len([c for c in text if is_cjk(c)])

    dashes = []
    for m in re.finditer(r'[^。！？\n]{0,30}—[^。！？\n]{0,30}', text):
        dashes.append(m.group(0).strip())
    ellipses = []
    for m in re.finditer(r'[^。！？\n]{0,30}…+[^。！？\n]{0,30}', text):
        ellipses.append(m.group(0).strip())
    pauses = []
    for m in re.finditer(r'[^。！？\n]{0,20}、[^。！？\n]{0,20}', text):
        pauses.append(m.group(0).strip())

    return {
        'total': total,
        'density': round(total / max(cjk_count, 1) * 100, 2),
        'dash_count': len(dashes),
        'ellipsis_count': len(ellipses),
        'pause_count': len(pauses),
        'dash_contexts': dashes[:10],
        'ellipsis_contexts': ellipses[:10],
        'counts': dict(counts),
    }


# ════════════════════════════════════════════════
# QUOTE VERIFICATION (v3.3 新增)
# ════════════════════════════════════════════════

def verify_quotes(semantic_md_text):
    """从 semantic.md 文本中提取所有「…」引句，检查重复。
    返回 dict: {total: int, unique: int, duplicates: list[str]}
    用于辅助检查第三部分引句是否与前文重复。
    """
    # 匹配中文引号内的内容（直角引号 + 弯引号）
    quotes = re.findall(r'「([^」]+)」', semantic_md_text)
    quotes += re.findall(r'\u201c([^\u201d]+)\u201d', semantic_md_text)
    total = len(quotes)
    seen = set()
    duplicates = []
    for q in quotes:
        q_stripped = q.strip()
        if q_stripped in seen:
            duplicates.append(q_stripped)
        else:
            seen.add(q_stripped)
    return {
        'total': total,
        'unique': len(seen),
        'duplicates': list(set(duplicates)),
    }

# ════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════

def run(text):
    text = text.strip()
    if not text:
        return {'error': 'Empty input'}
    cjk_chars = [c for c in text if is_cjk(c)]
    if len(cjk_chars) < 100:
        return {'error': 'Text too short (< 100 CJK characters). Analysis not meaningful.'}

    # 文言文检测
    classical_info = detect_classical(text)
    is_classical = classical_info['is_classical']

    chars = analyze_chars(text)
    words = analyze_words(text, is_classical=is_classical)
    sents = analyze_sentences(text)
    paras = analyze_paragraphs(text)
    punct = analyze_punctuation(text)

    word_sent_idx = {}
    for w, cnt in (words.get('top_words') or []):
        if cnt >= 2:
            word_sent_idx[w] = [s['id'] for s in sents['sents'] if w in s['text']]

    # v3.3: 不再输出完整 raw 字段，仅保留 text_preview（前500字）
    text_preview = text[:500] + ('…' if len(text) > 500 else '')

    return {
        'text_preview': text_preview,
        'chars': chars,
        'words': words,
        'sents': sents,
        'paras': paras,
        'punct': punct,
        'word_sent_idx': word_sent_idx,
        'classical': classical_info,
        'meta': {
            'engine_version': __version__,
            'text_type': '古典文本' if is_classical else '现代文本',
            'total_cjk':    chars['total_cjk'],
            'unique_chars': chars['unique'],
            'rare_chars':   chars['rare_count'],
            'sent_count':   sents['count'],
            'para_count':   paras['count'],
            'avg_sent_len': sents['avg_len'],
            'max_sent_len': sents['max_len'],
            'min_sent_len': sents['min_len'],
            'rhythm':       sents['rhythm'],
            'punct_density':punct['density'],
            'dialog_pct':   sents['dialog_pct'],
        }
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='文风拆解器 — 统计分析引擎 v3.4',
        usage='python3 analyze.py <text_file> [--names "人名1,人名2,..."]'
    )
    parser.add_argument('text_file', nargs='?', default=None,
                        help='输入文本文件路径（不提供则从 stdin 读取）')
    parser.add_argument('--names', type=str, default=None,
                        help='逗号分隔的人名列表，注入 jieba 词典以避免分词粘连。'
                             '例如: --names "法比耶娜,德沃,沙坦"')
    args = parser.parse_args()

    # 注入用户人名词典
    if args.names:
        injected = inject_user_names(args.names)
        if injected:
            print(f"[INFO] 已注入 {len(injected)} 个人名到 jieba 词典: {', '.join(injected)}",
                  file=sys.stderr)

    if args.text_file:
        with open(args.text_file, 'r', encoding='utf-8') as f:
            text = f.read()
    else:
        text = sys.stdin.read()
    result = run(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
