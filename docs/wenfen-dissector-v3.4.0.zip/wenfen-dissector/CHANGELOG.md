# Changelog

## v3.3.0 — 系统性改进（15 项修复）

基于全面代码审阅，本次更新覆盖数据正确性（P0）、工程健壮性（P1）、增强建议（P2）三个层面。

### P0 — 数据正确性修复

- **段落切分增加单换行 fallback**：`analyze_paragraphs()` 在双换行切分只得到 0-1 段时，自动 fallback 为单换行切分。修复 EPUB/TXT 中仅用单换行分段导致段落分析失效的问题。
- **`_get_contexts` 改为完整句匹配**：不再使用前后 40 字截取（可能返回不完整片段），改为基于 `_SENT_RE` 的完整句子搜索，保证返回含上下文的完整句。
- **`run()` 不再输出 `raw` 字段**：对于 10万+ 字文本，原 `stats.json` 因嵌入完整原文而巨大。改为仅输出 `text_preview`（前 500 字）。
- **EPUB 章节标题提取改进**：`extract_epub()` 优先从 HTML `<h1>`-`<h3>` 或 `<title>` 标签提取章节标题，fallback 到正文前 60 字。

### P1 — 工程健壮性

- **新增 Step 0：正文提取与范围确认**：SKILL.md 增加完整的正文范围截取指导（关键词启发式剥离、用户询问策略、EPUB 章节级排除），使 AI agent 可以执行此步骤。
- **`detect_open` 细化为 8 种句首类型**：区分第一/第二/第三人称、引语、指示/时间、虚词/连词、实词、其他，替代原来粗糙的 5 类。
- **新增 semantic.md Markdown 子集文档**：SKILL.md 新增第 9 节，明确列出 `parse_md()` 支持和不支持的语法，避免 AI 使用不兼容语法导致 PDF 内容丢失。
- **`requirements.txt` 增加 Python 版本说明**：注明 Python >= 3.8, < 3.13 recommended，以及 jieba 在 3.12+ 的兼容性说明。
- **文言文自动检测与优雅降级**：新增 `detect_classical()` 函数，当文言虚词占比 > 2% 时自动判定为古典文本。古典文本模式下跳过特色词/低频词检测，`meta.text_type` 标记为 `"古典文本"`。
- **句子功能分类改为均匀采样**：SKILL.md 中将「取前 50 句」改为「均匀采样 50 句」（等间距或开头/中间/结尾分段取样），确保覆盖全文不同阶段。

### P2 — 增强

- **新增 `tests/` 目录**：57 个单元测试覆盖 `is_cjk` 边界、分桶正确性、修辞格正/反例、句首分类、文言文检测、段落切分 fallback、`_get_contexts`、`run()` 错误/正常路径、`verify_quotes`。全部通过。
- **PlotTree 移至独立文件**：`scripts/plot_tree.py` 独立存放情节流程图 Flowable 代码，`pdf_report.py` 中仅保留注释引用，减少主文件体积约 180 行。
- **意象字库扩展为 10 类**：新增「食物」类（酒茶饭菜肉鱼汤饼粥饺面馒糕点果蔬盐酱醋糖油蜜 + 繁体），覆盖美食文学核心意象。
- **引句去重验证工具**：新增 `verify_quotes(semantic_md_text)` 函数，从 semantic.md 中提取所有引句并检查重复，辅助 AI 确保第三部分引句不与前文重复。
- **版本号统一管理**：`__version__` 改为从 `VERSION` 文件读取，`meta.engine_version` 输出完整版本号（含 patch），消除三处版本信息不一致问题。

### 文件变更清单

| 文件 | 变更 |
|------|------|
| `VERSION` | 3.2.1 → 3.3.0 |
| `scripts/analyze.py` | 重写（段落 fallback、_get_contexts、detect_open、detect_classical、食物意象、verify_quotes、版本统一） |
| `scripts/epub_analyzer.py` | 标题提取改进 |
| `scripts/pdf_report.py` | PlotTree 移除（改为 import 注释） |
| `scripts/plot_tree.py` | 新增（PlotTree 独立文件） |
| `SKILL.md` | 新增 Step 0、Markdown 子集文档、版本号更新、采样策略修正 |
| `requirements.txt` | 增加 Python 版本说明 |
| `tests/test_analyze.py` | 新增（57 个单元测试） |
| `tests/__init__.py` | 新增 |
| `CHANGELOG.md` | 本次更新 |
| `README.md` | 版本同步 |

---

## v3.2.1 — 二轮审阅小修

- 建筑类意象字库去重
- prompt_reference.md 内部提示词与文件头一致化

## v3.2 — 数据/工程/文档系统性修复

- 句子切分允许单字句
- 修辞检测改进（反问/排比/反复互斥分类）
- 意象字库 7→9 类（动物、建筑）
- TOC 改用 sentinel marker
- 章节编号修正（概览不占编号）
- 引句规范修正
- 死代码清理

## v3.1 — P0 数据正确性修复

- 句型分布全 0 修复
- 句子/段落分桶分离
- 意象库繁简双库
- is_cjk 扩展到 Ext B + Compat
- rhetoric set → sorted list

## v3.0

- 稀有词检测重写
- 人名/专有名词独立收集
- 三维词汇分类

## v2.2

- 双引擎结构（统计 + AI 语意）
- pdf_report.py 直接消费 stats.json
