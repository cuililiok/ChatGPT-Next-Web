# 文风拆解器 v3.3.0

中文文学文风分析工具，输出完整 PDF 分析报告。

## 安装

```bash
# Python >= 3.8, < 3.13 recommended
pip install -r requirements.txt
```

## 快速开始

```bash
# 1. 统计分析
python scripts/analyze.py 作品.txt > stats.json

# 2. AI 语意分析（由 AI 阅读 stats.json + 原文后撰写）
# → 生成 semantic.md

# 3. 输出 PDF
python scripts/pdf_report.py \
  --stats stats.json \
  --ai    semantic.md \
  --output 作品_文风分析.pdf \
  --title "《作品名》文风拆解报告" \
  --theme warm-academic
```

## EPUB 输入

```bash
python scripts/epub_analyzer.py 作品.epub
# 输出至 /tmp/wenfen_book/book_stats_bundle.json
```

## 运行测试

```bash
pip install pytest
python -m pytest tests/ -v
```

## 文件说明

| 文件 | 说明 |
|------|------|
| `VERSION` | 版本号（当前 3.3.0） |
| `CHANGELOG.md` | 版本变更记录 |
| `SKILL.md` | 完整工作流程文档（AI Skill 定义） |
| `scripts/analyze.py` | 统计分析引擎（jieba） |
| `scripts/pdf_report.py` | PDF 报告生成器（reportlab） |
| `scripts/epub_analyzer.py` | EPUB 文本提取与全书采样分析 |
| `scripts/md2pdf.py` | PDF 基础设施（bundled） |
| `scripts/plot_tree.py` | 情节流程图 Flowable（预留） |
| `references/prompt_reference.md` | AI 撰写 semantic.md 的思路框架参考 |
| `requirements.txt` | Python 依赖 |
| `tests/test_analyze.py` | 单元测试（57 个） |

## 依赖

- Python 3.8+ (推荐 < 3.13)
- jieba（中文分词）
- reportlab（PDF 生成）
- ebooklib（EPUB 解析，可选）
- pytest（运行测试，可选）

## 版本历史

- **v3.3.0** — 15 项系统性改进（段落 fallback、文言检测、食物意象、测试覆盖等）
- **v3.2.1** — 建筑类意象字库去重、prompt_reference 一致化
- **v3.2** — 句切分修复、修辞改进、意象库扩 9 类、TOC 健壮化、章节编号修正
- **v3.1** — P0 数据正确性修复
- **v3.0** — 稀有词检测重写、专有名词独立收集
- **v2.2** — 双引擎结构（统计 + AI 语意）
