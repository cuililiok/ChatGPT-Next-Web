---
name: wenfen-dissector
description: 文風拆解器（Chinese Text Style Dissector）。當用戶要求分析中文文本的文風、拆解寫作風格、進行文學分析、研究句型詞頻意象修辭等時使用此技能。觸發詞包括：文風分析、文風拆解、拆解文本、分析文風、文學分析、詞頻分析、意象系統、修辭分析、句型分析、稀有字、稀有詞。即使用戶只說「幫我分析這篇文章」並貼入中文文本，也應觸發此技能。
---

# 文風拆解器 — 完整工作流程 v3.1

雙引擎系統：**統計引擎**（analyze.py + jieba，v3.1）產出結構化 JSON，**語意引擎**（AI）讀 JSON + 原文生成分析散文，**pdf_report.py**（v3.1）直接從 JSON 構建第一部分所有表格並合併 AI 散文，輸出完整 PDF。

---

## 目錄

1. [前置準備](#1-前置準備)
2. [Step 1：執行統計分析](#2-step-1執行統計分析)
3. [Step 2：AI 語意分析（6個模塊）](#3-step-2ai-語意分析6個模塊)
4. [Step 3：輸出 PDF](#4-step-3輸出-pdf)
5. [字段速查表](#5-字段速查表)
6. [報告結構模板](#6-報告結構模板)
7. [全局引句規範](#7-全局引句規範)
8. [注意事項](#8-注意事項)

---

## 1. 前置準備

### 安裝依賴

```bash
pip install jieba reportlab
```

### 路徑定位（動態，不硬編碼）

```python
import sys, os
_SCRIPTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scripts')
if _SCRIPTS not in sys.path:
    sys.path.insert(0, _SCRIPTS)

from analyze import run, analyze_chars, analyze_words, analyze_sentences, analyze_paragraphs, analyze_punctuation
```

### 讀取文本

```python
# 普通文本文件
with open(text_path, 'r', encoding='utf-8') as f:
    text = f.read()

# EPUB（調用 epub_analyzer.py）
from epub_analyzer import extract_epub_text
text = extract_epub_text(epub_path)
```

> ⚠️ **正文範圍提示**：分析前必須確認已正確截取正文範圍，排除前言、版權頁、目錄、廣告頁、注釋附錄等非正文內容。例如魯迅《故事新編》，前言佔全書篇幅的 15%，若不排除會顯著拉低詞彙密度、拉高抽象詞比例，影響分析結論。

---

## 2. Step 1：執行統計分析

```python
result = run(text)   # 一次性執行，長文本（>10萬字）自動分塊後合併

chars = result['chars']
words = result['words']
sents = result['sents']
paras = result['paras']
punct = result['punct']
meta  = result['meta']

# 保存 JSON 供 pdf_report.py 使用
import json
with open('stats.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
```

---

## 3. Step 2：AI 語意分析（6個模塊）

語意分析由 AI 直接完成，無需外部 API。逐模塊閱讀 JSON 數據和原文後撰寫分析散文，保存為 `semantic.md`，供 pdf_report.py 合併進 PDF 第二、三部分。

### 模塊概覽

| # | 模塊 | 主要數據輸入 | 核心任務 |
|---|------|------------|---------|
| 1 | 意象系統 | chars['imagery_chars'] + 原文 | 識別核心意象、象徵含義、系統性 |
| 2 | 敘述聲音 | sents['open_dist'] + sents['dialog_pct'] + 原文 | 人稱、距離、可靠性、情感溫度 |
| 3 | 修辭格 | sents['rhet_dist'] + sents['sents'] + 原文 | 找例句、分析功能、識別標誌性修辭 |
| 4 | 情節結構 | paras['paras'] + 原文 | 敘事動力、時間結構、衝突層級（含20種情節類型識別） |
| 5 | 文風肖像 | meta + pos_ratios + imagery_chars + 原文 | 3個文風標籤、氣質描述、近似作家、文風危險 |
| 6 | 句子功能 | sents['sents']（前50句）| 逐句歸類並統計功能分佈 |

### 各模塊執行要點

**① 意象系統**
- 結合 `imagery_chars` 的量化數據（各類別 total 次數和 chars 高頻字），定位原文中意象的具體出現語境
- 識別意象間是否形成「呼應系統」（同一意象反覆出現、不同意象相互映照）或「散漫分布」
- 每個核心意象至少引用 **3 個原文例句**，展示其在不同語境中的用法變化

**② 敘述聲音**
- 重點觀察：`words['pronouns']`（人稱代詞分布）、`sents['dialog_pct']`（對話佔比）、`sents['open_dist']`（句首類型）
- 自由間接引語識別：人物內心與敘述聲音的融合處（如「她知道，這不可能。」）
- 至少引用 **5 段原文**演示聲音特徵

**③ 修辭格**
- 以 `rhet_dist` 為索引，從 `sents['sents']` 定位對應句子
- 每種修辭格至少引用 **2 個原文例句**（含上下文，不能孤立一句）
- 判斷「標誌性修辭」：高密度 + 貫穿全文 + 與文風氣質高度吻合

**④ 情節結構（含20種情節類型）**

用以下框架識別本文的情節類型（可多選）：

| 類型 | 核心動力 | 結構標誌 |
|------|---------|---------|
| 追求 | 主角追尋目標或理想 | 目標明確→障礙→達成或幻滅 |
| 冒險 | 進入未知世界的旅程 | 出發→磨難→歸來/蛻變 |
| 追逐 | 逃跑與追趕的張力 | 獵手/獵物二元結構 |
| 救助 | 拯救身陷危境者 | 被困→英雄介入→解救 |
| 逃脫 | 主角脫離困境 | 囚禁/束縛→謀劃→突圍 |
| 復仇 | 以暴力或計謀討回公道 | 傷害→醞釀→復仇行動 |
| 謎題 | 解開謎團為驅動力 | 謎題呈現→線索→揭示 |
| 對立 | 兩種力量的正面衝突 | 對立面設立→鬥爭→勝負 |
| 愛情 | 吸引、阻礙與結合（或分離）| 相遇→阻礙→結局 |
| 禁忌之愛 | 越界的愛情 | 禁忌設立→越界→代價 |
| 犧牲 | 為更高價值放棄自身 | 選擇時刻→代價→意義確認 |
| 發現 | 揭示隱藏的真相 | 現狀→探查→真相暴露 |
| 蛻變 | 人物在壓力下改變 | 原始狀態→觸發→質變 |
| 成長 | 從幼稚走向成熟 | 初始幼稚→歷練→成熟 |
| 墮落 | 從高處跌落的弧線 | 高峰狀態→誘惑→衰敗 |
| 誘惑 | 禁果的吸引與代價 | 誘惑呈現→掙扎→選擇後果 |
| 變形 | 身份或形態的根本改變 | 原有形態→轉化過程→新形態 |
| 怪物 | 面對並征服恐懼 | 威脅出現→對抗→克服/毀滅 |
| 超人 | 能力遠超常人者的故事 | 特殊能力→挑戰→影響邊界 |
| 悲劇 | 因缺陷或命運走向毀滅 | 弱點埋下→命運推進→不可逆毀滅 |

- 至少引用 **4 個關鍵轉折點的原文段落**
- 說明 Scene（場景）與 Summary（摘要）的比例

**⑤ 文風肖像**
- 3 個文風標籤：用動詞短語，如「以身體感知切入抽象哲學」「用破折號製造窒息節奏」
- 「最接近作家」給出量化理由（如「同樣動詞/名詞佔比高，句長方差相近」）
- 文風危險：過度使用時的問題（如「意象過密導致感官疲勞」）

**⑥ 句子功能分類**

功能類型：鋪墊 / 行動 / 轉折 / 高潮 / 描寫 / 心理 / 對話 / 議論

文本 > 5000 字時只取前 50 句，在報告中標明「取樣：前 X 句」。完成後計算各類功能的句數和佔比。

### semantic.md 格式要求

AI 只需寫第二、三部分的正文散文，**不需要寫第一部分的數字和表格**（那些由 pdf_report.py 直接從 JSON 生成）。

```markdown
## 第二部分：語意分析

### 七、意象系統

（分析正文……）

### 八、敘述聲音
...

### 九、修辭格
...

### 十、情節結構
...

### 十一、文風肖像
...

### 十二、句子功能分類
...

---

## 第三部分：文風診斷摘要

### 一、文風定義
...

### 二、核心特徵
...

### 三、語言密度分析
...

### 四、與其他作家的對比
...

### 五、綜合評語
...
```

---

## 4. Step 3：輸出 PDF

```bash
python scripts/pdf_report.py \
  --stats   stats.json \
  --ai      semantic.md \
  --output  "《作品名》_文風分析.pdf" \
  --title   "《作品名》文風拆解報告" \
  --author  "分析者姓名" \
  --theme   warm-academic
```

**pdf_report.py 的工作方式：**

- 第一部分（基礎數據）：直接從 `stats.json` 構建 reportlab 表格，不解析 Markdown，速度快
- 第二、三部分：讀取 `semantic.md`，解析純散文（無大型表格），解析速度快
- 合併輸出帶封面、目錄、頁眉頁腳的完整 PDF

**可用主題（`--theme` 參數）：**

| 主題名 | 風格 |
|--------|------|
| warm-academic | 暖棕色調，書卷感（預設） |
| dark-ink | 深色底，白字，現代感 |
| minimal | 極簡黑白 |
| scholar | 學術藍灰 |

---

## 5. 字段速查表

| 模塊 | 字段 | 類型 | 說明 |
|------|------|------|------|
| **meta** | total_cjk | int | 總漢字數 |
| | unique_chars | int | 不重複字種數 |
| | rare_chars | int | 生僻字種數（全文只出現1次）|
| | sent_count / para_count | int | 句數 / 段落數 |
| | avg_sent_len | float | 平均句長（漢字）|
| | max_sent_len / min_sent_len | int | 最長/最短句字數 |
| | rhythm | str | 平穩 / 起伏 / 強烈對比 |
| | punct_density | float | 每百漢字標點數 |
| | dialog_pct | float | 含對話句佔比（%）|
| **chars** | total_cjk | int | 同 meta |
| | unique / rare_count | int | 字種數 / 生僻字數 |
| | content_count / func_count | int | 實詞字種 / 虛詞字種 |
| | content_freq | list[(str,int)] | 實詞字頻，降序，max 80 |
| | func_freq | list[(str,int)] | 虛詞字頻，降序，max 40 |
| | rare | list[str] | 生僻字列表 |
| | rare_char_contexts | dict{str: list[str]} | 生僻字→原文例句（每字≤2句）|
| | imagery_chars | dict{cluster:{total,chars}} | 7類意象字統計 |
| **words** | top_words | list[(str,int)] | 實詞詞頻，降序，max 80 |
| | func_words | list[(str,int)] | 虛詞詞頻，降序，max 30 |
| | pos_dist | dict{label:int} | 詞性分布（次數）|
| | pos_ratios | dict{label:float} | 詞性佔比（%）含名/動/形/副/代/數/成語/慣用語 |
| | pronouns | list[(str,int)] | 代詞頻率 |
| | idioms | list[(str,int)] | 成語頻率 |
| | rare_words | dict{word:{level,count,pos,dict_freq}} | v3.0 level=特色詞/低頻詞；基於文本內頻率而非jieba詞典頻率分類 |
| | rare_word_contexts | dict{word:list[str]} | 特色詞/低頻詞→原文例句（每詞≤2句）|
| | person_names | list[(str,int)] | 人名頻率（nr詞性），v3.0獨立收集不混入content_tokens |
| | proper_nouns | list[(str,int)] | 專有名詞頻率（nr/ns/nz），v3.0獨立收集不混入content_tokens |
| **sents** | count | int | 句數 |
| | avg_len / variance | float | 均長 / 方差 |
| | max_len / min_len | int | 最長/最短句字數 |
| | rhythm | str | 節奏評估 |
| | type_dist | dict | 短句/中句/長句/超長句各自句數（v3.1：閾值 ≤12/13-30/31-50/>50）|
| | open_dist | dict | 句首類型分布（12類）|
| | rhet_dist | dict | 修辭格分布 |
| | dialog_pct | float | 對話句佔比（%）|
| | sents | list[dict] | 每句：id/text/clen/type/dialog/open/rhetoric |
| **paras** | count | int | 段落數 |
| | avg_len / avg_sc | float | 均字數 / 均句數 |
| | max_len / min_len | int | 最長/最短段字數 |
| | bucket_dist | dict | 極短/短/中/長/超長各自段數 |
| | single_sent | int | 單句段數量 |
| | paras | list[dict] | 每段：id/text/clen/sc/avg_sent/bucket |
| **punct** | total / density | int/float | 標點總數 / 每百字密度 |
| | dash_count / ellipsis_count / pause_count | int | 破折號/省略號/頓號數 |
| | dash_contexts / ellipsis_contexts | list[str] | 各自原文例句（≤10句）|
| | counts | dict{標點:int} | 各標點次數 |

---

## 6. 報告結構模板

> **佔比規則（全局）**：每一條統計數據必須同時給出「絕對數」和「百分比」。
> 正確：「短句 748 句（34.0%）」「名詞 4,872 個（28.6%）」
> 錯誤：「短句佔 34%」「名詞佔比 28.6%」
> 唯一例外：均值類指標（均句長、均段長等）只給絕對數。

---

```
# 《作品名》文風拆解報告

> 分析時間：YYYY-MM-DD　·　引擎版本：wenfen-dissector v3.1

---

## 第一部分：基礎數據
（以下各節表格由 pdf_report.py 直接從 stats.json 生成，AI 無需撰寫）

### 概覽數據表
| 指標 | 數值 |
|------|------|
| 總漢字數 | X 字 |
| 不重複字種 | X 種 |
| 生僻字種（僅出現1次）| X 種（佔字種 X%）|
| 實詞字種 | X 種（佔字種 X%）|
| 虛詞字種 | X 種（佔字種 X%）|
| 總句數 | X 句 |
| 平均句長 | X 漢字/句 |
| 最長句 / 最短句 | X 字 / X 字 |
| 句長方差 · 節奏 | X · 平穩/起伏/強烈對比 |
| 含對話句 | X% |
| 總段落數 | X 段 |
| 平均段落長 | X 漢字/段 |
| 平均句數/段 | X 句/段 |
| 標點密度 | X 個/百字 |
| 破折號 / 省略號 | X / X |

### 一、字頻特徵

#### 1.1 總體字種數據
| 類別 | 字種數 | 佔總字種 |
（from chars）

#### 1.2 意象字庫
| 意象類別 | 次數 | 佔意象字總量 | 高頻字 |
（from chars.imagery_chars）

#### 1.3 高頻實詞字 TOP20
| 排名 | 字 | 次數 | 佔總字 | 頻率條 |
（from chars.content_freq，含 bar chart 列）

#### 1.4 高頻虛詞字 TOP10
| 排名 | 字 | 次數 | 佔總字 |
（from chars.func_freq）

---

### 二、詞頻與詞性

#### 2.1 詞性分布
| 詞性 | 次數 | 佔比 |
（from words.pos_dist / pos_ratios）

#### 2.2 高頻實詞 TOP30
| 排名 | 詞 | 次數 | 佔詞頻 | 頻率條 |
（from words.top_words）

#### 2.3 成語與慣用語
| 成語/慣用語 | 次數 | 佔成語總量 |
（from words.idioms）

---

### 三、句型分析

#### 3.1 句長分布
| 句型 | 字數範圍 | 句數 | 佔比 |
（from sents.type_dist）

#### 3.2 節奏與對話
| 指標 | 數值 |
（avg_len, max/min_len, variance, rhythm, dialog_pct）

#### 3.3 句首類型分布
| 句首類型 | 句數 | 佔比 |
（from sents.open_dist）

#### 3.4 修辭格分布（統計層）
| 修辭格 | 句數 | 佔標注句 |
（from sents.rhet_dist）

---

### 四、段落結構

#### 4.1 段落長度分布
| 長度等級 | 字數範圍 | 段數 | 佔比 |
（from paras.bucket_dist）

#### 4.2 關鍵段落數據
| 指標 | 數值 |
（count, avg_len, avg_sc, max/min_len, single_sent）

---

### 五、標點符號

#### 5.1 標點分布
| 標點 | 名稱 | 次數 | 佔標點總量 |
（from punct.counts）

#### 5.2 破折號語境（全部例句，from punct.dash_contexts）
「…—…」

#### 5.3 省略號語境（全部例句，from punct.ellipsis_contexts）
「…………」

---

### 六、稀有字與稀有詞

#### 6.1 稀有字（全文僅出現1次）
共 X 種（佔全部字種 X%）。
Concordance 表（字 | 原文語境）：
（from chars.rare + rare_char_contexts，至少展示 15 字的語境）

#### 6.2 稀有詞（自造詞 / 低頻詞）
自造詞 X 個 · 低頻詞 X 個。
（from words.rare_words + rare_word_contexts，v3.0：特色詞全部展示含詞典頻率；低頻詞展示前30；另增2.5節人名與專有名詞）
---

## 第二部分：語意分析
（以下由 AI 撰寫，保存為 semantic.md，由 pdf_report.py 合併）

### 七、意象系統
- 核心意象（3-6個），每個含：次數、感官來源、象徵含義、≥3個原文例句
- 意象系統性質（系統型/散漫型/雙線並行）
- 整體評價（100字內）

### 八、敘述聲音
- 人稱、敘述距離、可靠性、自由間接引語（含例句）、情感溫度
- 原文例句 ≥5段，演示聲音特徵
- 整體聲音描述（100字內）

### 九、修辭格
每種修辭格：
- 名稱 · 頻次 · 是否標誌性
- ≥2個原文例句（含上下文）+ 功能說明
- 主要修辭格總結 + 風格評價（80字內）

### 十、情節結構
- 情節類型識別（從20種中選，可多選）
- 敘事動力（目標/謎題/情緒/氛圍驅動）
- 時間結構（順/倒/插敘說明）
- 衝突層級（人vs人/環境/自我/命運）
- Scene vs Summary 估算比例
- 關鍵轉折點 ≥4處（附原文段落）
- 整體結構評價（100字內）

### 十一、文風肖像
- 文風標籤 × 3（動詞短語），每個附 ≥2段原文佐證
- 氣質描述（150字內）
- 最接近作家 + 量化理由（50字內）
- 文風危險（50字內）

### 十二、句子功能分類
取樣說明（前X句/全文X句）

功能分布表：
| 功能類型 | 句數 | 佔比 |
（鋪墊/行動/轉折/高潮/描寫/心理/對話/議論）

逐句列表：
[句號] [功能] 句子文本（10字理由）

敘事節奏評估（100字內）

---

## 第三部分：文風診斷摘要
（由 AI 撰寫，保存在 semantic.md 同一文件中）

> 本部分原文引句不少於20處，且必須與第一、二部分引用過的句子不重複。

### 一、文風定義
2-3句概括整體文風，附 ≥3段原文引句。

### 二、核心特徵
3-5個最突出特徵，每個特徵：
- 特徵名稱 + 一句話定義
- 數據支撐（引具體統計數字及佔比）
- ≥2段原文佐證 + 一句分析說明

### 三、語言密度分析
提取句長方差、標點密度、實/虛詞比、意象字佔比等關鍵密度指標，逐一陳述，每個指標 ≥1段原文演示語感。

### 四、與其他作家的對比
2-3位最接近的作家，每位：
- 相似點（量化 + 定性）
- 差異點
- 對方代表作引句 + 本文引句並列對照

### 五、綜合評語
總結性文字（回扣關鍵發現），附 2-3段原文收束。
```

---

## 7. 全局引句規範

**總量底線：**

| 部分 | 最低引句數 |
|------|----------|
| 第一部分（基礎數據）| ≥40處 |
| 第二部分（語意分析）| ≥30處 |
| 第三部分（文風診斷摘要）| ≥20處（且必須為新例句，不得重複）|
| **全報告合計** | **≥90處** |

**各節強制引句：**

| 章節 | 最低引句 |
|------|---------|
| 1.3 高頻實詞字（前20字）| 每字 ≥1句 = 20處 |
| 5.2 / 5.3 破折號/省略號 | 各自全部語境（≤10處）|
| 6.1 稀有字 | ≥15處 |
| 6.2 稀有詞（自造詞全部 + 低頻詞）| ≥15處 |
| 7.1 每個核心意象 | ≥3句 |
| 8 敘述聲音 | ≥5句 |
| 9 修辭格（每種）| ≥2句（含上下文）|
| 10 情節結構轉折點 | ≥4段 |
| 11 文風肖像（每個標籤）| ≥2句 |
| 12.2 句子功能列表 | 全部取樣句（每句1引）|
| 第三部分 | ≥20處新句 |

**引句格式：**
- 格式：`「原文內容」`
- 需注明出處：`「原文內容」（第X章）`
- 精準引用，不得改寫、概括、拼接

---

## 8. 注意事項

### 長文本策略

| 文本長度 | 策略 |
|---------|------|
| < 1,000字 | 全文分析，報告首部標注「文本較短，統計結果僅供參考」|
| 1,000 – 100,000字 | 全文分析 |
| > 100,000字 | analyze.py 自動分塊合併；語意分析只取前5,000字，報告標注取樣範圍 |
| > 200,000字 | 建議分章節多次分析，或取開頭/中段/結尾各5,000字對比分析 |

### 繁/簡體說明

> ⚠️ 本工具 jieba 詞典基於簡體中文訓練，繁體文本的詞性標注和稀有詞識別準確率約降低 15-25%。分析繁體文本時，在報告首部加注：「jieba 分詞基於簡體詞典，詞性標注和稀有詞識別結果僅供參考，建議結合原文語感校驗。」

### 錯誤處理

```python
result = run(text)
if 'error' in result:
    # 常見錯誤：
    # 'Empty input'     → 文本為空
    # 'Text too short'  → 漢字數 < 100，無統計意義
    print(f"分析失敗：{result['error']}")
```

### 輸出文件命名

```python
import re
safe_title = re.sub(r'[\\/:*?"<>|《》]', '', work_title)
stats_path  = f"{safe_title}_stats.json"
ai_path     = f"{safe_title}_semantic.md"
output_path = f"{safe_title}_文風分析.pdf"
```
