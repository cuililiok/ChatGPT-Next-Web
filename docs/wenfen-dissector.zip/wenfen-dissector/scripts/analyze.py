#!/usr/bin/env python3
"""
文风拆解器 — 统计分析引擎 v3.2
Usage: python3 analyze.py <text_file>
       echo "文本" | python3 analyze.py
Output: JSON to stdout

v3.2 变更：
- 句子切分允许单字句（"好。""不。"），不再强制 2+ 字句身
- 修辞检测改进：
  · 反问检测改用「岂/岂能/何尝/何曾/何必/难道」等真正的反问标记
  · 排比改为更严格的「相邻短句长度近似 + 词性序列重复」启发式
  · 反复检测拆为"叠字"（AA）/"复辞"（不...不...）/"低多样性"，避免一句被多次标记
  · 引擎在 sents.note 字段写明"统计层粗粒度，仅做参考"
- 意象字库扩展为 9 类（新增"动物"和"建筑"），扩充身体/自然/器物等类别
- FUNC_CHARS 标注为现代汉语集（文言虚词另置）

v3.1（保留）：
- _sent_bucket / _para_bucket 分离
- PUNCT_SET 显式列举
- 意象库繁简双库
- is_cjk 覆盖 Basic + Ext A + Ext B + Compat
- rhetoric 转 list（JSON 可序列化）
"""

import sys, json, re, statistics
from collections import Counter

__version__ = "3.2"

# ── jieba setup ──
try:
    import jieba
    import jieba.posseg as pseg
    jieba.setLogLevel(60)
    HAS_JIEBA = True
except ImportError:
    HAS_JIEBA = False
    print("[WARN] jieba 未安装，词频/词性分析将跳过。执行: pip install jieba", file=sys.stderr)

# ════════════════════════════════════════════════
# CONSTANTS
# ════════════════════════════════════════════════

def is_cjk(c):
    """判断是否为 CJK 汉字。覆盖：
    - Basic    (U+4E00-U+9FFF)
    - Ext A    (U+3400-U+4DBF)
    - Ext B    (U+20000-U+2A6DF)
    - Compat   (U+F900-U+FAFF)
    """
    cp = ord(c)
    return (
        0x4E00 <= cp <= 0x9FFF
        or 0x3400 <= cp <= 0x4DBF
        or 0x20000 <= cp <= 0x2A6DF
        or 0xF900 <= cp <= 0xFAFF
    )

# 标点集合：显式列举，避免字符串拼接的歧义和重复
PUNCT_SET = frozenset([
    # 中文常用标点
    '，', '。', '！', '？', '；', '：', '、',
    '…', '—', '～', '·',
    # 中文引号 / 括号 / 书名号
    '“', '”', '‘', '’',
    '「', '」', '『', '』',
    '（', '）', '【', '】',
    '《', '》', '〈', '〉',
    # 英文标点（中文文本中偶尔混用）
    ',', '.', '!', '?', ';', ':',
    '"', "'",
    '(', ')', '[', ']', '{', '}',
])

# 现代汉语虚词字集合（80 余字）。
# 注：本集合主要覆盖现代汉语高频虚词，不含「岂/孰/莫/弗/乃/胡/耶」等
# 文言虚词。分析古典文本时，这些字会被归入"实词字"，
# 导致虚词比偏低、实词字种偏高——分析报告应在此情况下做出说明。
FUNC_CHARS = set(
    '的了是在我他她它你们們和或与與也都就但而如为為以对對很太更最不没沒有要会會能可得着著过過'
    '把被让讓从從到里裡上下中来來去说說道这這那其此已将將曾又再还還只则則于於之乎者哉夫矣焉且若虽雖'
    '然故因所即何啊呢吧哦嗯哪'
)

POS_MAP = {
    'n':'名词','nr':'人名','ns':'地名','nz':'专名','ng':'名语素',
    'v':'动词','vd':'副动词','vn':'动名词','vg':'动词语素',
    'a':'形容词','ad':'副形容词','an':'形名词',
    'd':'副词','p':'介词','c':'连词',
    'm':'数词','q':'量词','r':'代词',
    't':'时间词','s':'处所词','f':'方位词',
    'x':'标点','u':'助词','y':'语气词','e':'叹词',
    'i':'成语','l':'惯用语','j':'缩略语',
}

# 实词词性（用于content_tokens），不含专有名词nr/ns/nz
CONTENT_POS = {'n','ng','v','vd','vn','vg','a','ad','an','i','l','j','t','s'}

# ════════════════════════════════════════════════
# 意象字库 v3.2：9 类，每类提供简体 + 繁体字符集
# ════════════════════════════════════════════════
_IMAGERY_RAW = {
    '身体': (
        '眼脸手脚腰背肩胸腹头发耳口唇鼻心肺肠血骨皮肉指甲肤颈臂腿膝肘掌齿舌须眉额',
        '眼臉手腳腰背肩胸腹頭髮耳口唇鼻心肺腸血骨皮肉指甲膚頸臂腿膝肘掌齒舌鬚眉額',
    ),
    '颜色': (
        '红白黑黄蓝绿紫金银灰棕橙粉褐青朱碧赤墨翠',
        '紅白黑黃藍綠紫金銀灰棕橙粉褐青朱碧赤墨翠',
    ),
    '自然': (
        '山水风云雨雪日月星天地花草树叶石沙海河湖原野田川岭崖溪谷霜露霞雾烟泉',
        '山水風雲雨雪日月星天地花草樹葉石沙海河湖原野田川嶺崖溪谷霜露霞霧煙泉',
    ),
    '光影': (
        '光暗影明亮淡闪阴晴阳曦暮昏黎曙昼夜辉煌黯朦胧',
        '光暗影明亮淡閃陰晴陽曦暮昏黎曙晝夜輝煌黯朦朧',
    ),
    '时间': (
        '年月日时秒春夏秋冬古今昔往后曾旦昔朝夕晨午夜瞬',
        '年月日時秒春夏秋冬古今昔往後曾旦昔朝夕晨午夜瞬',
    ),
    '器物': (
        '门窗墙桌椅床灯书杯碗刀剑镜笔琴箫笛钟鼓帘扇砚纸帆舟舸席案',
        '門窗牆桌椅床燈書杯碗刀劍鏡筆琴簫笛鐘鼓簾扇硯紙帆舟舸席案',
    ),
    '情感': (
        '爱恨悲欢喜怒哀惧愁忧寂寞孤思念怨恋慕',
        '愛恨悲歡喜怒哀懼愁憂寂寞孤思念怨戀慕',
    ),
    # v3.2 新增
    '动物': (
        '鸟兽虫鱼龙凤鹤雁鹰莺鸠燕鹊鹭鸥鹿马牛羊犬猫鼠蛇蝶蛾蝉鸣',
        '鳥獸蟲魚龍鳳鶴雁鷹鶯鳩燕鵲鷺鷗鹿馬牛羊犬貓鼠蛇蝶蛾蟬鳴',
    ),
    '建筑': (
        '殿阁亭台楼榭堂屋宅院廊柱檐栏阶轩轩塔阙宫府堂庙寺观',
        '殿閣亭台樓榭堂屋宅院廊柱簷欄階軒軒塔闕宮府堂廟寺觀',
    ),
}
IMAGERY_CLUSTERS = {k: set(simp) | set(trad) for k, (simp, trad) in _IMAGERY_RAW.items()}

# ════════════════════════════════════════════════
# CONTEXT HELPERS
# ════════════════════════════════════════════════

def _get_contexts(text, target, max_results=5):
    """返回含 target 的完整句子列表（句末标点切分）。"""
    results = []
    for m in re.finditer(r'[^。！？\n]{0,40}' + re.escape(target) + r'[^。！？\n]{0,40}', text):
        sentence = m.group(0).strip()
        if sentence:
            results.append(sentence)
        if len(results) >= max_results:
            break
    return results


def _sent_bucket(clen):
    """句子长度分桶（汉字数）。"""
    if clen <= 12:  return '短句'
    if clen <= 30:  return '中句'
    if clen <= 50:  return '长句'
    return '超长句'


def _para_bucket(clen):
    """段落长度分桶（汉字数）。粒度比句子更粗。"""
    if clen <= 30:  return '极短'
    if clen <= 80:  return '短'
    if clen <= 200: return '中'
    if clen <= 400: return '长'
    return '超长'

# ════════════════════════════════════════════════
# SENTENCE ANALYSIS
# ════════════════════════════════════════════════

def detect_open(s):
    if not s: return '其他'
    c = s[0]
    if c in '他她它它们其': return '代词起句'
    if c in '的了是在': return '虚词起句'
    if '\u4e00' <= c <= '\u9fff':
        return '名词/实词起句'
    if c in '“”「『': return '引语起句'
    return '其他'


def classify_rhetoric(s):
    """检测修辞格 / 句间逻辑关系。返回 set。
    v3.2：本函数仅做粗粒度模式识别，作为线索供 AI 语意层参考；
    精细辞格识别（暗喻、博喻、借代、对偶、顶真、设问/反问区分等）
    应由 AI 阅读原文后判断。
    """
    types = set()

    # === 比喻类 ===
    # 明喻：含「像/似/如/犹/仿佛/好比」+ 「一样/般/似的/一般」
    if re.search(r'(像|似|如|猶|犹|彷彿|仿佛|好比)', s) and \
       re.search(r'(一樣|一样|般|似的|一般)', s):
        types.add('明喻')
    # 对比：不是 X 而是 Y
    if '不是' in s and '而是' in s:
        types.add('对比')

    # === 反复 / 复辞 / 叠字（互斥分类，避免一句被多次标记） ===
    pairs = re.findall(r'([\u4e00-\u9fff])\1', s)
    aa_count = len(pairs)
    cf_match = bool(re.search(r'(不|没|沒).{0,3}(不|没|沒)', s))
    low_div = (len(set(s)) / max(len(s), 1) < 0.45 and len(s) > 8)

    # 互斥优先级：叠字（多个 AA） > 复辞（不...不...）> 反复（低多样性）
    if aa_count >= 2:
        types.add('叠字')
    elif cf_match and len(s) >= 4:
        types.add('复辞')
    elif low_div:
        types.add('反复')

    # === 排比（更严格：≥3 短句段 + 长度近似 + 不含分号）===
    if not s.count('；'):
        segs = re.split(r'[，,]', s)
        segs = [seg.strip() for seg in segs if seg.strip()]
        if len(segs) >= 3:
            seg_lens = [len(seg) for seg in segs]
            avg_len = sum(seg_lens) / len(seg_lens)
            if avg_len >= 3:  # 短分句要至少 3 字
                # 长度方差小（变化系数 < 0.4）
                variance = sum((l - avg_len) ** 2 for l in seg_lens) / len(seg_lens)
                cv = (variance ** 0.5) / avg_len if avg_len > 0 else 1
                if cv < 0.4:
                    types.add('排比')

    # === 反问（v3.2 重写：用真正的反问标记词）===
    if re.search(r'(豈|岂|難道|难道|何嘗|何尝|何曾|何必|何不|何苦|何須|何须|怎能|怎可|焉能|寧不|宁不)', s):
        if s.endswith('？') or s.endswith('?') or s.endswith('！') or s.endswith('!'):
            types.add('反问')
        elif '？' in s or '?' in s:
            types.add('反问')

    # === 设问（自问自答）===
    if re.search(r'[？?].{0,30}[。.]', s) and not re.search(r'(豈|岂|難道|难道|何尝|何嘗)', s):
        # 句中含问号但不是反问，可能是设问；让 AI 层最终判断
        pass  # v3.2：暂不自动标记设问，避免误报

    # === 句间逻辑关系 ===
    if re.search(r'(然|而|却|但|虽|尽管|雖|儘管|卻).{1,8}(却|但|然而|可是|卻|不過|不过)', s):
        types.add('转折')
    if re.search(r'(雖然|虽然|尽管|儘管|即使|縱然|纵然).{2,15}(也|還|还|仍|依然)', s):
        types.add('让步')
    if re.search(r'(連|连).{1,4}[都也]', s):
        types.add('递进')
    if re.search(r'(真|好|很|太|极|十分|非常|格外|極).{1,4}(啊|呀|呢|了|的)', s) or \
       (s.endswith('！') or s.endswith('!')) and len(s) <= 20:
        types.add('感叹')
    if re.search(r'(因为|由于|因為|由於).{2,30}(所以|因此|故|以致|於是|于是)', s):
        types.add('因果')
    if re.search(r'(如果|假若|倘若|要是|即使|若是|若).{2,20}(就|便|也|则|則|將|将)', s):
        types.add('假设')
    return types


# ════════════════════════════════════════════════
# CHARACTER ANALYSIS
# ════════════════════════════════════════════════

def analyze_chars(text):
    cjk  = [c for c in text if is_cjk(c)]
    freq = Counter(cjk)

    content_freq = sorted([(c,n) for c,n in freq.items() if c not in FUNC_CHARS], key=lambda x:-x[1])
    func_freq    = sorted([(c,n) for c,n in freq.items() if c in FUNC_CHARS],     key=lambda x:-x[1])
    rare_chars   = [c for c,n in freq.items() if n == 1]

    rare_char_contexts = {}
    for c in rare_chars[:60]:
        ctxs = _get_contexts(text, c, max_results=2)
        if ctxs:
            rare_char_contexts[c] = ctxs

    imagery = {}
    for cluster, chars in IMAGERY_CLUSTERS.items():
        hits = {c: freq[c] for c in chars if c in freq}
        if hits:
            imagery[cluster] = {'total': sum(hits.values()), 'chars': hits}

    return {
        'total_cjk':          len(cjk),
        'unique':             len(freq),
        'content_count':      len(content_freq),
        'func_count':         len(func_freq),
        'rare_count':         len(rare_chars),
        'content_freq':       content_freq[:80],
        'func_freq':          func_freq[:40],
        'rare':               rare_chars,
        'rare_char_contexts': rare_char_contexts,
        'all_freq':           freq.most_common(5000),
        'imagery_chars':      imagery,
    }

# ════════════════════════════════════════════════
# WORD ANALYSIS
# ════════════════════════════════════════════════

def _is_segmented_pseudo(word):
    """判断 word 是否是 jieba 分词粘连产生的伪词。

    保守策略：只把每段都≤1字（即被切成单字串）的判为伪词，
    避免把"然而"这种合法双字词误杀。
    """
    if not HAS_JIEBA or len(word) < 2:
        return False
    try:
        standalone = list(jieba.cut(word))
        # 只有当 jieba 把它切成全部单字时才判伪词
        if len(standalone) > 1 and all(len(s) == 1 for s in standalone if s.strip()):
            return True
    except Exception:
        pass
    return False


def _detect_word_features(content_tokens, text=''):
    """检测词汇特征（基于文本内频率）。"""
    if not content_tokens:
        return {}

    rare = {}
    try:
        text_freq = Counter(w for w, _ in content_tokens)
        all_counts = list(text_freq.values())
        if not all_counts:
            return {}

        median_freq = statistics.median(all_counts)
        sents = re.split(r'[。！？；…]', text)

        for w, f in content_tokens:
            if w in rare:
                continue
            count = text_freq[w]
            dict_freq = jieba.dt.FREQ.get(w, 0) if HAS_JIEBA else 0

            if _is_segmented_pseudo(w):
                continue
            cross_sent = sum(1 for s in sents if w in s)
            if cross_sent < 2:
                continue

            if count <= 3:
                rare[w] = {'level': '低频词', 'count': count,
                           'pos': f, 'dict_freq': dict_freq}
            elif count >= median_freq and dict_freq <= 2:
                rare[w] = {'level': '特色词', 'count': count,
                           'pos': f, 'dict_freq': dict_freq}
    except Exception:
        pass
    return rare


def analyze_words(text):
    if not HAS_JIEBA:
        return {
            'top_words':[],'func_words':[],'pos_dist':{},'pos_ratios':{},
            'pronouns':[],'idioms':[],'rare_words':{},'rare_word_contexts':{},'wpos':{},
            'person_names':[],'proper_nouns':[],
        }

    pairs  = list(pseg.cut(text))
    tokens = [(w.word.strip(), w.flag) for w in pairs if w.word.strip()]

    proper_nouns = Counter()
    content_tokens, func_tokens = [], []

    for w, f in tokens:
        if not any(is_cjk(c) for c in w) or len(w) < 2:
            continue

        if f.startswith(('nr', 'ns', 'nz')):
            dict_freq = jieba.dt.FREQ.get(w, 0) if HAS_JIEBA else 0
            if dict_freq > 5000:
                content_tokens.append((w, f))
            else:
                proper_nouns[w] += 1
            continue

        if f[:1] in CONTENT_POS:
            content_tokens.append((w, f))
        else:
            func_tokens.append((w, f))

    content_freq = Counter(w for w,_ in content_tokens)
    func_freq    = Counter(w for w,_ in func_tokens)

    all_cjk  = [(w,f) for w,f in tokens if any(is_cjk(c) for c in w) and len(w) >= 2]
    pos_dist = Counter(POS_MAP.get(f[:2],'其他') for w,f in all_cjk)

    pronoun_freq = Counter(w for w,f in tokens if f.startswith('r') and any(is_cjk(c) for c in w))
    idiom_freq   = Counter(w for w,f in tokens if f.startswith('i') and any(is_cjk(c) for c in w))

    proper_noun_set = set(proper_nouns.keys())
    filtered_tokens = [(w, f) for w, f in content_tokens if w not in proper_noun_set]
    rare_words = _detect_word_features(filtered_tokens, text=text)
    rare_word_contexts = {}
    for w in rare_words:
        ctxs = _get_contexts(text, w, max_results=2)
        if ctxs:
            rare_word_contexts[w] = ctxs

    wpos = {}
    for w, cnt in content_freq.items():
        if cnt >= 2:
            positions, start = [], 0
            while True:
                idx = text.find(w, start)
                if idx < 0: break
                positions.append(idx); start = idx + 1
            wpos[w] = positions

    total_content = sum(v for k,v in pos_dist.items() if k not in ('标点','助词','语气词','其他'))
    ratios = {k: round(pos_dist.get(k,0)/max(total_content,1)*100, 1)
              for k in ['名词','动词','形容词','副词','代词','数词','成语','惯用语']}

    return {
        'top_words':          content_freq.most_common(80),
        'func_words':         func_freq.most_common(30),
        'pos_dist':           dict(pos_dist.most_common()),
        'pos_ratios':         ratios,
        'pronouns':           pronoun_freq.most_common(20),
        'idioms':             idiom_freq.most_common(20),
        'person_names':       proper_nouns.most_common(40),
        'proper_nouns':       proper_nouns.most_common(40),
        'rare_words':         rare_words,
        'rare_word_contexts': rare_word_contexts,
        'wpos':               wpos,
    }

# ════════════════════════════════════════════════
# SENTENCE ANALYSIS
# ════════════════════════════════════════════════

# 句子切分正则：句身允许 1+ 个非句末字符（v3.2，原 {2,} 会漏掉单字句"好。""不。"）
_SENT_RE = re.compile(r'[^。！？\n]+[。！？…]+')


def analyze_sentences(text):
    sents = []
    for m in _SENT_RE.finditer(text):
        t = m.group(0).strip()
        if not t:
            continue
        cjk_len = len([c for c in t if is_cjk(c)])
        if cjk_len == 0:
            # 跳过纯标点段（如多个句号连排）
            continue
        rhetoric = classify_rhetoric(t)
        dialog  = bool(re.match(r'\s*[“"「『]', t) or re.search(r'[”"」』]\s*[。，]', t))
        opening = detect_open(t)
        sents.append({
            'id': len(sents) + 1,
            'text': t, 'clen': cjk_len,
            'type': _sent_bucket(cjk_len),
            'dialog': dialog,
            'open': opening,
            'rhetoric': sorted(rhetoric),
        })

    if not sents:
        return {'count':0,'avg_len':0,'max_len':0,'min_len':0,'variance':0,
                'rhythm':'','type_dist':{},'open_dist':{},'rhet_dist':{},
                'dialog_pct':0,'sents':[],
                'note': '统计层修辞识别为粗粒度模式匹配，仅作 AI 语意分析的线索参考。'}

    lens = [s['clen'] for s in sents]
    avg, mx, mn = sum(lens)/len(lens), max(lens), min(lens)
    var = round(sum((l-avg)**2 for l in lens)/len(lens), 1)

    buckets = Counter(s['type'] for s in sents)
    opens   = Counter(s['open'] for s in sents)
    rhets   = Counter()
    for s in sents:
        for r in s['rhetoric']:
            rhets[r] += 1
    dialog_n = sum(1 for s in sents if s['dialog'])
    dialog_pct = round(dialog_n / len(sents) * 100, 1)

    if mx > 3 * mn:
        rhythm = '强烈对比'
    elif var > avg * 0.5:
        rhythm = '起伏'
    else:
        rhythm = '平稳'

    return {
        'count': len(sents), 'avg_len': round(avg, 1), 'variance': var,
        'max_len': mx, 'min_len': mn, 'rhythm': rhythm,
        'type_dist': dict(buckets),
        'open_dist': dict(opens),
        'rhet_dist': dict(rhets),
        'dialog_pct': dialog_pct,
        'sents': sents,
        'note': '统计层修辞识别为粗粒度模式匹配（关键字 + 句法启发式），仅作 AI 语意分析的线索参考。',
    }

# ════════════════════════════════════════════════
# PARAGRAPH ANALYSIS
# ════════════════════════════════════════════════

def analyze_paragraphs(text):
    paras = [p.strip() for p in text.split('\n\n') if p.strip()]
    result = []
    for p in paras:
        cjk = len([c for c in p if is_cjk(c)])
        sent_count = len(re.findall(r'[。！？…]', p))
        avg_sent = round(cjk / max(sent_count, 1), 1)
        result.append({
            'id': len(result) + 1,
            'text': p, 'clen': cjk, 'sc': sent_count,
            'avg_sent': avg_sent, 'bucket': _para_bucket(cjk),
        })

    if not result:
        return {'count':0,'avg_len':0,'avg_sc':0,'max_len':0,'min_len':0,
                'bucket_dist':{},'single_sent':0,'paras':[]}

    lens = [p['clen'] for p in result]
    scs  = [p['sc'] for p in result]
    return {
        'count': len(result),
        'avg_len': round(sum(lens)/len(lens), 1),
        'avg_sc': round(sum(scs)/len(scs), 1),
        'max_len': max(lens), 'min_len': min(lens),
        'bucket_dist': dict(Counter(p['bucket'] for p in result)),
        'single_sent': sum(1 for p in result if p['sc'] == 1),
        'paras': result,
    }

# ════════════════════════════════════════════════
# PUNCTUATION ANALYSIS
# ════════════════════════════════════════════════

def analyze_punctuation(text):
    punc_chars = [c for c in text if c in PUNCT_SET]
    counts = Counter(punc_chars)
    total = len(punc_chars)
    cjk_count = len([c for c in text if is_cjk(c)])

    dashes = []
    for m in re.finditer(r'[^。！？\n]{0,30}—[^。！？\n]{0,30}', text):
        dashes.append(m.group(0).strip())
    ellipses = []
    for m in re.finditer(r'[^。！？\n]{0,30}…+[^。！？\n]{0,30}', text):
        ellipses.append(m.group(0).strip())
    pauses = []
    for m in re.finditer(r'[^。！？\n]{0,20}、[^。！？\n]{0,20}', text):
        pauses.append(m.group(0).strip())

    return {
        'total': total,
        'density': round(total / max(cjk_count, 1) * 100, 2),
        'dash_count': len(dashes),
        'ellipsis_count': len(ellipses),
        'pause_count': len(pauses),
        'dash_contexts': dashes[:10],
        'ellipsis_contexts': ellipses[:10],
        'counts': dict(counts),
    }

# ════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════

def run(text):
    text = text.strip()
    if not text:
        return {'error': 'Empty input'}
    if len([c for c in text if is_cjk(c)]) < 100:
        return {'error': 'Text too short (< 100 CJK characters). Analysis not meaningful.'}

    chars = analyze_chars(text)
    words = analyze_words(text)
    sents = analyze_sentences(text)
    paras = analyze_paragraphs(text)
    punct = analyze_punctuation(text)

    word_sent_idx = {}
    for w, cnt in (words.get('top_words') or []):
        if cnt >= 2:
            word_sent_idx[w] = [s['id'] for s in sents['sents'] if w in s['text']]

    return {
        'raw':   text,
        'chars': chars,
        'words': words,
        'sents': sents,
        'paras': paras,
        'punct': punct,
        'word_sent_idx': word_sent_idx,
        'meta': {
            'engine_version': __version__,
            'total_cjk':    chars['total_cjk'],
            'unique_chars': chars['unique'],
            'rare_chars':   chars['rare_count'],
            'sent_count':   sents['count'],
            'para_count':   paras['count'],
            'avg_sent_len': sents['avg_len'],
            'max_sent_len': sents['max_len'],
            'min_sent_len': sents['min_len'],
            'rhythm':       sents['rhythm'],
            'punct_density':punct['density'],
            'dialog_pct':   sents['dialog_pct'],
        }
    }


if __name__ == '__main__':
    if len(sys.argv) > 1:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            text = f.read()
    else:
        text = sys.stdin.read()
    result = run(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
