#!/usr/bin/env python3
"""
文風拆解器 — 報告生成工具
Usage:
  python3 report_tool.py analyze <text_or_file>

Step 1: 統計分析（必做）
Step 2: 生成 AI 語意分析所需的結構化數據（供 AI 閱讀）

這個腳本只做統計層。
語意層由 AI（本檔口中的「我」）根據 JSON 輸出親自書寫。
"""

import subprocess
import sys
import json
import os
from pathlib import Path

# 使用相对路径
SKILL_DIR = Path(__file__).parent.parent
ANALYZE_PY = SKILL_DIR / "scripts/analyze.py"


def run_stats(text: str) -> dict:
    """運行統計分析引擎"""
    tmp = Path("/tmp/wenfen_tool_input.txt")
    tmp.write_text(text, encoding="utf-8")

    result = subprocess.run(
        ["python3", str(ANALYZE_PY), str(tmp)],
        capture_output=True, text=True
    )

    if result.returncode != 0:
        raise RuntimeError(f"analyze.py error: {result.stderr}")

    return json.loads(result.stdout)


def build_report_bundle(d: dict) -> dict:
    """根據 JSON 構建 AI 分析所需的數據包"""
    meta = d["meta"]

    # 構建句子列表（用於 sentence_function 分析）
    sents_data = []
    for s in d["sents"]["sents"]:
        sents_data.append({
            "id": s["id"],
            "text": s["text"],
            "len": s["clen"],
            "type": s["type"],
            "open": s["open"],
            "dialog": s.get("dialog", False),
            "rhetoric": s.get("rhetoric", [])
        })

    # 構建高頻詞包
    top_words = d["words"]["top_words"][:20]

    # 構建 word → sent 映射（每個高頻詞出現在哪些句子）
    word_sent_map = {}
    for w, _ in top_words:
        sids = d["word_sent_idx"].get(w, [])
        word_sent_map[w] = [sents_data[sid]["text"] for sid in sids if sid < len(sents_data)]

    return {
        "meta": meta,
        "top_chars": d["chars"]["content_freq"][:15],
        "top_words": top_words,
        "word_sent_map": word_sent_map,
        "sents": sents_data,
        "paras": d["paras"]["paras"],
        "raw": d["raw"],
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 report_tool.py analyze <text_or_file>")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "analyze":
        # 讀取文本
        text_path = Path(sys.argv[2]) if len(sys.argv) > 2 else None
        if text_path and text_path.exists():
            text = text_path.read_text(encoding="utf-8")
        else:
            text = sys.argv[2] if len(sys.argv) > 2 else sys.stdin.read()

        if not text.strip():
            print("Error: empty text", file=sys.stderr)
            sys.exit(1)

        # 統計分析
        stats = run_stats(text)
        bundle = build_report_bundle(stats)

        # 輸出 AI 提示頭（告訴 AI 這是什麼任務）
        print(json.dumps(bundle, ensure_ascii=False, indent=2))

    else:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
