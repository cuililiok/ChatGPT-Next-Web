# 文风拆解器配置文件

class Config:
    # 文本分析配置
    MIN_TEXT_LENGTH = 100  # 最小文本长度（CJK字符）
    MAX_CHUNK_SIZE = 100000  # 大文本分段大小
    
    # 分析结果配置
    TOP_CHARS_LIMIT = 80  # 高频字符限制
    TOP_WORDS_LIMIT = 80  # 高频词限制
    RARE_CHARS_LIMIT = 60  # 稀有字符限制
    CONTEXT_MAX_RESULTS = 5  # 上下文最大结果数
    DASH_CONTEXTS_LIMIT = 10  # 破折号上下文限制
    ELLIPSIS_CONTEXTS_LIMIT = 10  # 省略号上下文限制
    
    # EPUB 分析配置
    SAMPLE_CHAPTERS = 10  # 采样章节数
    MIN_CHAPTER_LENGTH = 200  # 最小章节长度
    
    # 性能配置
    JIEBA_LOG_LEVEL = 60  # jieba 日志级别
    
    # 输出配置
    REPORT_ENCODING = 'utf-8'  # 报告编码
    JSON_INDENT = 2  # JSON 缩进
    
    # 路径配置
    DEFAULT_OUTPUT_DIR = './output'  # 默认输出目录
    TEMP_DIR = '/tmp/wenfen_tool'  # 临时目录

# 导出配置实例
config = Config()
