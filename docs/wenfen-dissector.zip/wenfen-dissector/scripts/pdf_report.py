#!/usr/bin/env python3
"""
文风拆解器 — PDF 报告生成器 v3.1

直接从 analyze.py 的 JSON 输出构建 reportlab 对象，跳过 Markdown 解析层。
第一部分（基础数据）所有表格从 JSON 直接生成，无 Markdown 中间层。
第二、三部分（语意分析 + 文风诊断）读取 AI 写的 Markdown 散文，解析速度快。

用法：
  python pdf_report.py \\
    --stats   stats.json       \\  # analyze.py 的 JSON 输出
    --ai      semantic.md      \\  # AI 写的第二、三部分文字
    --output  report.pdf       \\
    --title   "《XX》文风拆解报告"  \\
    --author  "分析者"           \\
    --theme   warm-academic

依赖：
  pip install reportlab
  md2pdf.py 需要在同一 scripts/ 目录下（或由 WENFEN_MD2PDF 环境变量指定路径）
"""

import sys, os, json, argparse, re, importlib.util
from pathlib import Path
from datetime import date
from collections import Counter

# ═══════════════════════════════════════════════════════════════════════
# 载入 md2pdf 基础设施
# ═══════════════════════════════════════════════════════════════════════

def _load_md2pdf():
    """在多个候选路径中找到并载入 md2pdf.py。"""
    candidates = [
        Path(os.environ.get("WENFEN_MD2PDF", "")),
        Path(__file__).parent / "md2pdf.py",
        Path(__file__).parent / "md2pdf.py.bak",
    ]
    # 搜寻灵犀常见安装路径
    for base in [Path.home() / "AppData/Roaming/WPS 灵犀/serverdir/skills",
                 Path("/root/.openclaw/workspace/skills"),
                 Path("/home") / os.environ.get("USER","user") / ".openclaw/workspace/skills"]:
        candidates.append(base / "any2pdf/scripts/md2pdf.py")
        candidates.append(base / "any2pdf/scripts/md2pdf.py.bak")

    for p in candidates:
        if p and p.exists():
            spec = importlib.util.spec_from_file_location("md2pdf", str(p))
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
    raise ImportError(
        "找不到 md2pdf.py。请设置环境变量 WENFEN_MD2PDF=/path/to/md2pdf.py，"
        "或将 md2pdf.py 放在 scripts/ 目录下。"
    )

_m = _load_md2pdf()

# 从 md2pdf 引入所需符号
register_fonts  = _m.register_fonts
load_theme      = _m.load_theme
THEMES          = _m.THEMES
PDFBuilder      = _m.PDFBuilder
HRule           = _m.HRule
HRuleCentered   = _m.HRuleCentered
ClayDot         = _m.ClayDot
ChapterMark     = _m.ChapterMark
_font_wrap      = _m._font_wrap
_is_cjk         = _m._is_cjk
md_inline       = _m.md_inline
esc             = _m.esc
esc_code        = _m.esc_code
LeftBorderParagraph = _m.LeftBorderParagraph

from reportlab.lib.units import mm
from reportlab.lib.colors import white, HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    Paragraph, Spacer, PageBreak, Table, TableStyle, Flowable
)

# ═══════════════════════════════════════════════════════════════════════
# 辅助：把百分比整合到 N 次（X%）格式
# ═══════════════════════════════════════════════════════════════════════

def _pct(count, total):
    if total <= 0: return "0.0%"
    return f"{count/total*100:.1f}%"

def _fmt(count, total, unit=""):
    return f"{count:,}{unit}（{_pct(count, total)}）"

# ═══════════════════════════════════════════════════════════════════════
# 简易情节树 Flowable（纯 reportlab 绘制，无 Mermaid）
# ═══════════════════════════════════════════════════════════════════════

class PlotTree(Flowable):
    """
    自适应情节流程图——根据情节类型使用不同节点标签和弧线形态。
    支持弯曲/上升/下降/颠覆/螺旋等箭头样式。
    nodes: list of (label, color_hex, caption) tuples
    arc_type: 'linear' | 'ascending' | 'descending' | 'subvert' | 'spiral'
    """
    def __init__(self, nodes, body_w, theme, arc_type='linear'):
        Flowable.__init__(self)
        self._nodes    = nodes
        self._body_w   = body_w
        self._theme    = theme
        self._arc_type = arc_type
        n = len(self._nodes)
        self._box_w    = min(36*mm, (body_w - (n-1)*8*mm) / n)
        self._box_h    = 14*mm
        self._total_w  = n * self._box_w + (n-1) * 8*mm
        max_offset = max(abs(o) for o in self._get_y_offsets(n)) if n > 0 else 0
        self._total_h  = self._box_h + 14*mm + max_offset * 2  # box + caption + arc label + offset margin
        self.width     = body_w
        self.height    = self._total_h + 6*mm

    def _draw_arrow(self, c, x1, y1, x2, y2):
        """绘制带箭头的连接线，根据弧线类型决定形状。"""
        import math
        T = self._theme

        if self._arc_type == 'linear':
            # 直线箭头
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            c.line(x1, y1, x2, y2)
            self._arrowhead(c, x2, y2, 0)

        elif self._arc_type == 'ascending':
            # 上升弧线
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            mid_x = (x1 + x2) / 2
            mid_y = max(y1, y2) + 3*mm
            p = c.beginPath()
            p.moveTo(x1, y1)
            p.curveTo(mid_x, mid_y, mid_x, mid_y, x2, y2)
            c.drawPath(p, fill=0, stroke=1)
            # Arrowhead angle based on curve tangent at endpoint
            angle = math.atan2(y2 - mid_y, x2 - mid_x)
            self._arrowhead(c, x2, y2, angle)

        elif self._arc_type == 'descending':
            # 下降弧线
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            mid_x = (x1 + x2) / 2
            mid_y = min(y1, y2) - 3*mm
            p = c.beginPath()
            p.moveTo(x1, y1)
            p.curveTo(mid_x, mid_y, mid_x, mid_y, x2, y2)
            c.drawPath(p, fill=0, stroke=1)
            angle = math.atan2(y2 - mid_y, x2 - mid_x)
            self._arrowhead(c, x2, y2, angle)

        elif self._arc_type == 'subvert':
            # 颠覆：先上升再骤降（S形）
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            mid_x = (x1 + x2) / 2
            p = c.beginPath()
            p.moveTo(x1, y1)
            p.curveTo(x1 + 2*mm, y1 + 4*mm, x2 - 2*mm, y2 + 4*mm, mid_x, y1)
            p.curveTo(mid_x, y1 - 5*mm, mid_x, y1 - 5*mm, x2, y2)
            c.drawPath(p, fill=0, stroke=1)
            self._arrowhead(c, x2, y2, -0.3)

        elif self._arc_type == 'spiral':
            # 螺旋：反复摆动
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            seg = 3
            dx = (x2 - x1) / seg
            dy = 2.5*mm
            p = c.beginPath()
            p.moveTo(x1, y1)
            for s in range(seg):
                sx = x1 + dx * s
                ex = x1 + dx * (s + 1)
                cy = y1 + dy * (1 if s % 2 == 0 else -1)
                p.curveTo(sx + dx*0.3, cy, ex - dx*0.3, cy, ex, y1)
            c.drawPath(p, fill=0, stroke=1)
            self._arrowhead(c, x2, y2, 0)
        else:
            c.setStrokeColor(T["border"])
            c.setLineWidth(0.8)
            c.line(x1, y1, x2, y2)
            self._arrowhead(c, x2, y2, 0)

    def _arrowhead(self, c, x, y, angle):
        import math
        c.setFillColor(self._theme["border"])
        size = 1.5*mm
        p = c.beginPath()
        p.moveTo(x, y)
        p.lineTo(x - size * math.cos(angle - 0.4), y - size * math.sin(angle - 0.4))
        p.lineTo(x - size * math.cos(angle + 0.4), y - size * math.sin(angle + 0.4))
        p.close()
        c.drawPath(p, fill=1, stroke=0)

    def draw(self):
        import math
        c = self.canv
        T = self._theme
        n = len(self._nodes)
        x_start = (self._body_w - self._total_w) / 2
        bh = self._box_h

        # 根据弧线类型调整节点垂直位置
        y_offsets = self._get_y_offsets(n)

        for i, (label, color_hex, caption) in enumerate(self._nodes):
            x = x_start + i * (self._box_w + 8*mm)
            y_off = y_offsets[i] if i < len(y_offsets) else 0
            y = self.height - bh - 2*mm + y_off

            # Shadow
            c.setFillColor(HexColor("#E0E0E0"))
            c.roundRect(x + 0.5*mm, y - 0.5*mm, self._box_w, bh, 3*mm, fill=1, stroke=0)

            # Box
            c.setFillColor(HexColor(color_hex))
            c.setStrokeColor(HexColor(color_hex))
            c.roundRect(x, y, self._box_w, bh, 3*mm, fill=1, stroke=0)

            # Label
            c.setFillColor(white)
            c.setFont("CJK", 9)
            c.drawCentredString(x + self._box_w/2, y + bh/2 - 3, label)

            # Caption below box
            if caption:
                c.setFillColor(T["ink_faded"])
                c.setFont("CJK", 7)
                cap = caption[:16] + "..." if len(caption) > 17 else caption
                c.drawCentredString(x + self._box_w/2, y - 8, cap)

            # Arrow
            if i < n - 1:
                ax = x + self._box_w + 1*mm
                ay = self.height - bh/2 - 2*mm + (y_off + (y_offsets[i+1] if i+1 < len(y_offsets) else 0)) / 2
                ax2 = x_start + (i+1) * (self._box_w + 8*mm) - 1*mm
                self._draw_arrow(c, ax, ay, ax2, ay)

        # Arc type label
        arc_labels = {
            'linear': '',
            'ascending': '─── 上升弧线 ───',
            'descending': '─── 下降弧线 ───',
            'subvert': '─── 颠覆弧线 ───',
            'spiral': '─── 螺旋弧线 ───',
        }
        lbl = arc_labels.get(self._arc_type, '')
        if lbl:
            c.setFillColor(T["ink_faded"])
            c.setFont("CJK", 7)
            c.drawCentredString(self._body_w / 2, self.height - self._total_h + 1*mm, lbl)

    def _get_y_offsets(self, n):
        """根据弧线类型返回每个节点的垂直偏移，支持3-6个节点。"""
        if self._arc_type == 'ascending':
            # 从左下到右上，逐步上升
            step = 2.0 * mm / max(n - 1, 1)
            return [(-i * step) for i in range(n)]
        elif self._arc_type == 'descending':
            # 从左上到右下，逐步下降
            step = 2.0 * mm / max(n - 1, 1)
            return [(i * step) for i in range(n)]
        elif self._arc_type == 'subvert':
            # 先升后骤降（S形反转）
            offsets = []
            peak = n * 0.4  # 上升在约40%处达到顶点
            for i in range(n):
                if i <= peak:
                    offsets.append(-i * 2.5 * mm / max(peak, 1))
                else:
                    fall = (i - peak) / max(n - 1 - peak, 1)
                    offsets.append(-(peak * 2.5 * mm / max(peak, 1)) + fall * 5.5 * mm)
            return offsets
        elif self._arc_type == 'spiral':
            # 螺旋摆动，振幅逐渐增大
            offsets = []
            for i in range(n):
                amp = 1.5 + i * 0.5  # 递增振幅
                offsets.append(amp * mm * (1 if i % 2 == 0 else -1))
            return offsets
        return [0] * n


# ═══════════════════════════════════════════════════════════════════════
# 额外段落样式（用于稀有字/词语境、引句）
# ═══════════════════════════════════════════════════════════════════════

def _make_extra_styles(ST, T, ah):
    """在 PDFBuilder 基础样式之上补充文风报告专用样式。"""
    # 部分标题样式：22pt，介于part(26pt)和chapter(18pt)之间，保持结构层次感
    h_align = ST['part'].alignment
    ST['part_ch'] = ParagraphStyle('PartCh', fontName="Serif", fontSize=22,
        leading=30, textColor=ST['part'].textColor, alignment=h_align,
        spaceBefore=0, spaceAfter=0)
    ST['quote'] = ParagraphStyle('Quote',
        fontName="CJK", fontSize=9, leading=15,
        textColor=T["ink"], leftIndent=12, rightIndent=12,
        spaceBefore=2, spaceAfter=2,
        borderColor=T["accent"], borderWidth=0,
        backColor=T["canvas_sec"])
    ST['label_sm'] = ParagraphStyle('LabelSm',
        fontName="SansBold", fontSize=8, leading=11,
        textColor=T["accent"], spaceBefore=6, spaceAfter=2)
    ST['body_sm'] = ParagraphStyle('BodySm',
        fontName="Sans", fontSize=8.5, leading=13,
        textColor=T["ink"], spaceBefore=1, spaceAfter=1,
        wordWrap='CJK')
    ST['concordance_char'] = ParagraphStyle('ConcChar',
        fontName="CJK", fontSize=14, leading=18,
        textColor=T["accent"], alignment=TA_CENTER)
    ST['concordance_ctx'] = ParagraphStyle('ConcCtx',
        fontName="CJK", fontSize=8.5, leading=14,
        textColor=T["ink"], wordWrap='CJK')
    ST['stat_badge'] = ParagraphStyle('Badge',
        fontName="SansBold", fontSize=10, leading=14,
        textColor=T["ink_faded"], alignment=TA_CENTER)
    return ST

# ═══════════════════════════════════════════════════════════════════════
# 表格构建辅助函数
# ═══════════════════════════════════════════════════════════════════════

def _make_table(rows, col_ratios, body_w, ST, T,
                header_bg=None, zebra=True, font_size_override=None):
    """
    rows: [ [cell, cell, ...], ... ] 第0行为表头
    col_ratios: [0.3, 0.5, 0.2] 各列宽比例，自动归一化
    """
    ah = f"#{int(T['accent'].red*255):02x}{int(T['accent'].green*255):02x}{int(T['accent'].blue*255):02x}" \
         if hasattr(T['accent'],'red') else "#CC785C"

    total = sum(col_ratios)
    col_w = [(r/total) * (body_w - 4*mm) for r in col_ratios]

    fs = font_size_override or 8
    th_style = ParagraphStyle('th_', fontName="SansBold", fontSize=fs,
                              leading=fs+3, textColor=white, alignment=TA_CENTER,
                              wordWrap='CJK')
    tc_style = ParagraphStyle('tc_', fontName="Sans", fontSize=fs,
                              leading=fs+3, textColor=T["ink"], alignment=TA_LEFT,
                              wordWrap='CJK')

    def _cell(text, is_header=False):
        style = th_style if is_header else tc_style
        return Paragraph(_font_wrap(esc(str(text))), style)

    tdata = []
    for ri, row in enumerate(rows):
        tdata.append([_cell(cell, ri == 0) for cell in row])

    hdr_bg  = header_bg or T["accent"]
    ts_list = [
        ('BACKGROUND', (0,0), (-1,0), hdr_bg),
        ('TEXTCOLOR',  (0,0), (-1,0), white),
        ('GRID',       (0,0), (-1,-1), 0.4, T["border"]),
        ('VALIGN',     (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1), 5),
        ('RIGHTPADDING',(0,0),(-1,-1), 5),
        ('TOPPADDING', (0,0),(-1,-1), 3),
        ('BOTTOMPADDING',(0,0),(-1,-1), 3),
    ]
    if zebra:
        for ri in range(1, len(tdata)):
            bg = white if ri % 2 == 1 else T["canvas_sec"]
            ts_list.append(('BACKGROUND', (0,ri), (-1,ri), bg))

    t = Table(tdata, colWidths=col_w, repeatRows=1)
    t.setStyle(TableStyle(ts_list))
    return t

def _bar(value, max_val, width_mm=30):
    """返回文字版迷你条形图（用于表格内）。"""
    if max_val <= 0: return ""
    filled = int(value / max_val * 8)
    return "█" * filled + "░" * (8 - filled)

# ═══════════════════════════════════════════════════════════════════════
# 第一部分各章节构建函数
# ═══════════════════════════════════════════════════════════════════════

def build_overview(d, story, ST, T, bw, ah):
    """概览数据表。"""
    m  = d["meta"]
    sr = d["sents"]
    pr = d["paras"]
    pu = d["punct"]

    rows = [
        ["指标", "数值"],
        ["总汉字数",         f"{m['total_cjk']:,} 字"],
        ["不重复字种",       f"{m['unique_chars']:,} 种"],
        ["生僻字（仅出现1次）", f"{m['rare_chars']:,} 种（占字种 {_pct(m['rare_chars'], m['unique_chars'])}）"],
        ["总句数",           f"{m['sent_count']:,} 句"],
        ["平均句长",         f"{m['avg_sent_len']} 字/句"],
        ["最长句 / 最短句",  f"{m['max_sent_len']} 字 / {m['min_sent_len']} 字"],
        ["句长方差 · 节奏",  f"{sr['variance']}  ·  {m['rhythm']}"],
        ["含对话句",         f"{sr['dialog_pct']}%"],
        ["段落数",           f"{m['para_count']:,} 段"],
        ["平均段落长",       f"{pr['avg_len']} 字/段"],
        ["平均句数/段",      f"{pr['avg_sc']} 句/段"],
        ["标点密度",         f"{m['punct_density']} 个/百字"],
        ["破折号 / 省略号",  f"{pu['dash_count']} / {pu['ellipsis_count']}"],
    ]
    story.append(_make_table(rows, [0.42, 0.58], bw, ST, T))


def build_char_section(d, story, ST, T, bw, ah):
    """一、字频特征。"""
    chars = d["chars"]
    total = chars["total_cjk"]

    # 1.1 总体数据
    rows = [
        ["类别", "字种数", "占总字种"],
        ["实词字种",
         f"{chars['content_count']:,}",
         _pct(chars['content_count'], chars['unique'])],
        ["虚词字种",
         f"{chars['func_count']:,}",
         _pct(chars['func_count'], chars['unique'])],
        ["生僻字种（出现1次）",
         f"{chars['rare_count']:,}",
         _pct(chars['rare_count'], chars['unique'])],
        ["总字种",
         f"{chars['unique']:,}", "100.0%"],
    ]
    story.append(Paragraph(_font_wrap(esc("1.1  总体字种数据")), ST['h3']))
    story.append(_make_table(rows, [0.48, 0.26, 0.26], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 1.2 意象字库
    img = chars.get("imagery_chars", {})
    if img:
        img_total = sum(v["total"] for v in img.values())
        rows = [["意象类别", "次数", "占意象字总量", "高频字"]]
        for cluster, data in sorted(img.items(), key=lambda x: -x[1]["total"]):
            top_chars = "、".join(
                f"{c}({n})" for c, n in
                sorted(data["chars"].items(), key=lambda x: -x[1])[:5]
            )
            rows.append([
                cluster,
                f"{data['total']:,}",
                _pct(data['total'], img_total),
                top_chars,
            ])
        rows.append(["合计", f"{img_total:,}", "100.0%", ""])
        story.append(Paragraph(_font_wrap(esc("1.2  意象字库")), ST['h3']))
        story.append(_make_table(rows, [0.18, 0.14, 0.20, 0.48], bw, ST, T))
        story.append(Spacer(1, 3*mm))

    # 1.3 高频实词字 TOP20
    cf = chars["content_freq"][:20]
    max_n = cf[0][1] if cf else 1
    rows = [["排名", "字", "次数", "占总字", "频率条"]]
    for i, (c, n) in enumerate(cf, 1):
        rows.append([str(i), c, str(n), _pct(n, total), _bar(n, max_n)])
    story.append(Paragraph(_font_wrap(esc("1.3  高频实词字 TOP20")), ST['h3']))
    story.append(_make_table(rows, [0.10, 0.10, 0.14, 0.18, 0.48], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 1.4 高频虚词字 TOP10
    ff = chars["func_freq"][:10]
    rows = [["排名", "字", "次数", "占总字"]]
    for i, (c, n) in enumerate(ff, 1):
        rows.append([str(i), c, str(n), _pct(n, total)])
    story.append(Paragraph(_font_wrap(esc("1.4  高频虚词字 TOP10")), ST['h3']))
    story.append(_make_table(rows, [0.15, 0.15, 0.20, 0.50], bw, ST, T))


def build_word_section(d, story, ST, T, bw, ah):
    """二、词频与词性。"""
    words = d["words"]
    total_top = sum(n for _, n in words["top_words"])

    # 2.1 词性分布
    pos_r = words.get("pos_ratios", {})
    pos_d = words.get("pos_dist", {})
    total_pos = sum(pos_d.values()) or 1
    rows = [["词性", "次数", "占比"]]
    for k in ["名词","动词","形容词","副词","代词","数词","成语","惯用语"]:
        cnt = pos_d.get(k, 0)
        if cnt:
            rows.append([k, f"{cnt:,}", f"{pos_r.get(k,0)}%"])
    story.append(Paragraph(_font_wrap(esc("2.1  词性分布")), ST['h3']))
    story.append(_make_table(rows, [0.40, 0.30, 0.30], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 2.2 高频实词 TOP30
    top = words["top_words"][:30]
    max_n = top[0][1] if top else 1
    rows = [["排名", "词", "次数", "占词频", "频率条"]]
    for i, (w, n) in enumerate(top, 1):
        rows.append([str(i), w, str(n), _pct(n, total_top), _bar(n, max_n)])
    story.append(Paragraph(_font_wrap(esc("2.2  高频实词 TOP30")), ST['h3']))
    story.append(_make_table(rows, [0.10, 0.18, 0.14, 0.18, 0.40], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 2.3 成语与惯用语
    idioms = words.get("idioms", [])
    if idioms:
        total_idiom = sum(n for _, n in idioms)
        rows = [["成语/惯用语", "次数", "占成语总量"]]
        for w, n in idioms[:20]:
            rows.append([w, str(n), _pct(n, total_idiom)])
        story.append(Paragraph(_font_wrap(esc("2.3  成语与惯用语")), ST['h3']))
        story.append(_make_table(rows, [0.50, 0.25, 0.25], bw, ST, T))
    else:
        story.append(Paragraph(_font_wrap(esc("2.3  成语与惯用语")), ST['h3']))
        story.append(Paragraph("本文未检出成语（jieba 标记为 i 类标签）。", ST['body_sm']))
    story.append(Spacer(1, 3*mm))

    # 2.4 特色词与低频词（v3.0：基于文本内频率分类）
    rare_words   = words.get("rare_words", {})
    rare_word_ctx = words.get("rare_word_contexts", {})
    featured  = {w: v for w, v in rare_words.items() if v["level"] == "特色词"}
    low_freq  = {w: v for w, v in rare_words.items() if v["level"] == "低频词"}

    story.append(Paragraph(_font_wrap(esc("2.4  特色词与低频词")), ST['h3']))
    story.append(Paragraph(
        f"特色词（本文高频 + 词典罕见）：{len(featured):,} 个　"
        f"低频词（本文出现≤3次）：{len(low_freq):,} 个",
        ST['body_sm']
    ))
    story.append(Spacer(1, 2*mm))

    if featured:
        rows = [["特色词", "次数", "词典频率", "原文语境"]]
        feat_sorted = sorted(featured.items(), key=lambda x: -x[1]["count"])[:40]
        for w, v in feat_sorted:
            df = v.get("dict_freq", 0)
            df_str = str(df) if df > 0 else "0（词典未收录）"
            ctx = rare_word_ctx.get(w, ["—"])[0][:45] + ("…" if len(rare_word_ctx.get(w, [""])[0]) > 45 else "")
            rows.append([w, str(v["count"]), df_str, ctx])
        story.append(Paragraph("特色词（按频次排序）", ST['label_sm']))
        story.append(_make_table(rows, [0.15, 0.08, 0.17, 0.60], bw, ST, T, font_size_override=8))
        story.append(Spacer(1, 3*mm))

    if low_freq:
        rows = [["低频词", "次数", "原文语境"]]
        lf_sorted = sorted(low_freq.items(), key=lambda x: -x[1]["count"])[:30]
        for w, v in lf_sorted:
            ctx = rare_word_ctx.get(w, ["—"])[0][:55] + ("…" if len(rare_word_ctx.get(w, [""])[0]) > 55 else "")
            rows.append([w, str(v["count"]), ctx])
        story.append(Paragraph("低频词（按频次排序）", ST['label_sm']))
        story.append(_make_table(rows, [0.15, 0.10, 0.75], bw, ST, T, font_size_override=8))
        story.append(Spacer(1, 3*mm))

    # 2.5 人名与专有名词（v3.0新增：独立展示，不混入词频分析）
    proper_nouns = words.get("proper_nouns", [])
    person_names = words.get("person_names", [])
    if proper_nouns:
        # proper_nouns 格式：[(name, count), ...]
        pn_dict = dict(proper_nouns)
        # 分离人名和非人名专有名词
        pn_names = set(w for w, _ in (person_names or []))
        nr_items = [(w, c) for w, c in proper_nouns if w in pn_names]
        ns_nz_items = [(w, c) for w, c in proper_nouns if w not in pn_names]

        story.append(Paragraph(_font_wrap(esc("2.5  人名与专有名词")), ST['h3']))
        story.append(Paragraph(
            f"人名：{len(nr_items):,} 个　地名/其他专名：{len(ns_nz_items):,} 个",
            ST['body_sm']
        ))
        story.append(Spacer(1, 2*mm))

        if nr_items:
            rows = [["人名", "出现次数"]]
            for w, c in sorted(nr_items, key=lambda x: -x[1])[:30]:
                rows.append([w, str(c)])
            story.append(Paragraph("人名（按频次排序）", ST['label_sm']))
            story.append(_make_table(rows, [0.55, 0.45], bw, ST, T, font_size_override=8))
            story.append(Spacer(1, 3*mm))

        if ns_nz_items:
            rows = [["地名/专名", "出现次数"]]
            for w, c in sorted(ns_nz_items, key=lambda x: -x[1])[:30]:
                rows.append([w, str(c)])
            story.append(Paragraph("地名/专名（按频次排序）", ST['label_sm']))
            story.append(_make_table(rows, [0.55, 0.45], bw, ST, T, font_size_override=8))
            story.append(Spacer(1, 3*mm))


def build_sentence_section(d, story, ST, T, bw, ah):
    """三、句型分析。"""
    sr = d["sents"]
    total_s = sr["count"] or 1

    # 3.1 句长分布（v3.1：与 analyze.py 的 _sent_bucket 对齐）
    td = sr.get("type_dist", {})
    type_order = [("短句", "≤12字"), ("中句", "13-30字"), ("长句", "31-50字"), ("超长句", ">50字")]
    rows = [["句型", "字数范围", "句数", "占比"]]
    for label, rng in type_order:
        n = td.get(label, 0)
        rows.append([label, rng, str(n), _pct(n, total_s)])
    story.append(Paragraph(_font_wrap(esc("3.1  句长分布")), ST['h3']))
    story.append(_make_table(rows, [0.22, 0.28, 0.22, 0.28], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 3.2 节奏数据
    rows = [["指标","数值"],
            ["平均句长", f"{sr['avg_len']} 字/句"],
            ["最长句", f"{sr.get('max_len','-')} 字"],
            ["最短句", f"{sr.get('min_len','-')} 字"],
            ["句长方差", f"{sr['variance']}"],
            ["节奏特征", sr['rhythm']],
            ["含对话句", f"{sr.get('dialog_pct', 0)}%"]]
    story.append(Paragraph(_font_wrap(esc("3.2  节奏与对话")), ST['h3']))
    story.append(_make_table(rows, [0.42, 0.58], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 3.3 句首类型
    od = sr.get("open_dist", {})
    if od:
        rows = [["句首类型", "句数", "占比"]]
        for label, n in sorted(od.items(), key=lambda x: -x[1]):
            rows.append([label, str(n), _pct(n, total_s)])
        story.append(Paragraph(_font_wrap(esc("3.3  句首类型分布")), ST['h3']))
        story.append(_make_table(rows, [0.40, 0.30, 0.30], bw, ST, T))
        story.append(Spacer(1, 3*mm))

    # 3.4 修辞格分布
    rd = sr.get("rhet_dist", {})
    if rd:
        rows = [["修辞格", "句数", "占比"]]
        for label, n in sorted(rd.items(), key=lambda x: -x[1]):
            rows.append([label, str(n), _pct(n, total_s)])
        story.append(Paragraph(_font_wrap(esc("3.4  修辞格分布")), ST['h3']))
        story.append(_make_table(rows, [0.40, 0.30, 0.30], bw, ST, T))
        story.append(Spacer(1, 3*mm))


def build_paragraph_section(d, story, ST, T, bw, ah):
    """四、段落结构。"""
    pr = d["paras"]
    total_p = pr["count"] or 1

    # 4.1 长度分布
    bd = pr.get("bucket_dist", {})
    rows = [["长度等级","字数范围","段数","占比"]]
    order = ["极短（≤30字）","短（31-80字）","中（81-200字）","长（201-400字）","超长（>400字）"]
    ranges = {"极短（≤30字）":"≤30","短（31-80字）":"31-80",
              "中（81-200字）":"81-200","长（201-400字）":"201-400","超长（>400字）":">400"}
    for label in order:
        n = bd.get(label, 0)
        if n:
            rows.append([label, f"{ranges[label]}字", str(n), _pct(n, total_p)])
    story.append(Paragraph(_font_wrap(esc("4.1  段落长度分布")), ST['h3']))
    story.append(_make_table(rows, [0.36, 0.24, 0.20, 0.20], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 4.2 关键数据
    rows = [["指标","数值"],
            ["段落数", f"{pr['count']:,} 段"],
            ["平均段落长", f"{pr['avg_len']} 字/段"],
            ["平均句数/段", f"{pr['avg_sc']} 句/段"],
            ["最长段落", f"{pr['max_len']} 字"],
            ["最短段落", f"{pr['min_len']} 字"],
            ["单句段", f"{pr.get('single_sent',0)} 段（{_pct(pr.get('single_sent',0), total_p)}）"]]
    story.append(Paragraph(_font_wrap(esc("4.2  关键段落数据")), ST['h3']))
    story.append(_make_table(rows, [0.42, 0.58], bw, ST, T))


def build_punctuation_section(d, story, ST, T, bw, ah):
    """五、标点符号。"""
    pu = d["punct"]
    total_p = pu["total"] or 1
    NAMES = {
        "，":"逗号","。":"句号","！":"叹号","？":"问号","；":"分号",
        "：":"冒号","、":"顿号","…":"省略号","—":"破折号",
        "“":"引号开","”":"引号闭","（":"括号开","）":"括号闭",
        "《":"书名开","》":"书名闭","·":"间隔号",
    }
    rows = [["标点","名称","次数","占标点总量"]]
    for p, n in sorted(pu["counts"].items(), key=lambda x:-x[1]):
        rows.append([p, NAMES.get(p,""), str(n), _pct(n, total_p)])
    rows.append(["合计","", f"{total_p:,}", "100.0%"])
    story.append(Paragraph(_font_wrap(esc("5.1  标点分布")), ST['h3']))
    story.append(_make_table(rows, [0.15, 0.25, 0.25, 0.35], bw, ST, T))
    story.append(Spacer(1, 3*mm))

    # 破折号语境
    dc = pu.get("dash_contexts", [])
    if dc:
        story.append(Paragraph(_font_wrap(esc("5.2  破折号语境")), ST['h3']))
        for ctx in dc:
            story.append(Paragraph(f"“{_font_wrap(esc(ctx))}”", ST['quote']))
            story.append(Spacer(1, 1*mm))
    else:
        story.append(Paragraph(_font_wrap(esc("5.2  破折号语境")), ST['h3']))
        story.append(Paragraph("本文未使用破折号（—）。", ST['body_sm']))

    story.append(Spacer(1, 2*mm))

    # 省略号语境
    ec = pu.get("ellipsis_contexts", [])
    if ec:
        story.append(Paragraph(_font_wrap(esc("5.3  省略号语境")), ST['h3']))
        for ctx in ec:
            story.append(Paragraph(f"“{_font_wrap(esc(ctx))}”", ST['quote']))
            story.append(Spacer(1, 1*mm))
    else:
        story.append(Paragraph(_font_wrap(esc("5.3  省略号语境")), ST['h3']))
        story.append(Paragraph("本文未使用省略号（…）。", ST['body_sm']))



# ═══════════════════════════════════════════════════════════════════════
# 稀有字与稀有词
# ═══════════════════════════════════════════════════════════════════════

def build_rare_section(d, story, ST, T, bw, ah):
    """六、稀有字。"""
    chars = d["chars"]
    rare_chars   = chars.get("rare", [])
    rare_ctx     = chars.get("rare_char_contexts", {})

    # 6.1 稀有字
    story.append(Paragraph(_font_wrap(esc("6.1  稀有字（全文仅出现1次）")), ST['h3']))
    story.append(Paragraph(
        f"共 {len(rare_chars):,} 种（占全部字种 "
        f"{_pct(len(rare_chars), chars['unique'])}）。",
        ST['body_sm']
    ))
    story.append(Spacer(1, 2*mm))

    # Concordance table：字 | 原文语境
    ctx_pairs = [(c, rare_ctx.get(c, [])) for c in rare_chars if rare_ctx.get(c)][:40]
    if ctx_pairs:
        rows = [["稀有字", "原文语境"]]
        for c, ctxs in ctx_pairs:
            rows.append([c, ctxs[0][:60] + ("…" if len(ctxs[0]) > 60 else "")])
        story.append(_make_table(rows, [0.10, 0.90], bw, ST, T, font_size_override=8))

# 主构建器
# ═══════════════════════════════════════════════════════════════════════

class WenfenPDFBuilder(PDFBuilder):
    """
    继承 PDFBuilder，重写 build() 以直接消费 analyze.py 的 JSON，
    跳过第一部分的 Markdown 解析。
    """

    def build_from_data(self, stats: dict, ai_md: str, output_path: str):
        register_fonts()
        T  = self.T
        ST = self.ST
        bw = self.body_w
        ah = self.accent_hex
        _make_extra_styles(ST, T, ah)

        m = stats["meta"]
        story = []

        # ── 封面 ──
        body_frame = __import__('reportlab.platypus', fromlist=['Frame']).Frame(
            self.lm, self.bm, bw, self.body_h, id='body')
        full_frame = __import__('reportlab.platypus', fromlist=['Frame']).Frame(
            0, 0, self.page_w, self.page_h,
            leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0, id='full')

        from reportlab.platypus import BaseDocTemplate, PageTemplate, NextPageTemplate
        doc = BaseDocTemplate(
            output_path,
            pagesize=(self.page_w, self.page_h),
            leftMargin=self.lm, rightMargin=self.rm,
            topMargin=self.tm, bottomMargin=self.bm,
            title=self.cfg.get("title",""),
            author=self.cfg.get("author",""))

        templates = []
        if self.cfg.get("cover", True):
            templates.append(PageTemplate(id='cover', frames=[full_frame],
                                          onPage=self._cover_page))
            story.append(Spacer(1, self.page_h))

        toc_entries = []
        has_toc = self.cfg.get("toc", True)
        if has_toc:
            toc_page_tmpl = PageTemplate(id='toc', frames=[body_frame],
                                         onPage=self._toc_page)
            templates.append(toc_page_tmpl)
            story.append(NextPageTemplate('toc'))
            story.append(PageBreak())

        templates.append(PageTemplate(id='normal', frames=[body_frame],
                                      onPage=self._normal_page))
        story.append(NextPageTemplate('normal'))
        if has_toc:
            story.append(PageBreak())

        def _part(title):
            cm = ChapterMark(title, level=0)
            story.append(PageBreak())
            story.append(cm)
            story.append(Spacer(1, self.body_h * 0.35))
            story.append(HRuleCentered(bw, 40*mm, 0.8, T["accent"]))
            story.append(Spacer(1, 8*mm))
            story.append(Paragraph(_font_wrap(esc(title)), ST['part_ch']))
            story.append(Spacer(1, 8*mm))
            story.append(HRuleCentered(bw, 25*mm, 0.8, T["accent"]))
            toc_entries.append(('part', title, cm.key))

        def _chapter(title):
            cm = ChapterMark(title, level=1)
            story.append(PageBreak())
            story.append(cm)
            story.append(Spacer(1, self.body_h * 0.28))
            story.append(Paragraph(_font_wrap(esc(title)), ST['chapter']))
            story.append(Spacer(1, 5*mm))
            story.append(HRuleCentered(bw, 35*mm, 1.2, T["accent"]))
            toc_entries.append(('chapter', title, cm.key))

        # ════════════════════════════════════════════════
        # 第一部分：基础数据（直接从 JSON 构建）
        # ════════════════════════════════════════════════
        _part("第一部分：基礎數據")

        _chapter("一、概覽數據")
        build_overview(stats, story, ST, T, bw, ah)

        _chapter("二、字頻特徵")
        build_char_section(stats, story, ST, T, bw, ah)

        _chapter("三、詞頻與詞性")
        build_word_section(stats, story, ST, T, bw, ah)

        _chapter("四、句型分析")
        build_sentence_section(stats, story, ST, T, bw, ah)

        _chapter("五、段落結構")
        build_paragraph_section(stats, story, ST, T, bw, ah)

        _chapter("六、標點符號")
        build_punctuation_section(stats, story, ST, T, bw, ah)

        _chapter("七、稀有字")
        build_rare_section(stats, story, ST, T, bw, ah)

        # ════════════════════════════════════════════════
        # 第二、三部分：AI 语意分析（解析简单 Markdown 散文）
        # ════════════════════════════════════════════════
        if ai_md.strip():
            ai_story, ai_toc = self.parse_md(ai_md)
            for entry in ai_toc:
                toc_entries.append(entry)
            story.extend(ai_story)

        # ════════════════════════════════════════════════
        # 构建 TOC（用 toc_entries 手动构建，不依赖 parse_md 返回值）
        # ════════════════════════════════════════════════
        if has_toc and toc_entries:
            toc_story = self._build_toc_from_entries(toc_entries, bw, ST, T, ah)
            # story[:3] = [Spacer(封面), NextPageTemplate('toc'), PageBreak()]
            # story[3] = NextPageTemplate('normal') → _part自带的PageBreak翻到正文
            # story[5:] = 正文内容
            full_story = story[:3] + toc_story + [story[3]] + story[5:]
        else:
            full_story = story

        doc.addPageTemplates(templates)
        print(f"[pdf_report] 构建 PDF：{len(full_story)} 个元素")
        doc.build(full_story)
        size = os.path.getsize(output_path)
        print(f"[pdf_report] 完成：{output_path}（{size/1024:.0f} KB）")

    def _build_toc_from_entries(self, entries, bw, ST, T, ah):
        """直接从 toc_entries 列表构建目录，不依赖 Markdown 解析。"""
        ink = T["ink"]
        ink_hex = f"#{int(ink.red*255):02x}{int(ink.green*255):02x}{int(ink.blue*255):02x}" \
                  if hasattr(ink,'red') else "#181818"
        s = [Spacer(1, 15*mm)]
        s.append(Paragraph(_font_wrap("目    錄"), ST['part']))
        s.append(HRule(bw * 0.12, 1, T["accent"]))
        s.append(Spacer(1, 8*mm))
        for etype, title, key in entries:
            style = ST['toc1'] if etype == 'part' else ST['toc2']
            linked = f"<a href=\"#{key}\" color=\"{ink_hex}\">{_font_wrap(esc(title))}</a>"
            s.append(Paragraph(linked, style))
        return s


# ═══════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(description="文风拆解器 PDF 报告生成器")
    ap.add_argument("--stats",   "-s", required=True,
                    help="analyze.py 的 JSON 输出路径")
    ap.add_argument("--ai",      "-a", default="",
                    help="AI 写的第二、三部分 Markdown 文件路径（可选）")
    ap.add_argument("--output",  "-o", default="wenfen_report.pdf",
                    help="輸出 PDF 路徑")
    ap.add_argument("--title",   default="",  help="封面標題")
    ap.add_argument("--subtitle",default="",  help="封面副標題")
    ap.add_argument("--author",  default="",  help="作者/分析者")
    ap.add_argument("--date",    default=str(date.today()), help="日期")
    ap.add_argument("--theme",   default="warm-academic",
                    help=f"主题（{', '.join(THEMES.keys())}）")
    ap.add_argument("--no-cover",action="store_true", help="不生成封面")
    ap.add_argument("--no-toc",  action="store_true", help="不生成目錄")
    ap.add_argument("--watermark",default="",  help="水印文字")
    args = ap.parse_args()

    # 读取 stats JSON
    with open(args.stats, encoding="utf-8") as f:
        stats = json.load(f)

    # 读取 AI 文字（可选）
    ai_md = ""
    if args.ai and Path(args.ai).exists():
        with open(args.ai, encoding="utf-8") as f:
            ai_md = f.read()

    # 自动生成封面标题
    title = args.title or f"文风拆解报告"
    m = stats.get("meta", {})
    stats_line  = (f"总汉字 {m.get('total_cjk',0):,} · "
                   f"句数 {m.get('sent_count',0):,} · "
                   f"段落 {m.get('para_count',0):,}")
    stats_line2 = (f"平均句长 {m.get('avg_sent_len',0)} 字 · "
                   f"节奏：{m.get('rhythm','')} · "
                   f"标点密度 {m.get('punct_density',0)}%")

    theme = load_theme(args.theme)
    a = theme['accent']
    accent_hex = (f"#{int(a.red*255):02x}{int(a.green*255):02x}{int(a.blue*255):02x}"
                  if hasattr(a,'red') else "#CC785C")

    from reportlab.lib.pagesizes import A4
    config = {
        "title":       title,
        "subtitle":    args.subtitle,
        "author":      args.author,
        "date":        args.date,
        "watermark":   args.watermark,
        "theme":       theme,
        "accent_hex":  accent_hex,
        "cover":       not args.no_cover,
        "toc":         not args.no_toc,
        "page_size":   A4,
        "header_title":title,
        "footer_left": args.author,
        "stats_line":  stats_line,
        "stats_line2": stats_line2,
    }

    builder = WenfenPDFBuilder(config)
    builder.build_from_data(stats, ai_md, args.output)


if __name__ == "__main__":
    main()
