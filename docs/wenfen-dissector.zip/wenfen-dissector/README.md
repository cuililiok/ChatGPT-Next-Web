# 文风拆解器 v3.1

中文文学文风分析工具，输出完整 PDF 分析报告。

## 安裝

```bash
pip install -r requirements.txt
```

## 快速開始

```bash
# 1. 統計分析
python scripts/analyze.py 作品.txt > stats.json

# 2. AI 語意分析（由 AI 閱讀 stats.json + 原文後撰寫）
# → 生成 semantic.md

# 3. 輸出 PDF
python scripts/pdf_report.py \
  --stats stats.json \
  --ai    semantic.md \
  --output 作品_文風分析.pdf \
  --title "《作品名》文風拆解報告" \
  --theme warm-academic
```

## EPUB 輸入

```bash
python scripts/epub_analyzer.py 作品.epub > stats.json
```

## 文件說明

| 文件 | 说明 |
|------|------|
| `VERSION` | 版本号（当前 3.1）|
| `CHANGELOG.md` | 版本变更记录 |
| `SKILL.md` | 完整工作流程文档 |
| `scripts/analyze.py` | 统计分析引擎（jieba）|
| `scripts/pdf_report.py` | PDF 报告生成器（reportlab）|
| `scripts/epub_analyzer.py` | EPUB 文本提取 |
| `scripts/config.py` | 配置常数 |
| `scripts/md2pdf.py` | PDF 基础设施（来自 any2pdf）|
| `references/prompts.md` | AI 语意分析提示词参考 |
| `requirements.txt` | Python 依赖 |

## 依賴

- Python 3.8+
- jieba（中文分詞）
- reportlab（PDF 生成）
- ebooklib（EPUB 解析，可選）
