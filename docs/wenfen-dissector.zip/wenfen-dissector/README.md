# 文风拆解器 v3.2.1

中文文学文风分析工具，输出完整 PDF 分析报告。

## 安裝

```bash
pip install -r requirements.txt
```

## 快速開始

```bash
# 1. 統計分析
python scripts/analyze.py 作品.txt > stats.json

# 2. AI 語意分析（由 AI 閱讀 stats.json + 原文後撰寫）
# → 生成 semantic.md

# 3. 輸出 PDF
python scripts/pdf_report.py \
  --stats stats.json \
  --ai    semantic.md \
  --output 作品_文風分析.pdf \
  --title "《作品名》文風拆解報告" \
  --theme warm-academic
```

## EPUB 輸入

```bash
python scripts/epub_analyzer.py 作品.epub
# 輸出至 /tmp/wenfen_book/book_stats_bundle.json
```

## 文件說明

| 文件 | 说明 |
|------|------|
| `VERSION` | 版本号（当前 3.2） |
| `CHANGELOG.md` | 版本变更记录 |
| `SKILL.md` | 完整工作流程文档 |
| `scripts/analyze.py` | 统计分析引擎（jieba） |
| `scripts/pdf_report.py` | PDF 报告生成器（reportlab） |
| `scripts/epub_analyzer.py` | EPUB 文本提取与全书采样分析 |
| `scripts/md2pdf.py` | PDF 基础设施（bundled） |
| `references/prompt_reference.md` | AI 撰写 semantic.md 的思路框架参考 |
| `requirements.txt` | Python 依赖 |

## 依賴

- Python 3.8+
- jieba（中文分词）
- reportlab（PDF 生成）
- ebooklib（EPUB 解析，可选）

## 版本

- **v3.2.1** — 建筑类意象字库去重、prompt_reference 内部提示词与文件头一致化
- **v3.2** — 句切分修复、修辞改进、意象库扩 9 类、TOC 不再脆弱、章节编号修正、清理死代码
- **v3.1** — P0 数据正确性修复（句长分布全 0、繁体意象 0 命中等）
- **v3.0** — 稀有词检测重写、专有名词独立收集
- **v2.2** — 双引擎结构（统计 + AI 语意）
