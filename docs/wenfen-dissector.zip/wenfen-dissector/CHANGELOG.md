# Changelog

## v3.1 — P0 数据正确性修复

**修复（必须修）**

- **`pdf_report.py`：3.x 节重复输出 / 句长分布全 0**
  - 原 `build_word_section` 末尾混入了一段错位的 "三、句型分析" 代码（带文档字符串孤儿），导致每份 PDF 都先在"二、词频与词性"末尾输出一份错的句型分析，再在"四、句型分析"输出一份对的——同一份报告里出现两次。
  - 错位代码使用了"短句/中句/长句/超长句"的 key，但 `analyze.py` 输出的 `type_dist` 用的是"极短/短/中/长/超长"，结果所有句数都显示 0。
  - 修复：删除孤儿代码段，并将 `build_sentence_section` 的 key 与 `analyze.py` 的 `_sent_bucket` 输出严格对齐。
- **`analyze.py`：句子分桶用了段落分桶**
  - 原版 `analyze_sentences()` 调用 `_para_bucket()`，阈值是 20/60/150/300，对句子来说粒度过粗——大量中长句被全部归到"短"。
  - 修复：新增 `_sent_bucket()`（≤12 / 13–30 / 31–50 / >50），段落仍用 `_para_bucket()`（≤30 / 31–80 / 81–200 / 201–400 / >400）。
- **`analyze.py`：意象库简体硬编码导致繁体输入命中率为 0**
  - SKILL.md 全文使用繁体且明确说要分析繁体文本，但 `IMAGERY_CLUSTERS` 只包含简体字符，繁体输入下"身體 / 眼臉 / 紅 / 風"等都没有进入意象统计。
  - 修复：意象库改为 `(简体, 繁体)` 双库定义，在加载时合并，繁简通用。
- **`analyze.py`：`PUNCT_SET` 字符串拼接含重复和歧义引号**
  - 原版用 `set('，。！？；…—""''…')` 这种字符串拼接，肉眼难以审核，弯引号 / 直引号 / 中英文括号混在一起，导致"引号"在统计中可能被双倍计数或漏计。
  - 修复：改成显式列举的 `frozenset([...])`，分组排版（中文常用标点 / 中文引号 / 中文括号 / 英文标点），每个字符只出现一次。
- **`analyze.py`：CJK 范围只覆盖基本区**
  - 原版 `is_cjk` 只覆盖 U+4E00–U+9FFF + Ext A，对古典文学的 Ext B 异体字、Compat Ideographs 漏字。
  - 修复：扩展到 Basic + Ext A + Ext B + Compat Ideographs。
- **版本号集中管理**
  - 新增 `VERSION` 文件 + `analyze.__version__`，所有版本号都从这里读取。
  - SKILL.md / README.md / requirements.txt 已同步到 v3.1。

**未修（在 P1 路线图）**

- `report_tool.py` 是死代码（`pdf_report.py` 不通过 subprocess）
- `config.py` 的常量从未被引用（`analyze.py` 仍在用魔数）
- `pdf_report.py` 的 TOC 拼接靠硬编码下标切片
- `_load_md2pdf()` 仍包含开发者本地路径（WPS 灵犀 / openclaw）
- `references/prompts.md` 与 SKILL.md 的"无 API 调用"流程冲突，需要改名或重新定位

详见审阅意见 P1–P4 节。

## v3.0

- 稀有词检测重写：基于文本内频率而非 jieba 词典频率
- 人名 / 专有名词独立收集，不混入 content_tokens
- 三维词汇分类：特色词 / 低频词 / 人名与专有名词
- 伪词过滤前置：在构建 content_tokens 阶段完成

## v2.2

- 双引擎结构：统计引擎（analyze.py）+ 语意引擎（AI）
- pdf_report.py 直接消费 stats.json，跳过 Markdown 解析层
- 报告结构定型为"基础数据 / 语意分析 / 文风诊断"三部分
