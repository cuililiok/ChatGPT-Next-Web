#!/usr/bin/env python3
"""
文风拆解器 — 统计分析引擎 v3.0
Usage: python3 analyze.py <text_file>
       echo "文本" | python3 analyze.py
Output: JSON to stdout

v3.0 变更：
- 稀有词检测重写：基于文本内频率而非jieba词典频率
- 人名/专有名词独立收集，不混入content_tokens
- 三维词汇分类：特色词 / 低频词 / 人名与专有名词
- 伪词过滤前置：在构建content_tokens阶段完成
"""

import sys, json, re, statistics
from collections import Counter

# ── jieba setup ──
try:
    import jieba
    import jieba.posseg as pseg
    jieba.setLogLevel(60)
    HAS_JIEBA = True
except ImportError:
    HAS_JIEBA = False
    print("[WARN] jieba 未安装，词频/词性分析将跳过。执行: pip install jieba", file=sys.stderr)

# ════════════════════════════════════════════════
# CONSTANTS
# ════════════════════════════════════════════════

def is_cjk(c):
    return '\u4e00' <= c <= '\u9fff' or '\u3400' <= c <= '\u4dbf'

PUNCT_SET = set('，。！？；：、…—～""''【】《》（）""\'\'·')

FUNC_CHARS = set(
    '的了是在我他她它你们们和或与也都就但而如为以对很太更最不没有要会能可得着过'
    '把被让从到里上下中来去说道这那其此已将曾又再还只则于之乎者哉夫矣焉且若虽'
    '然故因所即何啊呢吧哦嗯哪'
)

POS_MAP = {
    'n':'名词','nr':'人名','ns':'地名','nz':'专名','ng':'名语素',
    'v':'动词','vd':'副动词','vn':'动名词','vg':'动词语素',
    'a':'形容词','ad':'副形容词','an':'形名词',
    'd':'副词','p':'介词','c':'连词',
    'm':'数词','q':'量词','r':'代词',
    't':'时间词','s':'处所词','f':'方位词',
    'x':'标点','u':'助词','y':'语气词','e':'叹词',
    'i':'成语','l':'惯用语','j':'缩略语',
}

# 实词词性（用于content_tokens），不含专有名词nr/ns/nz
CONTENT_POS = {'n','ng','v','vd','vn','vg','a','ad','an','i','l','j','t','s'}

IMAGERY_CLUSTERS = {
    '身体': set('眼脸手脚腰背肩胸腹头发耳口唇鼻心肺肠血骨皮肉指甲肤颈臂腿'),
    '颜色': set('红白黑黄蓝绿紫金银灰棕橙粉褐'),
    '自然': set('山水风云雨雪日月星天地花草树叶石沙海河湖原野田'),
    '光影': set('光暗影明亮淡闪阴晴阳曦暮昏黎曙'),
    '时间': set('年月日时秒春夏秋冬古今昔往后曾'),
    '器物': set('门窗墙桌椅床灯书杯碗刀剑镜笔'),
    '情感': set('爱恨悲欢喜怒哀惧'),
}

# ════════════════════════════════════════════════
# CONTEXT HELPERS
# ════════════════════════════════════════════════

def _get_contexts(text, target, max_results=5):
    """返回含 target 的完整句子列表（句末标点切分）。"""
    results = []
    for m in re.finditer(r'[^。！？\n]{0,40}' + re.escape(target) + r'[^。！？\n]{0,40}', text):
        sentence = m.group(0).strip()
        if sentence:
            results.append(sentence)
        if len(results) >= max_results:
            break
    return results

def _para_bucket(clen):
    if clen <= 20: return '极短'
    if clen <= 60: return '短'
    if clen <= 150: return '中'
    if clen <= 300: return '长'
    return '超长'

# ════════════════════════════════════════════════
# SENTENCE ANALYSIS
# ════════════════════════════════════════════════

def detect_open(s):
    if not s: return '其他'
    c = s[0]
    if c in '他她它它们其': return '代词起句'
    if c in '的了是在': return '虚词起句'
    if '\u4e00' <= c <= '\u9fff':
        return '名词/实词起句'
    if c in '""「『': return '引语起句'
    return '其他'

def classify_rhetoric(s):
    """检测修辞格。返回集合。"""
    types = set()
    if '像' in s and ('一样' in s or '般' in s or '似的' in s):
        types.add('明喻')
    if '不是' in s and '而是' in s:
        types.add('对比')
    if len(set(s)) / max(len(s), 1) < 0.5 and len(s) > 6:
        types.add('反复')
    pairs = re.findall(r'([\u4e00-\u9fff])\1', s)
    if len(pairs) >= 2:
        types.add('叠字')
    if re.search(r'不[一不]\S', s):
        types.add('反复')
    if s.count('，') >= 3 and not s.count('；'):
        types.add('排比')
    if re.search(r'何[A-Z\u4e00-\u9fff]{1,3}(之|之至)', s):
        types.add('反问')
    if re.search(r'(然|而|却|但|虽|尽管).{1,6}(却|但|然而|可是)', s):
        types.add('转折')
    if re.search(r'[既也又][然尚犹且].{0,4}[而却但]', s):
        types.add('让步')
    if re.search(r'连.{1,4}[都也]', s):
        types.add('递进')
    if re.search(r'(真|好|很|太|极|十分|非常|格外).{1,4}(啊|呀|呢|了|的)', s):
        types.add('感叹')
    if re.search(r'(因为|由于).{2,20}(所以|因此|故|以致)', s):
        types.add('因果')
    if re.search(r'(如果|假若|倘若|要是|即使).{2,15}(就|便|也|则)', s):
        types.add('假设')
    return types

# ════════════════════════════════════════════════
# CHARACTER ANALYSIS
# ════════════════════════════════════════════════

def analyze_chars(text):
    cjk  = [c for c in text if is_cjk(c)]
    freq = Counter(cjk)

    content_freq = sorted([(c,n) for c,n in freq.items() if c not in FUNC_CHARS], key=lambda x:-x[1])
    func_freq    = sorted([(c,n) for c,n in freq.items() if c in FUNC_CHARS],     key=lambda x:-x[1])
    rare_chars   = [c for c,n in freq.items() if n == 1]

    rare_char_contexts = {}
    for c in rare_chars[:60]:
        ctxs = _get_contexts(text, c, max_results=2)
        if ctxs:
            rare_char_contexts[c] = ctxs

    imagery = {}
    for cluster, chars in IMAGERY_CLUSTERS.items():
        hits = {c: freq[c] for c in chars if c in freq}
        if hits:
            imagery[cluster] = {'total': sum(hits.values()), 'chars': hits}

    return {
        'total_cjk':          len(cjk),
        'unique':             len(freq),
        'content_count':      len(content_freq),
        'func_count':         len(func_freq),
        'rare_count':         len(rare_chars),
        'content_freq':       content_freq[:80],
        'func_freq':          func_freq[:40],
        'rare':               rare_chars,
        'rare_char_contexts': rare_char_contexts,
        'all_freq':           freq.most_common(5000),
        'imagery_chars':      imagery,
    }

# ════════════════════════════════════════════════
# WORD ANALYSIS (v3.0 重写)
# ════════════════════════════════════════════════

def _is_segmented_pseudo(word):
    """判断word是否是jieba分词粘连产生的伪词。
    
    核心逻辑：如果jieba单独切这个词时产生了不同的分词结果，
    说明这个词只存在于特定上下文中，不是真正的词。
    
    例如："将手" 在 "的将手" 中被切成一个词，
    但 jieba.cut("将手") → ['将', '手']，说明它只是分词副产物。
    """
    if not HAS_JIEBA or len(word) < 2:
        return False
    try:
        standalone = list(jieba.cut(word))
        # 如果单独切的结果和原词不同，且每段都很短（≤2字），就是伪词
        if len(standalone) > 1 and all(len(s) <= 2 for s in standalone if s.strip()):
            return True
    except Exception:
        pass
    return False


def _detect_word_features(content_tokens, text=''):
    """检测词汇特征（v3.0：基于文本内频率）。
    
    分类逻辑：
    - 特色词：在本文中出现次数≥中位数 且 jieba词典中不常见（freq≤2）
      → 说明作者反复使用这个词，且这个词不是通用词汇
    - 低频词：在本文中出现次数≤3次
      → 值得注意但不是文风核心特征
    
    不再使用jieba词典频率作为"这个词存不存在"的裁判。
    jieba词典是通用互联网语料，文学文本中的古语/文言/自造词大量不在其中。
    """
    if not content_tokens:
        return {}
    
    import re as _re
    rare = {}
    try:
        # 1. 计算每个词在本文中的出现次数
        text_freq = Counter(w for w, _ in content_tokens)
        all_counts = list(text_freq.values())
        
        if not all_counts:
            return {}
        
        # 2. 计算中位数作为"特色词"阈值
        median_freq = statistics.median(all_counts)
        
        # 3. 预统计：跨句出现次数（仅用于伪词过滤）
        sents = _re.split(r'[。！？；…]', text)
        
        # 4. 逐词分类
        for w, f in content_tokens:
            # 去重：每个词只处理一次
            if w in rare:
                continue
            
            count = text_freq[w]
            dict_freq = jieba.dt.FREQ.get(w, 0) if HAS_JIEBA else 0
            
            # ── 伪词过滤 ──
            # 分词粘连产物：jieba单独切会产生不同结果
            if _is_segmented_pseudo(w):
                continue
            # 跨句出现次数太少：跨句<2次的词很可能是分词噪声
            cross_sent = sum(1 for s in sents if w in s)
            if cross_sent < 2:
                continue
            
            # ── 分类 ──
            if count <= 3:
                level = '低频词'
                rare[w] = {'level': level, 'count': count, 'pos': f, 'dict_freq': dict_freq}
            elif count >= median_freq and dict_freq <= 2:
                level = '特色词'
                rare[w] = {'level': level, 'count': count, 'pos': f, 'dict_freq': dict_freq}
            # count在4到median-1之间的普通词不输出
    
    except Exception:
        pass
    return rare


def analyze_words(text):
    if not HAS_JIEBA:
        return {
            'top_words':[],'func_words':[],'pos_dist':{},'pos_ratios':{},
            'pronouns':[],'idioms':[],'rare_words':{},'rare_word_contexts':{},'wpos':{},
            'person_names':[],'proper_nouns':[],
        }

    pairs  = list(pseg.cut(text))
    tokens = [(w.word.strip(), w.flag) for w in pairs if w.word.strip()]

    # ── v3.0 核心改动：专有名词在content_tokens之前独立收集 ──
    proper_nouns = Counter()  # 人名/地名/专名
    content_tokens, func_tokens = [], []
    
    for w, f in tokens:
        if not any(is_cjk(c) for c in w) or len(w) < 2:
            continue

        # 专有名词独立收集（jieba词典频率过滤伪专名）
        if f.startswith(('nr', 'ns', 'nz')):
            dict_freq = jieba.dt.FREQ.get(w, 0) if HAS_JIEBA else 0
            if dict_freq > 5000:
                # 词典高频词被误标为nr/ns/nz，回流到content_tokens
                content_tokens.append((w, f))
            else:
                proper_nouns[w] += 1
            continue

        if f[:1] in CONTENT_POS:
            content_tokens.append((w, f))
        else:
            func_tokens.append((w, f))

    content_freq = Counter(w for w,_ in content_tokens)
    func_freq    = Counter(w for w,_ in func_tokens)

    all_cjk  = [(w,f) for w,f in tokens if any(is_cjk(c) for c in w) and len(w) >= 2]
    pos_dist = Counter(POS_MAP.get(f[:2],'其他') for w,f in all_cjk)

    pronoun_freq = Counter(w for w,f in tokens if f.startswith('r') and any(is_cjk(c) for c in w))
    idiom_freq   = Counter(w for w,f in tokens if f.startswith('i') and any(is_cjk(c) for c in w))

    # ── v3.0: 词汇特征检测 ──
    # 从content_tokens中移除proper_nouns中已有的词（防止jieba词性不一致导致泄漏）
    proper_noun_set = set(proper_nouns.keys())
    filtered_tokens = [(w, f) for w, f in content_tokens if w not in proper_noun_set]
    rare_words = _detect_word_features(filtered_tokens, text=text)
    rare_word_contexts = {}
    for w in rare_words:
        ctxs = _get_contexts(text, w, max_results=2)
        if ctxs:
            rare_word_contexts[w] = ctxs

    wpos = {}
    for w, cnt in content_freq.items():
        if cnt >= 2:
            positions, start = [], 0
            while True:
                idx = text.find(w, start)
                if idx < 0: break
                positions.append(idx); start = idx + 1
            wpos[w] = positions

    total_content = sum(v for k,v in pos_dist.items() if k not in ('标点','助词','语气词','其他'))
    ratios = {k: round(pos_dist.get(k,0)/max(total_content,1)*100, 1)
              for k in ['名词','动词','形容词','副词','代词','数词','成语','惯用语']}

    return {
        'top_words':          content_freq.most_common(80),
        'func_words':         func_freq.most_common(30),
        'pos_dist':           dict(pos_dist.most_common()),
        'pos_ratios':         ratios,
        'pronouns':           pronoun_freq.most_common(20),
        'idioms':             idiom_freq.most_common(20),
        'person_names':       proper_nouns.most_common(40),
        'proper_nouns':       proper_nouns.most_common(40),
        'rare_words':         rare_words,
        'rare_word_contexts': rare_word_contexts,
        'wpos':               wpos,
    }

# ════════════════════════════════════════════════
# SENTENCE ANALYSIS
# ════════════════════════════════════════════════

def analyze_sentences(text):
    sents = []
    for m in re.finditer(r'[^。！？\n]{2,}[。！？…]+', text):
        t       = m.group(0).strip()
        cjk_len = len([c for c in t if is_cjk(c)])
        rhetoric= classify_rhetoric(t)
        dialog  = bool(re.match(r'\s*[""「『「]', t) or re.search(r'[""「」『』]\s*[。，]', t))
        opening = detect_open(t)
        sents.append({
            'id': len(sents) + 1,
            'text': t, 'clen': cjk_len,
            'type': _para_bucket(cjk_len),
            'dialog': dialog,
            'open': opening,
            'rhetoric': rhetoric,
        })

    if not sents:
        return {'count':0,'avg_len':0,'max_len':0,'min_len':0,'variance':0,
                'rhythm':'','type_dist':{},'open_dist':{},'rhet_dist':{},'dialog_pct':0,'sents':[]}

    lens = [s['clen'] for s in sents]
    avg, mx, mn = sum(lens)/len(lens), max(lens), min(lens)
    var = round(sum((l-avg)**2 for l in lens)/len(lens), 1)

    buckets = Counter(s['type'] for s in sents)
    opens   = Counter(s['open'] for s in sents)
    rhets   = Counter()
    for s in sents:
        for r in s['rhetoric']:
            rhets[r] += 1
    dialog_n = sum(1 for s in sents if s['dialog'])
    dialog_pct = round(dialog_n / len(sents) * 100, 1)

    if mx > 3 * mn:
        rhythm = '强烈对比'
    elif var > avg * 0.5:
        rhythm = '起伏'
    else:
        rhythm = '平稳'

    return {
        'count': len(sents), 'avg_len': round(avg, 1), 'variance': var,
        'max_len': mx, 'min_len': mn, 'rhythm': rhythm,
        'type_dist': dict(buckets),
        'open_dist': dict(opens),
        'rhet_dist': dict(rhets),
        'dialog_pct': dialog_pct,
        'sents': sents,
    }

# ════════════════════════════════════════════════
# PARAGRAPH ANALYSIS
# ════════════════════════════════════════════════

def analyze_paragraphs(text):
    paras = [p.strip() for p in text.split('\n\n') if p.strip()]
    result = []
    for p in paras:
        cjk = len([c for c in p if is_cjk(c)])
        sent_count = len(re.findall(r'[。！？…]', p))
        avg_sent = round(cjk / max(sent_count, 1), 1)
        result.append({
            'id': len(result) + 1,
            'text': p, 'clen': cjk, 'sc': sent_count,
            'avg_sent': avg_sent, 'bucket': _para_bucket(cjk),
        })

    if not result:
        return {'count':0,'avg_len':0,'avg_sc':0,'max_len':0,'min_len':0,
                'bucket_dist':{},'single_sent':0,'paras':[]}

    lens = [p['clen'] for p in result]
    scs  = [p['sc'] for p in result]
    return {
        'count': len(result),
        'avg_len': round(sum(lens)/len(lens), 1),
        'avg_sc': round(sum(scs)/len(scs), 1),
        'max_len': max(lens), 'min_len': min(lens),
        'bucket_dist': dict(Counter(p['bucket'] for p in result)),
        'single_sent': sum(1 for p in result if p['sc'] == 1),
        'paras': result,
    }

# ════════════════════════════════════════════════
# PUNCTUATION ANALYSIS
# ════════════════════════════════════════════════

def analyze_punctuation(text):
    punc_chars = [c for c in text if c in PUNCT_SET]
    counts = Counter(punc_chars)
    total = len(punc_chars)
    cjk_count = len([c for c in text if is_cjk(c)])

    dashes = []
    for m in re.finditer(r'[^。！？\n]{0,30}—[^。！？\n]{0,30}', text):
        dashes.append(m.group(0).strip())
    ellipses = []
    for m in re.finditer(r'[^。！？\n]{0,30}…+[^。！？\n]{0,30}', text):
        ellipses.append(m.group(0).strip())
    pauses = []
    for m in re.finditer(r'[^。！？\n]{0,20}、[^。！？\n]{0,20}', text):
        pauses.append(m.group(0).strip())

    return {
        'total': total,
        'density': round(total / max(cjk_count, 1) * 100, 2),
        'dash_count': len(dashes),
        'ellipsis_count': len(ellipses),
        'pause_count': len(pauses),
        'dash_contexts': dashes[:10],
        'ellipsis_contexts': ellipses[:10],
        'counts': dict(counts),
    }

# ════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════

def run(text):
    text = text.strip()
    if not text:
        return {'error': 'Empty input'}
    if len([c for c in text if is_cjk(c)]) < 100:
        return {'error': 'Text too short (< 100 CJK characters). Analysis not meaningful.'}

    chars = analyze_chars(text)
    words = analyze_words(text)
    sents = analyze_sentences(text)
    paras = analyze_paragraphs(text)
    punct = analyze_punctuation(text)

    word_sent_idx = {}
    for w, cnt in (words.get('top_words') or []):
        if cnt >= 2:
            word_sent_idx[w] = [s['id'] for s in sents['sents'] if w in s['text']]

    return {
        'raw':   text,
        'chars': chars,
        'words': words,
        'sents': sents,
        'paras': paras,
        'punct': punct,
        'word_sent_idx': word_sent_idx,
        'meta': {
            'total_cjk':    chars['total_cjk'],
            'unique_chars': chars['unique'],
            'rare_chars':   chars['rare_count'],
            'sent_count':   sents['count'],
            'para_count':   paras['count'],
            'avg_sent_len': sents['avg_len'],
            'max_sent_len': sents['max_len'],
            'min_sent_len': sents['min_len'],
            'rhythm':       sents['rhythm'],
            'punct_density':punct['density'],
            'dialog_pct':   sents['dialog_pct'],
        }
    }


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            text = f.read()
    else:
        text = sys.stdin.read()
    result = run(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))