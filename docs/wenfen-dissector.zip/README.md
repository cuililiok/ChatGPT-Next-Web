# 文風拆解器 v2.2

中文文學文風分析工具，輸出完整 PDF 分析報告。

## 安裝

```bash
pip install -r requirements.txt
```

## 快速開始

```bash
# 1. 統計分析
python scripts/analyze.py 作品.txt > stats.json

# 2. AI 語意分析（由 AI 閱讀 stats.json + 原文後撰寫）
# → 生成 semantic.md

# 3. 輸出 PDF
python scripts/pdf_report.py \
  --stats stats.json \
  --ai    semantic.md \
  --output 作品_文風分析.pdf \
  --title "《作品名》文風拆解報告" \
  --theme warm-academic
```

## EPUB 輸入

```bash
python scripts/epub_analyzer.py 作品.epub > stats.json
```

## 文件說明

| 文件 | 說明 |
|------|------|
| `SKILL.md` | 完整工作流程文檔 |
| `scripts/analyze.py` | 統計分析引擎（jieba）|
| `scripts/pdf_report.py` | PDF 報告生成器（reportlab）|
| `scripts/epub_analyzer.py` | EPUB 文本提取 |
| `scripts/config.py` | 配置常數 |
| `scripts/md2pdf.py` | PDF 基礎設施（來自 any2pdf）|
| `references/prompts.md` | AI 語意分析提示詞參考 |
| `requirements.txt` | Python 依賴 |

## 依賴

- Python 3.8+
- jieba（中文分詞）
- reportlab（PDF 生成）
- ebooklib（EPUB 解析，可選）
