"""
数据层

包含：
  - provider: 数据提供者接口
  - akshare_provider: AKShare 数据提供者
  - sina_provider: 新浪数据提供者
  - cache: 数据缓存
  - validator: 数据验证
"""

from .provider import DataProvider
from .akshare_provider import AKShareProvider
from .sina_provider import SinaProvider
from .cache import DataCache
from .validator import DataValidator

__all__ = [
    'DataProvider',
    'AKShareProvider',
    'SinaProvider',
    'DataCache',
    'DataValidator'
]
