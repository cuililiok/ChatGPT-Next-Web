# 子Skill安装记录

## 来源

14-step框架依赖的9个核心子skill + 4个辅助skill，来自WPS Lingxi zip包。

**zip文件**：`wps-lingxi-skills-all.zip`（68MB），通过QQ附件上传。
**安装时间**：2026-05-31
**安装方式**：解压后cp到 `~/.hermes/skills/`

## 已安装的子Skill列表

| Skill | 行数 | 用途 | 14-step对应步骤 |
|-------|------|------|----------------|
| industry-analysis | 216 | 行业分析框架 | 第二步 |
| financial-analysis | 250 | 财务分析六层框架 | 第四步 |
| buffett-analysis | 294 | 护城河五类诊断 | 第六步 |
| duan-yongping-investment | 335 | 段永平生意模式诊断 | 第七步 |
| damodaran-valuation | 664 | DCF估值方法论 | 第十二步 |
| ai-era-valuation | 670 | AI公司估值诊断 | 第十二步(12.0) |
| peer-compare | 95 | 同业对比框架 | 第十二步(12.3) |
| sotp-valuation | 272 | SOTP分部估值 | 第十二步(12.4) |
| position-management | 207 | 仓位管理+评分 | 第十三步 |

## 辅助Skill

| Skill | 行数 | 用途 |
|-------|------|------|
| annual-report | 103 | A股年报PDF下载（4源轮询） |
| pdf-verifier | 112 | PDF数据核验 |
| stock_analysis | 166 | 东方财富浏览器爬取 |
| valuation-art | 161 | 估值艺术参考 |

## 安装注意事项

1. zip解压后目录结构可能有嵌套（如`mx-data/mx-data/`），需要调整
2. 子skill的路径占位符`{skill_scripts}`需要在运行时解析
3. `duan-yongping-investment`在skill_view中可能找不到（名称不完全匹配），降级策略会生效
4. 子skill不会出现在`skills_list`的默认列表中（它们在子目录里），但`skill_view(name='xxx')`可以加载

## 验证命令

```bash
for skill in ai-era-valuation buffett-analysis damodaran-valuation duan-yongping-investment \
  financial-analysis industry-analysis peer-compare position-management sotp-valuation; do
  if [ -f ~/.hermes/skills/$skill/SKILL.md ]; then
    echo "✅ $skill ($(wc -l < ~/.hermes/skills/$skill/SKILL.md) lines)"
  else
    echo "❌ $skill MISSING"
  fi
done
```
