# Large Report PDF Conversion

## Problem
reportlab-based md2pdf.py hangs/times out on files >15K chars, especially with CJK text + complex tables. 87KB markdown (Full Mode 14-step report) consistently times out at 120s.

## Solution: weasyprint (tested 2026-05-31)
87KB CJK markdown → 0.54MB PDF in 14.46 seconds. No emoji stripping needed (unlike reportlab).

```python
import os, re, markdown, weasyprint

with open("report.md", "r", encoding="utf-8") as f:
    md = f.read()

# Strip emoji that might cause rendering issues
md_clean = re.sub(r'[⭐⚠️✅❌📊📈💰🎯🤖🔥⚡💡☐☑►▶▼▲◆●★☆♦♣♠♥]', '', md)

html_body = markdown.markdown(md_clean, extensions=['tables', 'fenced_code', 'toc'])

html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
@page {{ size: A4; margin: 2cm; }}
body {{ font-family: "WenQuanYi Zen Hei", "Noto Sans CJK SC", "Liberation Sans", sans-serif; font-size: 10.5pt; line-height: 1.7; color: #2d2d2d; }}
h1 {{ font-size: 18pt; color: #8B4513; border-bottom: 3px solid #8B4513; padding-bottom: 6px; margin-top: 30px; page-break-before: always; }}
h1:first-of-type {{ page-break-before: avoid; }}
h2 {{ font-size: 14pt; color: #2F4F4F; border-bottom: 1.5px solid #D2B48C; padding-bottom: 4px; margin-top: 24px; }}
h3 {{ font-size: 12pt; color: #4A4A4A; margin-top: 18px; }}
p {{ margin: 6px 0; text-align: justify; }}
table {{ border-collapse: collapse; width: 100%; font-size: 9pt; margin: 10px 0; }}
th {{ background: #F5F0EB; border: 1px solid #D2B48C; padding: 5px 8px; text-align: left; font-weight: bold; }}
td {{ border: 1px solid #D2B48C; padding: 4px 8px; }}
tr:nth-child(even) {{ background: #FAFAF5; }}
code {{ background: #F5F5F0; padding: 1px 4px; font-size: 9pt; }}
blockquote {{ border-left: 3px solid #D2B48C; padding-left: 12px; color: #666; }}
</style></head><body>{html_body}</body></html>"""

weasyprint.HTML(string=html).write_pdf("output.pdf")
```

## When to use which
- **<15K chars, simple tables**: md2pdf.py (reportlab) — better typography, cover page, TOC
- **>15K chars or complex CJK**: weasyprint — 10x faster, handles large files, no timeout
- **Full Mode 14-step report (~87KB)**: Always weasyprint

## Dependencies
```bash
pip install weasyprint markdown
```
Both pre-installed on this server.
