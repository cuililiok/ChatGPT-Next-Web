# 年报PDF下载与数据提取工作流

## 巨潮资讯网 (cninfo.com.cn) 年报搜索

```bash
# 巨潮API搜索年报
curl -s "http://www.cninfo.com.cn/new/hisAnnouncement/query" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "stock=601689&tabName=fulltext&pageSize=50&pageNum=1&category=category_ndbg_szsh&seDate=2020-01-01~2026-12-31"
```

注意：巨潮API参数格式可能变化，如果返回空结果，尝试 `stock=0.601689` 或用Tavily搜索直链。

## 公司官网年报

拓普集团: `https://www.tuopu.com/wp-content/uploads/` 下有历年年报

## 第三方源

- QQ财经: `https://file.finance.qq.com/finance/hs/pdf/`
- 新浪财经: `https://money.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?stockid=601689&id=XXX`
- 东方财富: `https://data.eastmoney.com/notices/detail/601689/`

## 下载后验证

```python
import fitz
doc = fitz.open('downloaded.pdf')
print(f'页数: {doc.page_count}')
print(doc[0].get_text()[:200])  # 确认是目标公司
doc.close()
```

年报全文通常 150-300 页。如果 < 30 页，大概率是摘要不是全文。

## 数据提取

```python
import fitz
doc = fitz.open('annual_report.pdf')
for i, page in enumerate(doc):
    text = page.get_text()
    if '近三年主要会计数据' in text and '营业收入' in text:
        print(f'Page {i+1}:')
        print(text[:4000])
        break
doc.close()
```

关键数据位置：
- 主要会计数据: 通常在第 6-8 页
- 分产品营收: 通常在第 19-22 页
- 财务指标(EPS/ROE): 通常在第 7 页
