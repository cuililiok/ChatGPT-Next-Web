# 子代理执行指南（实战经验）

## 何时使用子代理

14步Full Mode报告约2.4万字，单个LLM无法一次完成。必须拆分执行。

## 拆分策略

每家公司拆3个子代理：
- Part1: Step 0-5（数据准备+基本信息+行业+财务+年报掘金）
- Part2: Step 6-10（护城河+资本配置+段永平+发展史+投资秘诀）
- Part3: Step 11-16（估值+仓位管理+数据源+触发器+复盘）

逐个执行（非并行），避免API 429限流。

## 子代理Prompt规范

### 必须包含的数据（写入prompt正文）
- 五年财务数据表（2021-2025，从年报PDF提取）
- 当前股价/PE/PB/市值/总股本
- 可比公司PE/PB数据
- 分产品营收和毛利率
- WACC参数（Rf/Beta/ERP/Kd/tax/D/E）

### 禁止
- ❌ 硬编码年份（写"最新年报"而非"2024年报"）
- ❌ 让子代理自己提取数据（它会猜错）
- ❌ 并行启动3个子代理（会触发429）

### 必须
- ✅ toolsets必须含 `"skills"`（否则无法加载子skill）
- ✅ 每个子代理完成后检查文件存在且内容完整
- ✅ 明确写出"加载XXX skill并严格执行"

## 子代理toolsets配置

```json
["terminal", "file", "skills"]  // 最小集
["terminal", "file", "web", "browser", "skills"]  // 需要搜索时
```

注意：子代理不能使用 `delegate_task`、`clarify`、`memory`、`send_message`、`execute_code`。

## 大文件PDF转换

reportlab(md2pdf.py)处理>15KB的CJK markdown会超时（120s限制）。

**解决方案：weasyprint**
```python
import re, markdown, weasyprint

# 必须清理emoji（reportlab和weasyprint都会卡住）
md_clean = re.sub(r'[⭐⚠️✅❌📊📈💰🎯🤖🔥⚡💡☐☑►▶▼▲◆●★☆♦♣♠♥]', '', md_text)

html_body = markdown.markdown(md_clean, extensions=['tables', 'fenced_code', 'toc'])

html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
@page {{ size: A4; margin: 2cm; }}
body {{ font-family: "WenQuanYi Zen Hei", "Noto Sans CJK SC", sans-serif; font-size: 10.5pt; line-height: 1.7; }}
h1 {{ font-size: 18pt; color: #8B4513; page-break-before: always; }}
h2 {{ font-size: 14pt; color: #2F4F4F; }}
table {{ border-collapse: collapse; width: 100%; font-size: 9pt; }}
th {{ background: #F5F0EB; border: 1px solid #D2B48C; padding: 5px 8px; }}
td {{ border: 1px solid #D2B48C; padding: 4px 8px; }}
</style></head><body>{html_body}</body></html>"""

weasyprint.HTML(string=html).write_pdf('output.pdf')
```

## 报告质量标准

用户原话："你写的报告稀烂"。避免：
- ❌ "行业前景广阔" → ✅ "伺服系统市占率31%，国内第一"
- ❌ "毛利率较高" → ✅ "毛利率40.27%(+1.65pct)"
- ❌ 只给结论 → ✅ 展示DCF逐年预测表、WACC推导链
- ❌ 步骤字数不达标 → ✅ 每步必须达到最低字数

## 年报下载

使用 annual-report skill 的 download.py：
```bash
python3 ~/.hermes/skills/annual-report/scripts/download.py --query <代码> --list --output ~/年报/
python3 ~/.hermes/skills/annual-report/scripts/download.py --query <代码> --year 2025 --output ~/年报/
```

先 `--list` 查可用年份，取最近年份。不要硬编码年份。
