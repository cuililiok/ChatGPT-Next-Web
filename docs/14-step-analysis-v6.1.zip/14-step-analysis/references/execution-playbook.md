# 14-Step Report Execution Playbook

Battle-tested patterns for executing Full Mode 14-step investment research reports. Learned from multiple sessions (2026-05-31).

## Subagent Delegation Pattern

Split a Full Mode report into 3 subagents, each handling a logical section:

### Part 1: Steps 1-5 (Company Fundamentals)
- Step 1: Company basics + terminology (800 words)
- Step 2: Industry analysis (1200 words) — load `industry-analysis` skill
- Step 3: 5-year financial data table (800 words)
- Step 4: Financial analysis 6-layer framework (2000 words) — load `financial-analysis` skill
- Step 5: Annual report mining + anomaly explanation (1200 words)

### Part 2: Steps 6-10 (Qualitative Analysis)
- Step 6: Buffett moat diagnosis (1200 words) — load `buffett-analysis` skill
- Step 6.5: Capital allocation backtest (600 words)
- Step 7: Duan Yongping business model (1200 words) — load `duan-yongping-investment` skill
- Step 8: Company history (800 words)
- Step 9: Annual report + stock price insights (800 words)
- Step 10: Investment thesis (800 words)

### Part 3: Steps 11-16 (Valuation + Recommendation)
- Step 11: Analyst commentary (400 words)
- Step 12: Valuation analysis (1500+ words) — load `damodaran-valuation` + `peer-compare` skills
- Step 13: Position management (1200 words) — load `position-management` skill
- Step 14: Data sources (400 words)
- Step 15: Operation triggers (500 words)
- Step 16: Review memo (300 words)

## Prompt Writing Rules (CRITICAL)

### 1. NEVER Hardcode Years
```
❌ "下载2024年报PDF" / "提取2020-2024数据"
✅ "下载最新年报PDF" / "提取最近五年数据"
✅ "先确定当前日期，最新年份=当前年份-1"
```
Reason: A股 annual reports are released by April 30 of the following year. In May 2026, the latest is 2025.

### 2. Embed Extracted Data in Prompt
Don't make subagents search for data — embed it directly:
```
✅ "已确认的五年数据（来源：年报PDF）：
| 年份 | 营收 | 净利润 | ..."
```
This prevents data hallucination and saves API calls.

### 3. Include Skill Names Explicitly
```
✅ "先加载 industry-analysis skill，按其框架执行"
❌ "做行业分析"  (subagent won't know to load the skill)
```

### 4. Specify Output Path
```
✅ "写完保存到 ~/公司名_part1.md"
```

### 5. Run Sequentially, Not Parallel
Running 3 subagents in parallel causes HTTP 429 rate limits. Run them one at a time.

## Toolsets for Subagents

```json
["terminal", "file", "skills"]
```

The `"skills"` toolset is MANDATORY — without it, subagents cannot load sub-skills
like industry-analysis, financial-analysis, etc.

## PDF Conversion for Large Reports

Full Mode reports are typically 30-80KB markdown. reportlab/md2pdf.py will timeout.

Always use weasyprint:
```python
import re, markdown, weasyprint
md_clean = re.sub(r'[⭐⚠️✅❌📊📈💰🎯🤖🔥⚡💡☐☑►▶▼▲◆●★☆♦♣♠♥]', '', md)
html_body = markdown.markdown(md_clean, extensions=['tables', 'fenced_code', 'toc'])
# Use the CSS template from any2pdf/references/weasyprint-cjk-template.md
```

## Data Extraction from Annual Reports

Use `annual-report` skill's `download.py` script:
```bash
python ~/.hermes/skills/annual-report/scripts/download.py \
  --query <股票代码> --year <年份> --output ~/年报/
```

Key commands:
- `--list` to see available years
- `--year YYYY` to download specific year
- Output to `~/年报/` for organized storage

Extract data with pymupdf:
```python
import fitz
doc = fitz.open(pdf_path)
text = "".join(page.get_text() for page in doc)
# Then regex for specific metrics
```

## Multi-Company Parallel Analysis Pattern

When analyzing multiple companies simultaneously (e.g., industry comparison):

### Data Preparation
1. Use AKShare `stock_financial_abstract_ths` to get 5-year data for all companies
2. Use Sina Finance `hq.sinajs.cn` for real-time stock prices
3. Download annual report PDFs via `annual-report` skill's `download.py`
4. Embed all extracted data in subagent prompts (prevents hallucination)

### Subagent Execution
- Spawn one subagent per company (up to 3 parallel for this user)
- Each subagent runs the FULL 14-step framework independently
- Embed company-specific data, stock price, and PE/PB in the prompt
- Specify company type classification (A-H) in the prompt to save time
- Output path: `~/[公司名]深度研究报告_v[N]_Full.md`

### Post-Processing
- Verify all reports were created: `wc -l` for line count
- Convert to PDF using weasyprint (not reportlab, which times out on large files)
- Emoji cleaning regex: `re.sub(r'[⭐⚠️✅❌📊📈💰🎯🤖🔥⚡💡☐☑►▶▼▲◆●★☆♦♣♠♥]', '', md)`

### Example Prompt Structure
```
Company: [Name] ([Code])
Industry: [Sector]
Annual report PDF: ~/年报/[Name]：2025年年度报告.pdf

5-year financial data (from AKShare 2025年报):
| Year | Revenue | Net Profit | Rev Growth | Profit Growth | ROE | Gross Margin | EPS | BPS |
|------|---------|------------|------------|---------------|------|--------------|------|------|
| 2021 | ... | ... | ... | ... | ... | ... | ... | ... |
...

Current stock price: ~XX元
PE: ~XXx
PB: ~XXx

Skills to load: [list all required skills]
Output: Save to ~/[公司名]深度研究报告_v3_Full.md

IMPORTANT:
1. Load 14-step-analysis skill FIRST
2. Use Full Mode (16 steps)
3. For 12.-1 company type: [A/B/C/etc.]
4. Valuation path: [Standard DCF + PE percentile / Scenario DCF / etc.]
```

## Quality Checklist

Before submitting a report, verify:
- [ ] All 16 steps present (Full Mode)
- [ ] Each step meets minimum word count
- [ ] Financial data from annual report PDF (not hallucinated)
- [ ] Years are correct (latest = current_year - 1)
- [ ] Skills were loaded (check for "skill调用记录")
- [ ] Anomalies >30% explained
- [ ] Valuation uses correct company type (A-H classification)
- [ ] At least 4 valuation methods with specific prices
- [ ] 3 kill points in Step 13
- [ ] Review memo with frontmatter
