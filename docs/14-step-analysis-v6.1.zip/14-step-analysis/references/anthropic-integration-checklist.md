# Anthropic Skills + 14-step 整合清单

## 14步框架中的Anthropic Skill增强点

| 14步步骤 | 增强Skill | 用途 |
|---------|----------|------|
| 第2步 行业分析 | `sector-overview` | 行业概览（TAM/竞争格局/估值上下文） |
| 第12.3步 同业对比 | `competitive-analysis` | 竞争格局Deck（市场定位/战略综述） |
| 第12.9步 催化剂日历 | `catalyst-calendar` | 事件驱动日历（每周预览/仓位影响） |
| 第13.0步 反向论文 | `thesis-tracker` | 持续跟踪（论点评分卡/置信度更新） |

## 财报季专用流程

1. 财报前 → `earnings-preview`（Bull/Base/Bear情景预判）
2. 财报后 → `model-update`（更新财务模型和估值）
3. 持续 → `thesis-tracker`（更新投资论点评分卡）

## 不进14步的日常工具

| Skill | 场景 |
|-------|------|
| `morning-note` | 晨会纪要 |
| `ic-memo` | 投委会备忘录 |
| `deal-screening` | Deal筛选 |
| `teaser` | 匿名Teaser |
| `ib-check-deck` | PPT数字QC |
| `deck-refresh` | PPT数据刷新 |
| `clean-data-xls` | Excel数据清洗 |
