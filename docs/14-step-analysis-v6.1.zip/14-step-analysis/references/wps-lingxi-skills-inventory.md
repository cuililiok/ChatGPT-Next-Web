# WPS Lingxi Skills Inventory

Source: `wps-lingxi-skills-all.zip` (~68MB), provided by user 2026-05-31.

## Investment Research Skills (installed at ~/.hermes/skills/)
| Skill | Lines | Description |
|-------|-------|-------------|
| ai-era-valuation | 670 | AI company valuation: 5 dimensions (value chain, data moat, compute cost curve, regulatory option, human capital depreciation) + bimodal distribution |
| annual-report | 103 | Annual report PDF download from cninfo/QQ Finance |
| buffett-analysis | 294 | Buffett moat diagnosis: 5 types (resource, scale, cost, location, brand/diversification) |
| damodaran-valuation | 664 | Full DCF framework: WACC (Hamada relevering), 3-stage FCFF, terminal value, sensitivity analysis |
| duan-yongping-investment | 335 | Duan Yongping business model diagnosis: product quality, business model, management quality |
| financial-analysis | 250 | 6-layer financial analysis framework |
| industry-analysis | 216 | Industry analysis: lifecycle, CR4/CR8, TAM/SAM/SOM, supply-demand |
| pdf-verifier | 112 | PDF data verification against report |
| peer-compare | 95 | Peer comparison: terminal colored table, auto-ranking |
| position-management | 207 | Position sizing: S/A/B/C certainty grading, valuation veto, circle of competence |
| sotp-valuation | 272 | Sum-of-the-parts valuation for multi-segment companies |
| stock_analysis | 166 | East Money browser scraping for stock data |
| valuation-art | 161 | Advanced valuation art: cyclical investing, normalized earnings |

## Other Skills in Zip (not installed)
browser, chanshuo-perspective, dbsheet, deep-reading, deep-read-journalism, deep_research, docx, epub-translate, gov-doc-format, ima-skill, knowledge-base-site, lovestudio-any2pdf, minimax-pdf, mx_search, nuwa-distill, paper-writer, pdf, pptx, skill_creator, tushare-finance, web_builder, wps365, wps_docs, xlsx, weread

## Key Note
14-step-analysis SKILL.md references these skills by name (e.g., "必须调用：industry-analysis skill"). If `skill_view(name='industry-analysis')` fails, the skill may not be registered in Hermes' skill index even though files exist at `~/.hermes/skills/industry-analysis/SKILL.md`. Check the filesystem directly with `find ~/.hermes/skills -name SKILL.md`.
