# Anthropic 金融 Skill 整合指南

**安装日期：2026-06-01**
**来源：Anthropic《如何使用金融Skills》**

## 概述

13个Anthropic金融Skill已安装，与14步深度研究框架互补：
- **深度研究**（14-step框架）：每季度/半年对重点标的做Full Mode报告
- **日常投研**（以下工具）：财报季、晨会、Deal筛选等高频场景

## 工具链总览

| Skill | 功能 | 触发词 | 与14步框架的关系 |
|-------|------|--------|-----------------|
| `competitive-analysis` | 竞争格局分析Deck | 竞争分析、竞品分析、peer benchmarking | **增强第12.3步**（同业对比） |
| `catalyst-calendar` | 催化剂日历 | 催化剂日历、事件日历、catalyst calendar | **增强第12.9步**（催化剂日历） |
| `earnings-preview` | 财报前预览 | 业绩前瞻、earnings preview、季报预判 | **财报季专用**（第15步触发器前置） |
| `thesis-tracker` | 投资论点跟踪 | 投资逻辑、thesis check、持仓复盘 | **增强第13.0步**（反向论文持续跟踪） |
| `sector-overview` | 行业概览报告 | 行业研究、行业报告、赛道分析 | **增强第2步**（行业分析） |
| `model-update` | 财报后更新模型 | 更新模型、插财报、刷新估值 | **财报后专用**（更新第12步估值） |
| `morning-note` | 晨会纪要 | 晨报、晨会纪要、早盘提示 | **日常投研**（不进14步） |
| `ic-memo` | 投委会备忘录 | 投委会备忘录、IC memo | **PE/VC场景**（不进14步） |
| `deal-screening` | Deal快速筛选 | Deal筛选、项目筛选 | **PE/VC场景**（不进14步） |
| `teaser` | 匿名Teaser | Teaser、匿名简介 | **M&A场景**（不进14步） |
| `ib-check-deck` | PPT数字一致性检查 | 检查PPT、QC deck | **投行QC**（不进14步） |
| `deck-refresh` | 用新财报刷新PPT | 刷新PPT数字、deck refresh | **投行季报更新**（不进14步） |
| `clean-data-xls` | Excel数据清洗 | 清洗数据、整理表格 | **数据预处理**（不进14步） |

## 与14步框架的联动规则

### 第2步（行业分析）增强

Full Mode 行业分析时，可调用 `sector-overview` skill 生成结构化行业概览：
- 输出：市场规模、竞争格局、关键趋势、估值上下文
- 与 `industry-analysis` skill 互补：
  - `industry-analysis`：偏麦肯锡方法论（肖璟框架）
  - `sector-overview`：偏投行研报格式（TAM/SAM/SOM + 竞争格局 + 估值上下文）

**调用方式：**
```
加载 sector-overview skill，按其框架生成行业概览
```

### 第12.3步（同业对比）增强

调用 `competitive-analysis` skill 生成竞争格局Deck：
- 输出：市场定位图、竞争对手深度对比、战略综合分析
- 与 `peer-compare` skill 互补：
  - `peer-compare`：偏财务指标对比（PE/PB/ROE横向比较）
  - `competitive-analysis`：偏战略+市场定位（护城河、竞争动态、战略综述）

**调用方式：**
```
加载 competitive-analysis skill，按其框架生成竞争格局分析
```

### 第12.9步（催化剂日历）增强

调用 `catalyst-calendar` skill 生成结构化催化剂日历：
- 输出：未来6-12个月关键事件表、每周预览、仓位影响分析
- 与12.9原有的催化剂表互补：
  - 原12.9：偏"与DCF的联动"（哪些已price in，哪些是增量）
  - `catalyst-calendar`：偏"事件驱动投资"（每周预览、仓位影响）

**调用方式：**
```
加载 catalyst-calendar skill，按其框架生成催化剂日历
```

### 第13.0步（反向论文）持续跟踪

报告完成后，用 `thesis-tracker` 持续跟踪投资论点：
- 输出：论点评分卡、催化剂时间线、置信度更新
- 与13.0原有的kill points互补：
  - kill points：静态快照（报告完成时的3个卖出理由）
  - `thesis-tracker`：动态跟踪（持续更新论点评分卡）

**调用方式：**
```
加载 thesis-tracker skill，按其框架跟踪投资论点
```

### 财报季专用流程

1. **财报前**：调用 `earnings-preview` 做Bull/Base/Bear情景预判
2. **财报后**：调用 `model-update` 更新财务模型和估值
3. **持续**：调用 `thesis-tracker` 更新投资论点评分卡

**调用示例：**
```
用户："绿的谐波下个月财报，帮我做个预览"
→ 加载 earnings-preview skill
→ 生成Bull/Base/Bear情景分析

用户："更新一下我之前做的拓普集团报告里的估值"
→ 加载 model-update skill
→ 用最新财报数据更新DCF模型
```

## 不进14步框架的工具

以下Skill用于其他投研场景，不在14步深度研究流程中使用：

| Skill | 场景 | 说明 |
|-------|------|------|
| `morning-note` | 日常投研 | 晨会纪要、隔夜复盘 |
| `ic-memo` | PE/VC | 投委会备忘录 |
| `deal-screening` | PE/VC | Deal快速筛选 |
| `teaser` | M&A | 匿名Teaser |
| `ib-check-deck` | 投行 | PPT数字一致性检查 |
| `deck-refresh` | 投行 | 用新财报刷新PPT |
| `clean-data-xls` | 数据预处理 | Excel数据清洗 |

## 与Wind Skill的关系

| 维度 | Wind Skill | Anthropic Skill |
|------|-----------|-----------------|
| 数据源 | 实时行情、财务数据、研报 | 方法论框架、分析模板 |
| 定位 | "拿数据" | "做分析" |
| 互补关系 | Wind提供数据 → Anthropic提供框架 → 14-step整合输出 |

**典型工作流：**
1. Wind `上市公司一页纸投资报告` → 5分钟初筛
2. Anthropic `earnings-preview` → 财报前预判
3. 14-step Full Mode → 深度研究报告
4. Anthropic `thesis-tracker` → 持续跟踪
5. Wind `金融事实核验` → 数据交叉验证
