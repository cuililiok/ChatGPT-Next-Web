# Multi-Company Comparative Valuation Guide

**Created: 2026-06-01**
**Triggered by: User correction "估值也要按我给你的估值skill去做，不是随随便便自己去查的"**

## Core Rule

**NEVER use ad-hoc valuation methods (PEG tables, quality scorecards) as the primary valuation. Always use the 14-step framework's valuation methodology, even for quick comparisons.**

## Correct Approach for Multi-Company Comparison

### Step 1: Company Type Classification (12.-1)
For EACH company, determine:
- Type A (mature stable) → Standard DCF + PE percentile + peer comparison
- Type B (high growth) → Scenario DCF + PE percentile
- Type C (cyclical) → Normalized earnings DCF
- Type D (financial) → FCFE/PB or P/EV
- etc.

### Step 2: Data Collection
- Use AKShare `stock_financial_abstract_ths` for 5-year data
- Use Sina Finance `hq.sinajs.cn` for real-time prices
- Embed data in subagent prompts

### Step 3: Valuation Execution
For each company, execute the appropriate valuation path:
1. DCF (EPV + full DCF for A-type, scenario DCF for B-type)
2. PE/PB historical percentile
3. Peer comparison (12.3)
4. Reverse DCF (12.8.1)

### Step 4: Comparative Output
Structure the comparison as:
1. **First tier** (PEG < 2, quality score > 8): Core positions
2. **Second tier** (PEG 1.5-2.5, unique moat): Satellite positions
3. **Third tier** (PEG > 3): Watchlist
4. **Fourth tier** (extreme overvaluation or loss-making): Avoid

### Step 5: Summary Table
| Rank | Company | PEG | Quality Score | Core Logic | Target Price | Upside |
|------|---------|-----|---------------|------------|--------------|--------|
| #1 | ... | ... | ... | ... | ... | ... |

## What NOT to Do

❌ Create standalone PEG/quality score tables without DCF
❌ Skip 12.-1 company type classification
❌ Use the same valuation method for all companies
❌ Present flat comparisons without tiered recommendations
❌ Rely solely on relative metrics (PE, PB) without absolute valuation

## Acceptable Supplements

✅ PEG ratio as a screening/filtering tool (not primary valuation)
✅ Quality score (ROE × growth / PE) as a ranking aid
✅ Industry heat maps for visualization
✅ Tiered recommendation tables for actionable guidance

These supplements COMPLEMENT the 14-step framework but DO NOT REPLACE it.
