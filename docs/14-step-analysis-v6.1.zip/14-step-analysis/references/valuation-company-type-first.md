# Valuation Workflow: Company Type First

## Critical Rule (from SKILL.md line 496)
> "分类错误是估值失效的最常见原因。对周期股用当期PE估值、对保险公司用FCFF建模，结论必然失真。"

## Workflow
1. Read 12.-1 company type table (SKILL.md line 428-437)
2. Classify into A-H + optional subtype
3. Look up valuation method table (SKILL.md line 1138-1147) — labels now match 12.-1
4. Execute only the methods specified for that type
5. Output classification conclusion in required format (line 501-507)

## Company Types Quick Reference
| Type | Criteria | Core Method | Key Trap |
|------|----------|-------------|----------|
| A. Mature/Stable | Profit stable ≥5y, growth <15% | 3-stage FCFF DCF | Don't overestimate growth |
| B. High Growth | Revenue growth >30%, or unprofitable | Scenario DCF + probability discount | No historical anchor |
| C. Cyclical | Profit swings with economic cycle | Normalized earnings DCF, NEVER use current PE | Current PE is misleading |
| D. Financial | Banks, insurance, brokers | Bank→FCFE/P/B; Life→P/EV; P&C→P/B+COR | Debt is "raw material", no FCFF |
| E. Commodity | Profit driven by external prices | Price scenario DCF + resource reserves | External price uncontrollable |
| F. Emerging Market | High-risk country exposure | Adjusted DCF with CRP | A-ships default include China CRP |
| G. Distress | Sustained losses, debt default risk | Liquidation value / option pricing | DCF terminal value meaningless |
| H. Platform/Network | Multi-sided network + multi-business | SOTP per segment + platform premium | Cannot use single PE/PS |

## Chemical Sub-sector Rules (C vs A)
- Condition 1: Product requires customer certification? (high switching cost)
- Condition 2: Company survived full cycle with ROIC > WACC at bottom?
- Both YES → A type (e.g., 万华化学 MDI)
- Only Cond 1 → C type (specialty but cyclical)
- Cond 1 NO → C type (standard cyclical)

## Pitfall: Two Tables Had Mismatched Labels (FIXED in v5b)
The 12.-1 classification table (line 428) and the 12.10 valuation method table (line 1138) previously had DIFFERENT A-H labels (e.g., A="mature stable" vs A="稳健消费"). This was fixed in v5b — labels now match. If re-installing from original zip, this fix needs to be re-applied.
