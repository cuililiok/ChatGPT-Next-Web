# 14-step Full Mode 子代理执行策略

## 拆分方案

Full Mode报告约2.4万字，单个子代理会超时。拆为3部分：

| Part | 步骤 | 约字数 | 子代理数 |
|------|------|--------|---------|
| Part1 | Step 0-5（数据准备+基本面） | ~8000字 | 1个 |
| Part2 | Step 6-10（护城河+生意模式） | ~6000字 | 1个 |
| Part3 | Step 11-16（估值+仓位+触发器） | ~10000字 | 1个 |

## 执行顺序

**必须顺序执行，不能并行。** 并行会导致429限流错误。

```
Part1 → 等完成 → Part2 → 等完成 → Part3 → 合并 → 转PDF
```

## 子代理prompt要点

1. **不硬编码年份** — 写"最新年报""最近五年"，让子代理动态确定
2. **数据写入prompt** — 把已提取的五年财务数据直接写在prompt里，不让子代理自己推断
3. **toolsets必须包含 `"skills"`** — 否则子代理加载不了industry-analysis等子skill
4. **明确要求加载哪些skill** — 在prompt里写"先用skill_view加载XXX skill"
5. **字数要求写死** — 每步写明"XXX字"，子代理会自检

## 数据准备

在启动子代理前，先用annual-report skill的download.py下载年报：
```bash
python ~/.hermes/skills/annual-report/scripts/download.py \
  --query <股票代码> --year <最新年份> --output ~/年报/
```

用 `--list` 查可用年份，用pymupdf提取数据。

## Large File PDF转换

报告>15KB时，md2pdf.py(reportlab)会超时。改用weasyprint：

```python
import markdown, weasyprint
html_body = markdown.markdown(md_content, extensions=['tables', 'fenced_code', 'toc'])
html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
@page {{ size: A4; margin: 2cm; }}
body {{ font-family: "WenQuanYi Zen Hei", sans-serif; font-size: 10.5pt; line-height: 1.7; }}
h1 {{ font-size: 18pt; color: #8B4513; page-break-before: always; }}
h2 {{ font-size: 14pt; color: #2F4F4F; border-bottom: 1.5px solid #D2B48C; }}
table {{ border-collapse: collapse; width: 100%; font-size: 9pt; }}
th {{ background: #F5F0EB; border: 1px solid #D2B48C; padding: 5px 8px; }}
td {{ border: 1px solid #D2B48C; padding: 4px 8px; }}
</style></head><body>{html_body}</body></html>"""
weasyprint.HTML(string=html).write_pdf('output.pdf')
```

注意：先strip emoji字符（⭐⚠️✅❌等），否则可能渲染异常。

## 常见坑

| 坑 | 解决 |
|---|---|
| 子代理429限流 | 顺序执行，不并行 |
| 子代理不加载skill | toolsets加`"skills"` |
| 年份写死导致缺数据 | prompt写"最新年报"，不写具体年份 |
| reportlab超时 | 用weasyprint |
| 子代理输出没保存 | prompt里明确写"保存到 ~/xxx.md" |
