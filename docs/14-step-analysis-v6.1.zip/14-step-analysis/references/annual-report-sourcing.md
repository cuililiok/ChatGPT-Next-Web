# 年报PDF获取与数据提取实操指南

> 来源：2026-05-31 拓普集团14步分析实战经验

## 一、年报PDF获取

### 核心原则
- **cninfo.com.cn（巨潮资讯网）** 是A股年报最权威来源
- **URL不可猜测**：`/finalpage/` 后面的日期和ID是随机的，必须通过搜索获取
- **必须验证下载内容**：页数、公司名、报告类型

### 获取方法（按可靠性排序）

#### 方法1：Tavily搜索PDF直链（推荐）
```
搜索词："static.cninfo.com.cn 公司全称 年度报告 PDF"
搜索词："site:cninfo.com.cn 股票代码 年度报告"
搜索词："公司全称 年度报告 PDF file.finance.qq.com"
```

cninfo URL格式：`http://static.cninfo.com.cn/finalpage/YYYY-MM-DD/XXXXXXXXXX.PDF`
QQ财经URL格式：`https://file.finance.qq.com/finance/hs/pdf/YYYY/MM/DD/XXXXXXXX.PDF`

#### 方法2：公司官网
```
搜索词："公司域名 年度报告 PDF"
例：拓普集团 → "tuopu.com 年度报告 PDF"
```
⚠️ 公司官网可能只有摘要版（<15页），必须验证页数

#### 方法3：新浪财经公告页（GBK编码）
```
URL: https://money.finance.sina.com.cn/corp/go.php/vCB_Bulletin/stockid/{代码}/page_type/ndbg.phtml
注意：页面用GBK编码，curl需 iconv -f gbk -t utf-8
```

#### 方法4：巨潮API（参数格式敏感）
```bash
curl -s "http://www.cninfo.com.cn/new/hisAnnouncement/query" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "stock=0.601689&tabName=fulltext&pageSize=50&pageNum=1&category=category_ndbg_szsh&seDate=2022-01-01~2026-12-31"
```
⚠️ stock参数格式可能需要 "0.{代码}" 而非裸代码

### 下载验证流程
```bash
# 1. 下载
curl -sL "<URL>" -o ~/reports/{year}.pdf

# 2. 验证页数（全文应>150页，摘要<15页）
file ~/reports/{year}.pdf

# 3. 验证公司名和报告类型
python3 -c "
import fitz
doc = fitz.open('{year}.pdf')
print(doc[0].get_text()[:300])
print(f'Pages: {doc.page_count}')
doc.close()
"
```

### 常见陷阱
1. **cninfo URL不能猜测**：同一公司的不同年份年报URL路径完全不同
2. **搜索结果可能返回其他公司的年报**：必须验证第一页的公司名
3. **公司官网PDF可能是摘要**：拓普集团2022年报在官网只有12页摘要
4. **cninfo搜索API参数敏感**：stock参数格式、seDate格式都可能影响结果
5. **新浪财经用GBK编码**：直接curl得到的中文是乱码，需要iconv转换
6. **同一年报可能有多个来源**：优先cninfo > QQ财经 > 公司官网 > 其他

## 二、PDF数据提取

### 核心工具
```bash
pip install pymupdf  # 或 pip install fitz
```

### 必须提取的数据（按优先级）

#### 优先级1："近三年主要会计数据"（页6-8）
包含3年对比数据+同比增速，是最佳数据来源：
- 营业收入、归母净利润、扣非净利润、经营现金流
- 归母净资产、总资产
- ⚠️ 这个表格已含同比增速，且是审计后数据

#### 优先级2："主要财务指标"（紧随其后）
- 基本EPS、加权ROE、扣非ROE
- ⚠️ EPS可能因转增股本而重述，注意"调整后"列

#### 优先级3："主营业务分产品情况"（管理层讨论分析章节）
- 分产品营收、成本、毛利率、同比增速
- ⚠️ 这是分析业务结构的核心数据

#### 优先级4：完整财务报表（财务报告章节）
- 利润表、资产负债表、现金流量表
- 用于深度财务分析（六层框架）

### 提取代码模板
```python
import fitz

def extract_table(pdf_path, keyword):
    """从年报PDF中搜索包含关键词的页面并提取文本"""
    doc = fitz.open(pdf_path)
    results = []
    for i, page in enumerate(doc):
        text = page.get_text()
        if keyword in text:
            results.append((i+1, text))
    doc.close()
    return results

# 使用示例 - 搜索"近三年主要会计数据"
pages = extract_table('2025.pdf', '近三年主要会计数据')
for page_num, text in pages:
    print(f"Page {page_num}:", text[:3000])

# 搜索分产品数据
pages = extract_table('2024.pdf', '主营业务分产品情况')
for page_num, text in pages:
    print(f"Page {page_num}:", text[:5000])
```

### 数据提取常见错误
1. **搜索"营业收入"会匹配大量无关页面**：用组合关键词如"近三年主要会计数据"
2. **不要硬编码页码**：不同年份年报的页面布局可能不同
3. **注意转增股本影响**：2023年拓普每10股转增4.5股，导致EPS需要重述
4. **"调整前/调整后"列**：因转增股本重述的EPS，以"调整后"为准
5. **"近三年"是滚动窗口**：2024年报含2022/2023/2024，2025年报含2023/2024/2025

### 5年数据拼接策略
- 2024年报提供：2022/2023/2024三年数据
- 2025年报提供：2023/2024/2025三年数据
- 重叠年份（2023/2024）数据必须一致，不一致以最新年报为准
- 2021年数据：从2024年报中2022年数据+增长率反推，或单独下载2021年报

## 三、关键教训（实战总结）

1. **必须确认当前日期**：2026年5月做分析，2025年报早已披露（2026年4月），不能只用到2024年
2. **不能用券商研报数据替代年报原文**：铁律第3条"必须先下载年报PDF再核验"
3. **不能估算数据**：2020-2022年的数据不能用增长率推算，必须从年报提取
4. **验证每个PDF**：搜索结果可能返回其他公司的同名报告
5. **备份多来源**：同一份年报从cninfo和QQ财经各下一个，互相验证
